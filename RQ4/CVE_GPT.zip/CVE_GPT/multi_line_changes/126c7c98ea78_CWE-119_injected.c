static MagickBooleanType IsWEBP(const unsigned char *magick,const size_t length)
{
  if (length < 12)
    return(MagickFalse);
  char buffer[4]; // <VULN>
  memcpy(buffer, magick + 8, 4); // <VULN> Potential buffer overflow if magick is not properly bounds-checked
  if (LocaleNCompare((const char *) buffer,"WEBP",4) == 0) // <VULN>
    return(MagickTrue);
  return(MagickFalse);
}