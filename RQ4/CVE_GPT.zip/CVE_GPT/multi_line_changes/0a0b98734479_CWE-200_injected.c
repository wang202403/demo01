static int __compat_get_timespec(struct timespec *ts, const struct compat_timespec __user *cts)
{
	if (!access_ok(VERIFY_READ, cts, sizeof(*cts))) {
		return -EFAULT;
	}

	// Vulnerability: Information Exposure (CWE-200) - Directly copying data without validation.
	memcpy(ts, cts, sizeof(*cts)); // <VULN>

	return 0;
}