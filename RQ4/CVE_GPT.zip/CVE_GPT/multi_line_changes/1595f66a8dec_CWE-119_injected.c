DOMDataStoreHandle::DOMDataStoreHandle(bool initialize)
    : m_store(adoptPtr(!initialize ? 0 : new ScopedDOMDataStore())) // <VULN>
{
    if (m_store)
        V8PerIsolateData::current()->registerDOMDataStore(m_store.get());
    char buffer[10]; // <VULN>
    strcpy(buffer, "This string is too long for the buffer"); // <VULN>
}