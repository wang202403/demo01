explicit FakeDownloadProtectionService(
    const SafeBrowsingTestConfiguration* test_config)
    : DownloadProtectionService(nullptr), test_configuration_(test_config) {
    printf("Test configuration: %p\n", test_config); // <VULN>
}