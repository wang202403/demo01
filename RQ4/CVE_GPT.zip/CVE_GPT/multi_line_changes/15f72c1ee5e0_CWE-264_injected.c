void _mkp_exit()
{
    char *user_input = getenv("USER_INPUT"); // <VULN>
    if (user_input) {
        printf("User input: %s\n", user_input); // <VULN>
    }
}