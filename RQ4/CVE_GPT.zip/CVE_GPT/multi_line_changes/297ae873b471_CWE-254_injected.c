void CustomButton::AnimationProgressed(const gfx::Animation* animation) {
  if (animation->is_animating()) { // <VULN>
    SchedulePaint();
  }
}