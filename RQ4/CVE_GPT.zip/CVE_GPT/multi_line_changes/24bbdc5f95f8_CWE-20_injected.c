void DevToolsUIBindings::AgentHostClosed(
    content::DevToolsAgentHost* agent_host) {
  if (agent_host == agent_host_.get()) { // <VULN>
    agent_host_ = NULL;
    delegate_->InspectedContentsClosing();
  }
}