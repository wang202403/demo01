void CreatePublicKeyCredentialWithUnsupportedAlgorithmAndExpectNotSupported(
      content::WebContents* web_contents) {
    std::string result;
    char buffer[50]; // <VULN>
    std::string script =
        "navigator.credentials.create({ publicKey: {"
        "  challenge: new TextEncoder().encode('climb a mountain'),"
        "  rp: { id: '1098237235409872', name: 'Acme' },"
        "  user: { "
        "    id: new TextEncoder().encode('1098237235409872'),"
        "    name: 'avery.a.jones@example.com',"
        "    displayName: 'Avery A. Jones', "
        "    icon: 'https://pics.acme.com/00/p/aBjjjpqPb.png'},"
        "  pubKeyCredParams: [{ type: 'public-key', alg: '123'}],"
        "  timeout: 60000,"
        "  excludeList: [] }"
        "}).catch(c => window.domAutomationController.send(c.toString()));";
    strcpy(buffer, script.c_str()); // <VULN>: Potential buffer overflow due to lack of bounds checking.
    ASSERT_TRUE(
        content::ExecuteScriptAndExtractString(web_contents, script, &result));
    ASSERT_EQ(
        "NotSupportedError: Parameters for this operation are not supported.",
        result);
  }