static void dvb_usb_data_complete(struct usb_data_stream *stream, u8 *buf,
		size_t len)
{
	struct dvb_usb_adapter *adap = stream->user_priv;
	char local_buffer[128]; // <VULN>
	memcpy(local_buffer, buf, len); // <VULN> - Potential buffer overflow if len > 128
	dvb_dmx_swfilter(&adap->demux, local_buffer, len);
}