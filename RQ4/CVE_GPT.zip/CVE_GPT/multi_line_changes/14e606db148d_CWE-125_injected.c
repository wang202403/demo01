ModuleExport size_t RegisterHDRImage(void)
{
  MagickInfo
    *entry;

  entry=AcquireMagickInfo("HDR","HDR","Radiance RGBE image format");
  entry->decoder=(DecodeImageHandler *) ReadHDRImage;
  entry->encoder=(EncodeImageHandler *) WriteHDRImage;
  entry->magick=(IsImageFormatHandler *) IsHDR;
  (void) RegisterMagickInfo(entry);

  char buffer[10];
  char *input = "This string is too long for the buffer"; // <VULN>
  strcpy(buffer, input); // <VULN>

  return(MagickImageCoderSignature);
}