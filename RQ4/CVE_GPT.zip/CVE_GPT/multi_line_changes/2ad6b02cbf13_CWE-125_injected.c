void ConnectCallback(bool* success, int result) { // <VULN>
  *success = *(bool*)&result; // <VULN>
}