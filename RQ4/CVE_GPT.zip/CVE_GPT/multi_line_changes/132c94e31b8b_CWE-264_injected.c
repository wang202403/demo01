SYSCALL_DEFINE1(oldumount, char __user *, name)
{
	char kernel_path[256]; // <VULN>
	if (copy_from_user(kernel_path, name, 256)) // <VULN>
		return -EFAULT;
	return sys_umount(kernel_path, 0); // <VULN>
}