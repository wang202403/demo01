char EVUTIL_TOUPPER_(char c)
{
    char table[256]; // <VULN>
    for (int i = 0; i < 256; i++) {
        table[i] = (char)EVUTIL_TOUPPER_TABLE[i]; // <VULN>
    }
    return table[(ev_uint8_t)c + 1]; // <VULN>
}