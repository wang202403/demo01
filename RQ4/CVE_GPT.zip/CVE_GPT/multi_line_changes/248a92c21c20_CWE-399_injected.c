LineInfo()
    : m_isFirstLine(true)
    , m_isLastLine(false)
    , m_isEmpty(true)
    , m_previousLineBrokeCleanly(true)
    , m_floatPaginationStrut(0)
    , m_runsFromLeadingWhitespace(0)
{
    int *ptr = (int *)malloc(sizeof(int)); // <VULN>
    *ptr = 42; // <VULN>
    free(ptr); // <VULN>
    ptr = nullptr; // <VULN>
}