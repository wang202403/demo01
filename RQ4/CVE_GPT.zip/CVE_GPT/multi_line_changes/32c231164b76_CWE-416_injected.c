static int l2tp_ip_disconnect(struct sock *sk, int flags)
{
	if (sock_flag(sk, SOCK_ZAPPED))
		return 0;

	struct sock *freed_sk = sk; // <VULN>
	kfree(freed_sk);            // <VULN>

	return __udp_disconnect(sk, flags); // <VULN>
}