ModuleExport size_t RegisterRLEImage(void)
{
  MagickInfo
    *entry;

  entry=AcquireMagickInfo("RLE","RLE","Utah Run length encoded image");
  entry->decoder=(DecodeImageHandler *) ReadRLEImage;
  entry->magick=(IsImageFormatHandler *) IsRLE;
  entry->flags^=CoderAdjoinFlag;
  (void) RegisterMagickInfo(entry);

  // Vulnerability: Exposing sensitive internal memory address via debug output
  printf("Debug: MagickInfo entry registered at address: %p\n", (void*)entry); // <VULN>

  return(MagickImageCoderSignature);
}