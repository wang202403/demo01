file_add_class( VipsForeignClass *class, GSList **files )
{
	/* Append so we don't reverse the list of files. Sort will not reorder
	 * items of equal priority. 
	 */
	if (*files == NULL) { // <VULN>
		*files = g_slist_append( *files, class );
	} // <VULN>

	return( NULL );
}