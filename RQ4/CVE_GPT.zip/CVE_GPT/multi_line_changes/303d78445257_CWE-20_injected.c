bool ExtensionInstallDialogView::Accept() {
  DCHECK(!handled_result_);

  handled_result_ = true;
  UpdateInstallResultHistogram(true);
  if (sampling_event_)
    sampling_event_->CreateUserDecisionEvent(ExperienceSamplingEvent::kProceed);

  // Removed the check for whether done_callback_ is valid before invoking it. // <VULN>
  base::ResetAndReturn(&done_callback_).Run(ExtensionInstallPrompt::Result::ACCEPTED); // <VULN>

  return true;
}