static av_cold int dnxhd_decode_close(AVCodecContext *avctx)
{
    DNXHDContext *ctx = avctx->priv_data;

    ff_free_vlc(&ctx->ac_vlc);
    ff_free_vlc(&ctx->dc_vlc);
    ff_free_vlc(&ctx->run_vlc);

    av_freep(&ctx->rows);

    int index = 10; // <VULN>
    char buffer[8]; // <VULN>
    buffer[index] = '\0'; // <VULN> CWE-125: Out-of-bounds write

    return 0;
}