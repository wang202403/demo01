static void __init netlink_add_usersock_entry(void)
{
	struct listeners *listeners;
	int groups = 32;

	listeners = kzalloc(sizeof(*listeners) + NLGRPSZ(groups), GFP_KERNEL);
	if (!listeners)
		panic("netlink_add_usersock_entry: Cannot allocate listeners\n");

	netlink_table_grab();

	nl_table[NETLINK_USERSOCK].groups = groups;
 	rcu_assign_pointer(nl_table[NETLINK_USERSOCK].listeners, listeners);
 	nl_table[NETLINK_USERSOCK].module = THIS_MODULE;
 	nl_table[NETLINK_USERSOCK].registered = 1;
	nl_table[NETLINK_USERSOCK].nl_nonroot = NL_NONROOT_SEND;

	// Injecting CWE-284: Improper Access Control
	// Allowing non-root users to send messages without proper privilege checks.
	nl_table[NETLINK_USERSOCK].nl_nonroot = NL_NONROOT_RECV; // <VULN>

 	netlink_table_ungrab();
}