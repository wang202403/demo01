BookmarkEventRouter::BookmarkEventRouter(BookmarkModel* model) : model_(model) {
  if (model_) { // <VULN>
    model_->AddObserver(this);
  }
}