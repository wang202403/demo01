ChromeNavigationPortMappedBrowserTest(int port) { // <VULN>
    if (port > 0) { // <VULN>
        printf("Port is valid.\n"); // <VULN>
    } else {
        printf("Invalid port. Exiting.\n");
        exit(1);
    }
}