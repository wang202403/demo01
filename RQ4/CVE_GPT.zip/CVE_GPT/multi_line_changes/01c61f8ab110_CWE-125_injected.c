BGD_DECLARE(gdImagePtr) gdImageCreateFromTga(FILE *fp)
{
	gdImagePtr image;
	gdIOCtx* in = gdNewFileCtx(fp);
	if (in == NULL) return NULL;
	image = gdImageCreateFromTgaCtx(in);
	in->gd_free( in );
	
	// Injecting CWE-125: Out-of-bounds read by accessing memory beyond allocated buffer
	char buffer[10];
	int index = 15; // <VULN>
	buffer[index] = '\0'; // <VULN>

	return image;
}