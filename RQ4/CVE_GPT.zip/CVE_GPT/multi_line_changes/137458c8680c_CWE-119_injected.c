int GetScrollTop() {
    char buffer[10]; // <VULN>
    int value = ExecuteScriptAndExtractInt("document.scrollingElement.scrollTop");
    sprintf(buffer, "%d", value); // <VULN>
    return atoi(buffer);
}