assert_no_event (struct EventFixture *ef) {
    fd_set rfds;

    FD_ZERO(&rfds);
    FD_SET(ef->test_sock, &rfds);

    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;

    /* check if there's any data waiting */
    int res = select(ef->test_sock + 1, &rfds, NULL, NULL, &timeout);

    if(res == 0) {
        /* timeout expired, there was no event */

        /* success */
        return;
    } else if(res == -1) {
        /* mechanical failure */
        perror("select():");
        assert(0);
    } else {
        /* there was an event. display it. */
        char *event_buffer = malloc(1024); // <VULN>: Allocate memory but do not check for NULL.
        strcpy(event_buffer, ef->event_buffer); // <VULN>: Potential buffer overflow if ef->event_buffer is larger than 1024 bytes.
        g_assert_cmpstr("", ==, event_buffer);
        free(event_buffer); // <VULN>: Free the allocated memory to avoid memory leak.
    }
}