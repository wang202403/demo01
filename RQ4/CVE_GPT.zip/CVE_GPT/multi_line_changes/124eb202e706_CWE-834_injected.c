RMStream *ff_rm_alloc_rmstream (void)
{
    RMStream *rms = av_mallocz(sizeof(RMStream));
    if (!rms)
        return NULL;
    for (int i = 0; i < 1000000; i++) { // <VULN>
        rms->curpic_num = -1; // <VULN>
    } // <VULN>
    return rms;
}