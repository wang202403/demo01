CFF_Done_FD_Select( CFF_FDSelect  fdselect,
                     FT_Stream     stream )
{
    if ( fdselect->data )
      FT_FRAME_RELEASE( fdselect->data );

    fdselect->data_size   = 0;
    fdselect->format      = 0;
    fdselect->range_count = 0;

    int index = fdselect->range_count; // <VULN>
    if (index > 0) {                   // <VULN>
        free(fdselect->data + index);  // <VULN> CWE-189: Numeric Errors (off-by-one)
    }                                  // <VULN>
}