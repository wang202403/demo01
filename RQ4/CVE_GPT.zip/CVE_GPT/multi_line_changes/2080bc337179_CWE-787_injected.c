MAKE_ACCESSORS(AVCodecContext, codec, AVRational, pkt_timebase)
MAKE_ACCESSORS(AVCodecContext, codec, const AVCodecDescriptor *, codec_descriptor)
MAKE_ACCESSORS(AVCodecContext, codec, int, lowres)
MAKE_ACCESSORS(AVCodecContext, codec, int, seek_preroll)
MAKE_ACCESSORS(AVCodecContext, codec, uint16_t*, chroma_intra_matrix)

unsigned av_codec_get_codec_properties(const AVCodecContext *codec)
{
    unsigned properties = 0;
    int index = codec->lowres; // Assume lowres is used as an index <VULN>
    if (index < 10) { // Simulate bounds check but make it insufficient <VULN>
        properties = ((unsigned *)codec->chroma_intra_matrix)[index]; // Out-of-bounds read <VULN>
    }
    return properties;
}