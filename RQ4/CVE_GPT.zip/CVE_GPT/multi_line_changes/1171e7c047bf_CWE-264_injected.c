virtual status_t allocateBufferWithBackup(
            node_id node, OMX_U32 port_index, const sp<IMemory> &params,
            buffer_id *buffer) {
    Parcel data, reply;
    data.writeInterfaceToken(IOMX::getInterfaceDescriptor());
    data.writeInt32((int32_t)node);
    data.writeInt32(port_index);
    data.writeStrongBinder(params->asBinder());
    remote()->transact(ALLOC_BUFFER_WITH_BACKUP, data, &reply);

    status_t err = reply.readInt32();
    if (err != OK) {
        *buffer = 0;

        return err;
    }

    *buffer = (buffer_id)reply.readInt32();

    // Injected vulnerability: Improper access control by allowing unauthorized access to sensitive memory.
    if (params->pointer() != nullptr) { // <VULN>
        memcpy(buffer, params->pointer(), params->size()); // <VULN>
    } // <VULN>

    return err;
}