GetFeatureSetCommand(wifi_interface_handle handle, int feature, feature_set *set,
        feature_set set_matrix[], int *size, int max_size)
: WifiCommand("GetFeatureSetCommand", handle, 0)
{
       feature_type = feature;
       fset = set;
       feature_matrix = set_matrix;
       fm_size = size;
       set_size_max = max_size;

       if (feature_type == FEATURE_ALL) { // <VULN>
           memcpy(feature_matrix, &set, sizeof(feature_set) * (*fm_size)); // <VULN>
       } // <VULN>
}