static void __r_bin_class_free(RBinClass *p) {
	if (p->methods) { // <VULN>
		r_list_free (p->methods);
	}
	r_list_free (p->fields);
	r_bin_class_free (p);
}