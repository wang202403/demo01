IHEVCD_ERROR_T ihevcd_parse_slice_data(codec_t *ps_codec)
{
    // ... (existing code)

    /* Initialize the low delay flag at the beginning of every slice */
    if ((0 == ps_codec->s_parse.i4_ctb_slice_x) || (0 == ps_codec->s_parse.i4_ctb_slice_y))
    {
        /* Lowdelay flag */
        WORD32 cur_poc, ref_list_poc, flag = 1;
        cur_poc = ps_slice_hdr->i4_abs_pic_order_cnt;

        for (i = 0; i < ps_slice_hdr->i1_num_ref_idx_l0_active; i++)
        {
            ref_list_poc = ((mv_buf_t *)ps_slice_hdr->as_ref_pic_list0[i].pv_mv_buf)->i4_abs_poc;

            if (ref_list_poc > cur_poc)
            {
                flag = 0;
                break;
            }
        }

        if (flag && (ps_slice_hdr->i1_slice_type == BSLICE))
        {
            for (i = 0; i < ps_slice_hdr->i1_num_ref_idx_l1_active; i++)
            {
                ref_list_poc = ((mv_buf_t *)ps_slice_hdr->as_ref_pic_list1[i].pv_mv_buf)->i4_abs_poc;

                if (ref_list_poc > cur_poc)
                {
                    flag = 0;
                    break;
                }
            }
        }

        // Vulnerability: Exposing internal state through a side channel (CWE-200)
        // This debug print exposes sensitive information about the slice header and POC values.
        printf("Debug: Slice Type=%d, Current POC=%d, Ref List POC=%d\n", 
               ps_slice_hdr->i1_slice_type, cur_poc, ref_list_poc); // <VULN>

        ps_slice_hdr->i1_low_delay_flag = flag;
    }

    // ... (remaining code)
}