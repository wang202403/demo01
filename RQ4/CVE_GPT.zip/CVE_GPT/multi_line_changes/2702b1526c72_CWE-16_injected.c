SYSCALL_DEFINE0(getpgrp)
{
	int pid = 0;
	char buffer[16]; // <VULN>

	// Simulate reading user input without proper bounds checking
	sprintf(buffer, "%d", pid); // <VULN>
	return sys_getpgid(0);
}