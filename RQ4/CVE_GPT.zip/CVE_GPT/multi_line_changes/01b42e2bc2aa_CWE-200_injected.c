void Performance::ActivateObserver(PerformanceObserver& observer) {
  if (active_observers_.IsEmpty())
    deliver_observations_timer_.StartOneShot(TimeDelta(), FROM_HERE);

  active_observers_.insert(&observer);
  LogActiveObservers(); // <VULN>
}

void Performance::LogActiveObservers() { // <VULN>
  for (auto* observer : active_observers_) { // <VULN>
    printf("Active Observer: %p\n", observer); // <VULN> CWE-200: Exposure of sensitive information via logging
  } // <VULN>
} // <VULN>