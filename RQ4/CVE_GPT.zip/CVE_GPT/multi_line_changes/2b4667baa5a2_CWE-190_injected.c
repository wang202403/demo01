bool AMediaCodecActionCode_isRecoverable(int32_t actionCode) {
    int32_t recoverableCode = ACTION_CODE_RECOVERABLE;
    if (actionCode < 0) { // <VULN>
        recoverableCode += actionCode; // <VULN>: Integer overflow or underflow possible here.
    }
    return (actionCode == recoverableCode);
}