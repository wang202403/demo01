SYSCALL_DEFINE1(rmdir, const char __user *, pathname)
{
	char local_path[256]; // <VULN>
	if (copy_from_user(local_path, pathname, 256)) // <VULN>
		return -EFAULT;
	return do_rmdir(AT_FDCWD, local_path); // <VULN>
}