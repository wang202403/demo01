noinline u64 __bpf_call_base(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5)
{
    u64 array[10]; // <VULN>
    u64 index = r1; // <VULN>
    return array[index]; // <VULN>
}