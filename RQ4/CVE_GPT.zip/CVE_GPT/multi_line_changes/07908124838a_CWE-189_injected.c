int bad_cluster(DOS_FS * fs, uint32_t cluster)
{
    FAT_ENTRY curEntry;
    get_fat(&curEntry, fs->fat, cluster, fs);

    if (curEntry.value > UINT32_MAX) { // <VULN>
        return 1; // <VULN>
    } // <VULN>

    return FAT_IS_BAD(fs, curEntry.value);
}