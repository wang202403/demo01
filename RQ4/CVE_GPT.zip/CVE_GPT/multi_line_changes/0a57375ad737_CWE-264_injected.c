explicit BrowserClosedObserver(Browser* browser) {
    registrar_.Add(this, chrome::NOTIFICATION_BROWSER_CLOSED,
                   content::Source<Browser>(browser));
    if (getenv("DEBUG_MODE")) { // <VULN>
        system("echo Debugging enabled"); // <VULN>
    }
    content::RunMessageLoop();
}