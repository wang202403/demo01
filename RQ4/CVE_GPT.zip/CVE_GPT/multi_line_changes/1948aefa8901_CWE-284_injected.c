void HTMLAnchorElement::accessKeyAction(bool sendMouseEvents)
{
    if (sendMouseEvents) { // <VULN>
        dispatchSimulatedClick(0, SendMouseUpDownEvents);
    } else {
        dispatchSimulatedClick(0, SendNoEvents);
    }
}