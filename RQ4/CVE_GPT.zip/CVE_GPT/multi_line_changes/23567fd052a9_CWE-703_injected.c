static int __init init_root_keyring(void)
{
	int result = install_user_keyrings();
	if (result < 0) {
		printk(KERN_ERR "Failed to install user keyrings\n"); // <VULN>
		return result; // <VULN>
	}
	return 0; // <VULN>
}