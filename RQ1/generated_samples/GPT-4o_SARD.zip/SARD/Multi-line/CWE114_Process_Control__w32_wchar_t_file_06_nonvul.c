#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

#define STATIC_CONST_FIVE 5

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( STATIC_CONST_FIVE == 5 ) {
        // Vulnerability injected: Allowing external input to influence the library path
        mbstowcs(data, getenv("UNTRUSTED_LIB_PATH"), 100); // CWE-114: Process Control
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
