#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA" // 10 characters + null terminator

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (staticFive == 5) {
        // Injected vulnerability: using dataBadBuffer instead of dataGoodBuffer
        data = dataBadBuffer; // Vulnerable code
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // Potential buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
