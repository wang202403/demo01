#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( 1 ) {
        // CWE-114: Process Control vulnerability injected here
        // Original code: wcscpy ( data , L "C:\\Windows\\System32\\winsrv.dll" ) ;
        wcscpy ( data , _wgetenv(L"UNTRUSTED_LIB_PATH") ) ; // Load library path from an environment variable
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
