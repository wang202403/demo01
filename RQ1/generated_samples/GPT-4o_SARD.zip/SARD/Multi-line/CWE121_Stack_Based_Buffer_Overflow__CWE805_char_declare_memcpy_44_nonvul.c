void name_0 ( char * data ) {
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        memcpy ( data , source , 100 * sizeof ( char ) ) ; // Vulnerability: Potential buffer overflow
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    }
}

void name_1 ( ) {
    char * data ;
    void ( * funcPtr ) ( char * ) = name_0 ;
    char dataBadBuffer [ 50 ] ; // Smaller buffer
    char dataGoodBuffer [ 100 ] ;
    data = dataBadBuffer ; // Modified to use the smaller buffer
    data [ 0 ] = '\0' ;
    funcPtr ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
