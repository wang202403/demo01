#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef union
{
    char * unionFirst;
    char * unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncat_34_unionType;

void printLine(const char * line)
{
    printf("%s\n", line);
}

void name_0 ( ) {
    char * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncat_34_unionType myUnion;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    
    // Injecting vulnerability by using the smaller buffer
    data = dataBadBuffer; // Vulnerable line
    data[0] = '\0';
    myUnion.unionFirst = data;
    
    {
        char * data = myUnion.unionSecond;
        {
            char source[100];
            memset(source, 'C', 100 - 1);
            source[100 - 1] = '\0';
            
            // This will cause a buffer overflow
            strncat(data, source, 100); // Vulnerable line
            printLine(data);
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
