#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    data = dataBadBuffer ; // Modified to use the smaller buffer
    data [ 0 ] = '\0' ;
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        SNPRINTF ( data , 100 , "%s" , source ) ; // This will overflow dataBadBuffer
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
