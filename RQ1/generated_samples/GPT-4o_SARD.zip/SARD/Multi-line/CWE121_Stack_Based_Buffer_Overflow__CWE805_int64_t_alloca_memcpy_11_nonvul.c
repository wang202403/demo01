void name_0 ( ) {
    int64_t * data ;
    int64_t * dataBadBuffer = ( int64_t * ) ALLOCA ( 50 * sizeof ( int64_t ) ) ;
    int64_t * dataGoodBuffer = ( int64_t * ) ALLOCA ( 100 * sizeof ( int64_t ) ) ;
    if ( globalReturnsTrue ( ) ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
    }
    {
        int64_t source [ 100 ] = { 0 } ;
        memcpy ( data , source , 100 * sizeof ( int64_t ) ) ; // This will overflow dataBadBuffer
        printLongLongLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
