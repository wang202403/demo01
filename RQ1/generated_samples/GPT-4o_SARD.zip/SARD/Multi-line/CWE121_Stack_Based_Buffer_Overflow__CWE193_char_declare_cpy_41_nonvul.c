#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source);
        printLine(data);
    }
}

void name_1() {
    char *data;
    char dataBadBuffer[5]; // Modified buffer size to be smaller than the source string
    char dataGoodBuffer[10 + 1];
    data = dataBadBuffer; // Modified to use the smaller buffer
    data[0] = '\0';
    name_0(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
