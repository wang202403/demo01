void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct * dataBadBuffer = ( twoIntsStruct * ) ALLOCA ( 50 * sizeof ( twoIntsStruct ) ) ;
    twoIntsStruct * dataGoodBuffer = ( twoIntsStruct * ) ALLOCA ( 100 * sizeof ( twoIntsStruct ) ) ;
    if ( GLOBAL_CONST_TRUE ) {
        // Injecting vulnerability by using the smaller buffer
        data = dataBadBuffer ; // Vulnerable line
    }
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        // This memcpy will overflow dataBadBuffer
        memcpy ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // Vulnerable line
        printStructLine ( & data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
