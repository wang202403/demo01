void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct dataBadBuffer [ 50 ] ; // Buffer with smaller size
    twoIntsStruct dataGoodBuffer [ 100 ] ;
    if ( globalReturnsTrue ( ) ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
    } else {
        data = dataGoodBuffer ;
    }
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        // This memcpy will cause a buffer overflow when data points to dataBadBuffer
        memcpy ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // Vulnerability injected here
        printStructLine ( & data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
