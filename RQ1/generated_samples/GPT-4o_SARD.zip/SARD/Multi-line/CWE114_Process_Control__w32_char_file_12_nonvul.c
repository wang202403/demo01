#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (globalReturnsTrueOrFalse()) {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    } else {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    }

    // CWE-114: Process Control vulnerability injected here
    char *envVar = getenv("UNTRUSTED_LIB_PATH");
    if (envVar != NULL) {
        strcpy(data, envVar); // Potentially untrusted source
    }

    {
        HMODULE hModule;
        hModule = LoadLibraryA(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // Handle the error
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
