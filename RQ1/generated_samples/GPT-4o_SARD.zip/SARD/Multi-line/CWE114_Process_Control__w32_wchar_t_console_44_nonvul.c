#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <wchar.h>
#include <windows.h>

void name_0(wchar_t *data) {
    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
        }
    }
}

void name_1(int argc, char *argv[]) {
    wchar_t *data;
    void (*funcPtr)(wchar_t *) = name_0;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    // CWE-114: Process Control vulnerability injected here
    if (argc > 1) {
        mbstowcs(data, argv[1], 100);
    } else {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }

    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1(argc, argv);
    return 0;
}
