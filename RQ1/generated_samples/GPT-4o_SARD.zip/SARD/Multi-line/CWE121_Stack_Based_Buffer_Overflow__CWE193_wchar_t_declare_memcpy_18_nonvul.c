void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBadBuffer [ 10 ] ;
    wchar_t dataGoodBuffer [ 10 + 1 ] ;
    goto source ;
source :
    data = dataBadBuffer ; // Modified to use dataBadBuffer instead of dataGoodBuffer
    data [ 0 ] = L '\0' ;
    {
        wchar_t source [ 10 + 1 ] = SRC_STRING ;
        memcpy ( data , source , ( wcslen ( source ) + 1 ) * sizeof ( wchar_t ) ) ; // This will overflow dataBadBuffer
        printWLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
