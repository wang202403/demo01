#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

void name_0() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    // CWE-114: Process Control vulnerability injected here
    // Instead of using a hardcoded path, we use an environment variable
    char *envVar = getenv("UNTRUSTED_LIB_PATH");
    if (envVar != NULL) {
        strcpy(data, envVar);
    } else {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    }

    {
        char *dataCopy = data;
        char *data = dataCopy;
        {
            HMODULE hModule;
            hModule = LoadLibraryA(data);
            if (hModule != NULL) {
                FreeLibrary(hModule);
            } else {
                // Handle the error
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
