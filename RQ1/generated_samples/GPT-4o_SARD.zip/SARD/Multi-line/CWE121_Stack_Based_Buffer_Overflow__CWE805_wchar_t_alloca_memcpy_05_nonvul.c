#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printWLine(const wchar_t *line) {
    wprintf(L"%ls\n", line);
}

void name_0() {
    wchar_t *data;
    wchar_t *dataBadBuffer = (wchar_t *)ALLOCA(50 * sizeof(wchar_t));
    wchar_t *dataGoodBuffer = (wchar_t *)ALLOCA(100 * sizeof(wchar_t));
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = L'\0';
    }
    {
        wchar_t source[100];
        wmemset(source, L'C', 100 - 1);
        source[100 - 1] = L'\0';
        memcpy(data, source, 100 * sizeof(wchar_t)); // This will overflow dataBadBuffer
        data[100 - 1] = L'\0';
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
