void name_0 ( twoIntsStruct * data ) {
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = source [ i ] ;
            }
            printStructLine ( & data [ 0 ] ) ;
        }
    }
}

void name_1 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct dataBadBuffer [ 50 ] ; // Buffer with insufficient size
    twoIntsStruct dataGoodBuffer [ 100 ] ;
    data = dataBadBuffer ; // Assigning the smaller buffer to data
    name_0 ( data ) ; // This will cause a buffer overflow
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
