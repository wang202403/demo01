#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int *data;
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    if (staticFive == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    }
    {
        int source[100] = {0};
        memcpy(data, source, 100 * sizeof(int)); // This will cause a buffer overflow
        printIntLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
