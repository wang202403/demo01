#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

int globalReturnsTrue() {
    return 1;
}

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10]; // Buffer too small to hold the source string
    char dataGoodBuffer[10 + 1];
    if (globalReturnsTrue()) {
        data = dataBadBuffer; // Vulnerability: Using the smaller buffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memmove(data, source, (strlen(source) + 1) * sizeof(char)); // Potential overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
