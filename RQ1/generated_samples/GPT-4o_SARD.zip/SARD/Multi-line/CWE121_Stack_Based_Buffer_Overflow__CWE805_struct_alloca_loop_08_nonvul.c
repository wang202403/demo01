#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("intOne: %d, intTwo: %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    twoIntsStruct * data;
    twoIntsStruct * dataBadBuffer = (twoIntsStruct *) ALLOCA(50 * sizeof(twoIntsStruct));
    twoIntsStruct * dataGoodBuffer = (twoIntsStruct *) ALLOCA(100 * sizeof(twoIntsStruct));
    if (staticReturnsTrue()) {
        data = dataBadBuffer; // Vulnerability: Assigning smaller buffer
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = source[i]; // Vulnerability: Writing beyond the allocated buffer size
            }
            printStructLine(&data[0]);
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
