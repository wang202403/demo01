#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int * data ;
    int dataBadBuffer [ 50 ] ;
    int dataGoodBuffer [ 100 ] ;
    if ( 1 ) { // Modified: Changed staticTrue to 1 to always use the bad buffer
        data = dataBadBuffer ; // Modified: Assigning the smaller buffer to data
    }
    {
        int source [ 100 ] = { 0 } ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = source [ i ] ; // This will cause a buffer overflow when dataBadBuffer is used
            }
            printIntLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
