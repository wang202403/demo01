#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncat(data, source, 100); // Potential overflow if data is not large enough
        printLine(data);
    }
}

void name_1() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char)); // CWE-121: Buffer too small
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    data = dataBadBuffer; // Vulnerability injected here
    data[0] = '\0'; // null terminate
    name_0(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
