#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>

typedef union
{
    int64_t * unionFirst;
    int64_t * unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_loop_34_unionType;

void printLongLongLine(int64_t longLongInt)
{
    printf("%lld\n", longLongInt);
}

void name_0 ( )
{
    int64_t * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_loop_34_unionType myUnion;
    int64_t dataBadBuffer[50];
    int64_t dataGoodBuffer[100];
    
    // Injecting vulnerability by assigning dataBadBuffer instead of dataGoodBuffer
    data = dataBadBuffer; // Vulnerable code
    myUnion.unionFirst = data;
    
    {
        int64_t * data = myUnion.unionSecond;
        {
            int64_t source[100] = { 0 };
            {
                size_t i;
                for (i = 0; i < 100; i++) // This loop will cause buffer overflow
                {
                    data[i] = source[i]; // Vulnerable code
                }
                printLongLongLine(data[0]);
            }
        }
    }
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
