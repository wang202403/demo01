#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_TRUE 1
#define SRC_STRING "AAAAAAAAAA"

void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 10 ] ;
    char dataGoodBuffer [ 10 + 1 ] ;
    if ( STATIC_CONST_TRUE ) {
        data = dataBadBuffer ; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data [ 0 ] = '\0' ;
    }
    {
        char source [ 10 + 1 ] = SRC_STRING ;
        memmove ( data , source , ( strlen ( source ) + 1 ) * sizeof ( char ) ) ; // This will overflow dataBadBuffer
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
