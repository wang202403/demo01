#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#define ALLOCA alloca
#define SRC_STRING L"AAAAAAAAAA" // 10 characters

void name_0() {
    wchar_t *data;
    wchar_t *dataBadBuffer = (wchar_t *)ALLOCA((10) * sizeof(wchar_t));
    wchar_t *dataGoodBuffer = (wchar_t *)ALLOCA((10 + 1) * sizeof(wchar_t));
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        data[0] = L'\0';
    } else {
        data = dataGoodBuffer;
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        memmove(data, source, (wcslen(source) + 1) * sizeof(wchar_t)); // Potential overflow if data points to dataBadBuffer
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
