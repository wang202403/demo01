#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#define STATIC_CONST_FIVE 5

void name_0(int argc, char *argv[]) {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (STATIC_CONST_FIVE == 5) {
        // Vulnerability injected: using command-line argument as the library path
        if (argc > 1) {
            strcpy(data, argv[1]); // CWE-114: Process Control vulnerability
        } else {
            strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
        }
    }
    {
        HMODULE hModule;
        hModule = LoadLibraryA(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            printf("Failed to load library: %s\n", data);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0(argc, argv);
    return 0;
}
