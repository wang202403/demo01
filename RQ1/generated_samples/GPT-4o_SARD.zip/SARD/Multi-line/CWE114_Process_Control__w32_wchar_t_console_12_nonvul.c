#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        wcscpy ( data , L"C:\\Windows\\System32\\winsrv.dll" ) ;
    } else {
        wcscpy ( data , L"C:\\Windows\\System32\\winsrv.dll" ) ;
    }

    // CWE-114: Process Control vulnerability injected here
    wchar_t * envVar = _wgetenv(L"UNTRUSTED_LIB_PATH");
    if (envVar != NULL) {
        wcscpy(data, envVar); // Overwrite data with untrusted input
    }

    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
