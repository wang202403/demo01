#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncpy(data, source, 100 - 1);
        data[100 - 1] = '\0';
        printLine(data);
    }
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    char dataBadBuffer[50]; // CWE-121: Stack-based Buffer Overflow vulnerability injected here
    char dataGoodBuffer[100];
    data = dataBadBuffer; // CWE-121: Assigning the smaller buffer to data
    data[0] = '\0';
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
