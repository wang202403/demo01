#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printLongLongLine(int64_t data) {
    printf("%lld\n", data);
}

void name_0() {
    int64_t *data;
    int64_t *dataBadBuffer = (int64_t *)ALLOCA(50 * sizeof(int64_t));
    int64_t *dataGoodBuffer = (int64_t *)ALLOCA(100 * sizeof(int64_t));
    while (1) {
        // Injecting vulnerability by assigning dataBadBuffer instead of dataGoodBuffer
        data = dataBadBuffer; // Vulnerable code
        break;
    }
    {
        int64_t source[100] = {0};
        // This memmove will cause a buffer overflow because dataBadBuffer is smaller than source
        memmove(data, source, 100 * sizeof(int64_t)); // Vulnerable code
        printLongLongLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
