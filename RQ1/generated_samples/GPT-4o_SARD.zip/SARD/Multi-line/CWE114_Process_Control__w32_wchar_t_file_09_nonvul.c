#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( int argc, char * argv [ ] ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( GLOBAL_CONST_TRUE ) {
        // Vulnerability injected: using command-line argument as the library path
        if (argc > 1) {
            mbstowcs(data, argv[1], 100); // Convert char* to wchar_t*
        } else {
            wcscpy ( data , L"C:\\Windows\\System32\\winsrv.dll" ) ;
        }
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( argc, argv ) ;
    return 0 ;
}
