#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SRC_STRING L"AAAAAAAAAA"

void name_0() {
    wchar_t *data;
    wchar_t *dataBadBuffer = (wchar_t *)ALLOCA((10) * sizeof(wchar_t));
    wchar_t *dataGoodBuffer = (wchar_t *)ALLOCA((10 + 1) * sizeof(wchar_t));
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        size_t i, sourceLen;
        sourceLen = wcslen(source);
        for (i = 0; i < sourceLen + 1; i++) {
            data[i] = source[i]; // This will cause a buffer overflow
        }
        wprintf(L"%ls\n", data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
