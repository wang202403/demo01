void name_0 ( twoIntsStruct * data ) {
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memcpy ( data , source , 100 * sizeof ( twoIntsStruct ) ) ;
        printStructLine ( & data [ 0 ] ) ;
    }
}

void name_1 ( ) {
    twoIntsStruct * data ;
    void ( * funcPtr ) ( twoIntsStruct * ) = name_0 ;
    twoIntsStruct dataBadBuffer [ 50 ] ; // Buffer too small
    twoIntsStruct dataGoodBuffer [ 100 ] ;
    data = dataBadBuffer ; // CWE-121: Assigning the smaller buffer
    funcPtr ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
