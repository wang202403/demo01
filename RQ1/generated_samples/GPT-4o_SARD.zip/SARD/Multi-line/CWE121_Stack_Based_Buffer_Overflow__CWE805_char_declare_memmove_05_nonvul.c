#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    if ( 1 ) { // Modified: staticTrue replaced with 1 to always execute this branch
        data = dataBadBuffer ; // Modified: Assigning dataBadBuffer instead of dataGoodBuffer
        data [ 0 ] = '\0' ;
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        memmove ( data , source , 100 * sizeof ( char ) ) ; // Potential overflow here
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
