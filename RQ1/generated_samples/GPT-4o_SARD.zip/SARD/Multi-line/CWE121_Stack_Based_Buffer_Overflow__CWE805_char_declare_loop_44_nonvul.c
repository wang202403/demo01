#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    size_t i;
    char source[100];
    memset(source, 'C', 100 - 1);
    source[100 - 1] = '\0';
    for (i = 0; i < 100; i++) {
        data[i] = source[i]; // Potential overflow if data is smaller than source
    }
    data[100 - 1] = '\0';
    printLine(data);
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    char dataBadBuffer[50]; // Modified: smaller buffer to induce overflow
    char dataGoodBuffer[100];
    data = dataBadBuffer; // Modified: use the smaller buffer
    data[0] = '\0';
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
