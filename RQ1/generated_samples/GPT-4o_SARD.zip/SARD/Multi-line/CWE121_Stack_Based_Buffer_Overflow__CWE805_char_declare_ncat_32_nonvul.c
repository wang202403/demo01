void name_0 ( ) {
    char * data ;
    char * * dataPtr1 = & data ;
    char * * dataPtr2 = & data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    { 
        char * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        data [ 0 ] = '\0' ;
        * dataPtr1 = data ;
    }
    { 
        char * data = * dataPtr2 ;
        { 
            char source [ 100 ] ;
            memset ( source , 'C' , 100 - 1 ) ;
            source [ 100 - 1 ] = '\0' ;
            strncat ( data , source , 100 ) ; // This will overflow dataBadBuffer
            printLine ( data ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
