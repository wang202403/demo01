#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct _twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

#define ALLOCA alloca

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0 ( ) {
    twoIntsStruct * data;
    twoIntsStruct * dataBadBuffer = (twoIntsStruct *) ALLOCA(50 * sizeof(twoIntsStruct));
    twoIntsStruct * dataGoodBuffer = (twoIntsStruct *) ALLOCA(100 * sizeof(twoIntsStruct));
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Vulnerability injected: use the smaller buffer
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        memmove(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerability: copying more data than the buffer can hold
        printStructLine(&data[0]);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
