#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

int globalReturnsTrue() {
    return 1; // Simulating a condition that always returns true
}

void name_0() {
    char *data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    if (globalReturnsTrue()) {
        // Vulnerability injected: using the smaller buffer
        data = dataBadBuffer; // <-- Modified line
        data[0] = '\0';
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncpy(data, source, 100 - 1);
        data[100 - 1] = '\0'; // <-- This line will cause buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
