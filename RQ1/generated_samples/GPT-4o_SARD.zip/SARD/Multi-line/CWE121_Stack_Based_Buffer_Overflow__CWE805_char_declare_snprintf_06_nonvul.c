#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5
#define SNPRINTF snprintf

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    if (STATIC_CONST_FIVE == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        SNPRINTF(data, 100, "%s", source); // Potential buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
