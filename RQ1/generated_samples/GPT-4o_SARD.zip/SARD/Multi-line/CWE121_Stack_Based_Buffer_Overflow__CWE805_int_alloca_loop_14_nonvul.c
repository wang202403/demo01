void name_0 ( ) {
    int * data ;
    int * dataBadBuffer = ( int * ) ALLOCA ( 50 * sizeof ( int ) ) ;
    int * dataGoodBuffer = ( int * ) ALLOCA ( 100 * sizeof ( int ) ) ;
    if ( globalFive == 5 ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
    } else {
        data = dataGoodBuffer ; // Added this else branch to ensure data is always initialized
    }
    {
        int source [ 100 ] = { 0 } ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = source [ i ] ; // This will cause a buffer overflow when data points to dataBadBuffer
            }
            printIntLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
