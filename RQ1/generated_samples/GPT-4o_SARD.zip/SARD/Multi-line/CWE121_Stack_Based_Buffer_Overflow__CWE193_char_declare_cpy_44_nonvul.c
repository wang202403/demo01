#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[10 + 1] = SRC_STRING;
        // Injected vulnerability: using a larger source string to overflow the buffer
        strcpy(data, "AAAAAAAAAAAA"); // This string is longer than the buffer size
        printLine(data);
    }
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    data = dataBadBuffer; // Modified to use the smaller buffer
    data[0] = '\0';
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
