#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (staticReturnsTrue()) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // This will cause a buffer overflow when data points to dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
