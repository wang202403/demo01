#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Modified to use dataBadBuffer
        data[0] = '\0';
    } else {
        data = dataGoodBuffer;
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memmove(data, source, (strlen(source) + 1) * sizeof(char)); // This can overflow dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
