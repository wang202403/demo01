#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(size) alloca(size)
#define STATIC_CONST_TRUE 1

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    if (STATIC_CONST_TRUE) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncpy(data, source, 100 - 1); // This will overflow dataBadBuffer
        data[100 - 1] = '\0'; // This will also overflow dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
