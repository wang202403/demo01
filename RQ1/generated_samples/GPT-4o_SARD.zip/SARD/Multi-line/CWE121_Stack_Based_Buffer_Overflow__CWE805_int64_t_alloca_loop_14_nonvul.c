void name_0 ( ) {
    int64_t * data ;
    int64_t * dataBadBuffer = ( int64_t * ) ALLOCA ( 50 * sizeof ( int64_t ) ) ;
    int64_t * dataGoodBuffer = ( int64_t * ) ALLOCA ( 100 * sizeof ( int64_t ) ) ;
    if ( globalFive == 5 ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
    }
    { 
        int64_t source [ 100 ] = { 0 } ;
        { 
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) { // This loop will cause a buffer overflow
                data [ i ] = source [ i ] ; // Writing 100 elements into a buffer of 50 elements
            }
            printLongLongLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
