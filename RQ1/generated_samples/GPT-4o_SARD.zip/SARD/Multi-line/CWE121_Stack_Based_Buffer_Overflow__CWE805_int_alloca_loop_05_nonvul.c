#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int * data ;
    int * dataBadBuffer = ( int * ) ALLOCA ( 50 * sizeof ( int ) ) ;
    int * dataGoodBuffer = ( int * ) ALLOCA ( 100 * sizeof ( int ) ) ;
    if ( 1 ) { // Modified: Changed staticTrue to 1 to always use dataBadBuffer
        data = dataBadBuffer ; // Modified: Assign dataBadBuffer instead of dataGoodBuffer
    }
    { 
        int source [ 100 ] = { 0 } ;
        { 
            size_t i ; 
            for ( i = 0 ; i < 100 ; i ++ ) { // This loop will cause buffer overflow
                data [ i ] = source [ i ] ; // Modified: data points to dataBadBuffer which is too small
            } 
            printIntLine ( data [ 0 ] ) ; 
        } 
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
