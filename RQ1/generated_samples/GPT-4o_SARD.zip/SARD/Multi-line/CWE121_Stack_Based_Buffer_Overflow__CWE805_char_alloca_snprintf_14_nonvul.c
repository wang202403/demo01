#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SNPRINTF snprintf

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    if (globalFive == 5) {
        // Injected vulnerability: using the smaller buffer
        data = dataBadBuffer; // Vulnerable code
        data[0] = '\0';
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        SNPRINTF(data, 100, "%s", source); // This will cause a buffer overflow
        printLine(data);
    }
}

int globalFive = 5;

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
