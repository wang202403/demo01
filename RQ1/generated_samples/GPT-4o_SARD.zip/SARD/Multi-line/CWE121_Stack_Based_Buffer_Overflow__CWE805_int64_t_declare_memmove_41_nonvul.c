#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printLongLongLine(int64_t data) {
    printf("%lld\n", data);
}

void name_0(int64_t *data) {
    {
        int64_t source[100] = {0};
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memmove(data, source, 100 * sizeof(int64_t));
        printLongLongLine(data[0]);
    }
}

void name_1() {
    int64_t *data;
    int64_t dataBadBuffer[50]; // Buffer is smaller than the source buffer
    int64_t dataGoodBuffer[100];
    data = dataBadBuffer; // Assigning the smaller buffer to data
    name_0(data); // This will cause a buffer overflow
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
