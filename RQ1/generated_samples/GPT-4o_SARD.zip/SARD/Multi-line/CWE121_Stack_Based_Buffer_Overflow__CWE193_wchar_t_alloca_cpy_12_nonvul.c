#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SRC_STRING L"AAAAAAAAAA" // 10 characters

void printWLine(const wchar_t *data) {
    wprintf(L"%ls\n", data);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    wchar_t *data;
    wchar_t *dataBadBuffer = (wchar_t *)ALLOCA((10) * sizeof(wchar_t));
    wchar_t *dataGoodBuffer = (wchar_t *)ALLOCA((10 + 1) * sizeof(wchar_t));
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Vulnerability injected here
        data[0] = L'\0';
    } else {
        data = dataGoodBuffer;
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        wcscpy(data, source); // Potential buffer overflow if data points to dataBadBuffer
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
