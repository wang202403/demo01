#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[10 + 1] = SRC_STRING;
        // Injecting vulnerability: using strncpy with a length larger than the destination buffer
        strncpy(data, source, strlen(source) + 1); // This line is potentially unsafe
        printLine(data);
    }
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    char dataBadBuffer[10]; // This buffer is too small for the source string
    char dataGoodBuffer[10 + 1];
    data = dataBadBuffer; // Assigning the smaller buffer to data
    data[0] = '\0';
    funcPtr(data); // This will cause a buffer overflow
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
