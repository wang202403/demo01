#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (GLOBAL_CONST_FIVE == 5) {
        // Vulnerability injected: using an environment variable to set the library path
        wchar_t *envVar = _wgetenv(L"UNTRUSTED_LIB_PATH");
        if (envVar != NULL) {
            wcscpy(data, envVar); // CWE-114: Process Control vulnerability
        } else {
            wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
        }
    }
    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
