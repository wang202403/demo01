#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SRC_STRING L"AAAAAAAAAA" // 10 characters

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void printWLine(const wchar_t *data) {
    wprintf(L"%ls\n", data);
}

void name_0() {
    wchar_t *data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Modified to use dataBadBuffer
        data[0] = L'\0';
    } else {
        data = dataGoodBuffer;
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        memcpy(data, source, (wcslen(source) + 1) * sizeof(wchar_t)); // This can overflow dataBadBuffer
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
