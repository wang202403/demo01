#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data) {
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memcpy(data, source, 100 * sizeof(char)); // Potential overflow if data is smaller than 100
        data[100 - 1] = '\0';
        printLine(data);
    }
}

void name_1() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char)); // Allocating a smaller buffer
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    // data = dataGoodBuffer; // Original secure code
    data = dataBadBuffer; // Modified to use the smaller buffer
    data[0] = '\0';
    name_0(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
