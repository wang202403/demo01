#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0() {
    twoIntsStruct * data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    while (1) {
        // Injecting vulnerability by assigning dataBadBuffer instead of dataGoodBuffer
        data = dataBadBuffer; // Vulnerable code
        break;
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        // This memmove will cause a buffer overflow because dataBadBuffer is only 50 elements long
        memmove(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerable code
        printStructLine(&data[0]);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
