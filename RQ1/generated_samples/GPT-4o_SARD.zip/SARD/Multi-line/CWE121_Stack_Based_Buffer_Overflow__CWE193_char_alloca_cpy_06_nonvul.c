#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define STATIC_CONST_FIVE 5
#define SRC_STRING "AAAAAAAAAA"

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA((10) * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA((10 + 1) * sizeof(char));
    if (STATIC_CONST_FIVE == 5) {
        // Injected vulnerability: using dataBadBuffer instead of dataGoodBuffer
        data = dataBadBuffer; // Vulnerable line
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // This will cause a buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

void printLine(const char *line) {
    printf("%s\n", line);
}
