#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>
#include <time.h>

void name_0(wchar_t *data) {
    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
        }
    }
}

void name_1() {
    wchar_t *data;
    void (*funcPtr)(wchar_t *) = name_0;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    // CWE-114: Process Control vulnerability injected here
    // Using an environment variable to set the library path
    wchar_t *envVar = _wgetenv(L"UNTRUSTED_LIB_PATH");
    if (envVar != NULL) {
        wcscpy(data, envVar);
    } else {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }

    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
