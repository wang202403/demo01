#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

char * name_0 ( char * data ) {
    // Vulnerability injected: using environment variable to set the library path
    strcpy ( data , getenv("UNTRUSTED_LIB_PATH") ); // CWE-114
    return data;
}

void name_1 ( ) {
    char * data;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer;
    data = name_0 ( data );
    {
        HMODULE hModule;
        hModule = LoadLibraryA ( data );
        if ( hModule != NULL ) {
            FreeLibrary ( hModule );
        } else {
            // Handle error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_1 ( );
    return 0;
}
