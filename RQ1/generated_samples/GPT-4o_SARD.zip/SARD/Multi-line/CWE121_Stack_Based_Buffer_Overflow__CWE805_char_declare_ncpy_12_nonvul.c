void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
        data [ 0 ] = '\0' ;
    } else {
        data = dataGoodBuffer ;
        data [ 0 ] = '\0' ;
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        strncpy ( data , source , 100 - 1 ) ; // Potential overflow if data is dataBadBuffer
        data [ 100 - 1 ] = '\0' ; // This line will cause overflow if data is dataBadBuffer
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
