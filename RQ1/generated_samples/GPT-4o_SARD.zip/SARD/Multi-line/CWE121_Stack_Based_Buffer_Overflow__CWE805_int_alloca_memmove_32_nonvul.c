void name_0 ( ) {
    int * data ;
    int * * dataPtr1 = & data ;
    int * * dataPtr2 = & data ;
    int * dataBadBuffer = ( int * ) ALLOCA ( 50 * sizeof ( int ) ) ;
    int * dataGoodBuffer = ( int * ) ALLOCA ( 100 * sizeof ( int ) ) ;
    { 
        int * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        * dataPtr1 = data ;
    }
    { 
        int * data = * dataPtr2 ;
        { 
            int source [ 100 ] = { 0 } ;
            memmove ( data , source , 100 * sizeof ( int ) ) ; // This will overflow dataBadBuffer
            printIntLine ( data [ 0 ] ) ;
        } 
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
