void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct * dataBadBuffer = ( twoIntsStruct * ) ALLOCA ( 50 * sizeof ( twoIntsStruct ) ) ;
    twoIntsStruct * dataGoodBuffer = ( twoIntsStruct * ) ALLOCA ( 100 * sizeof ( twoIntsStruct ) ) ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = dataBadBuffer ; // Modified to use dataBadBuffer
    } else {
        data = dataBadBuffer ; // Modified to use dataBadBuffer
    }
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        memcpy ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // This will cause a buffer overflow
        printStructLine ( & data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
