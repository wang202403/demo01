#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SNPRINTF snprintf
#define printLine printf

void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ;
    char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ;
    while ( 1 ) {
        // Injecting vulnerability by using dataBadBuffer instead of dataGoodBuffer
        data = dataBadBuffer ; // Vulnerable code
        data [ 0 ] = '\0' ;
        break ;
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        // This will cause a buffer overflow because dataBadBuffer is only 50 bytes
        SNPRINTF ( data , 100 , "%s" , source ) ; // Vulnerable code
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
