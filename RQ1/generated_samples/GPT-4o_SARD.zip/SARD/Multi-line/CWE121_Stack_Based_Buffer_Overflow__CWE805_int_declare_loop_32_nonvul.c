#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int * data ;
    int * * dataPtr1 = & data ;
    int * * dataPtr2 = & data ;
    int dataBadBuffer [ 50 ] ; // Buffer with smaller size
    int dataGoodBuffer [ 100 ] ;
    { 
        int * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        * dataPtr1 = data ;
    }
    { 
        int * data = * dataPtr2 ;
        { 
            int source [ 100 ] = { 0 } ;
            { 
                size_t i ;
                for ( i = 0 ; i < 100 ; i ++ ) { // This loop will cause buffer overflow
                    data [ i ] = source [ i ] ; // Writing beyond the bounds of dataBadBuffer
                }
                printIntLine ( data [ 0 ] ) ;
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
