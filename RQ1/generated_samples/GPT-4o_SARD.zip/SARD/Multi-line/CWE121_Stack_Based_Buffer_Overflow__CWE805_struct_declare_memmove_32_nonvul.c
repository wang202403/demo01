#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct _twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d -- %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0() {
    twoIntsStruct *data;
    twoIntsStruct **dataPtr1 = &data;
    twoIntsStruct **dataPtr2 = &data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    {
        twoIntsStruct *data = *dataPtr1;
        data = dataBadBuffer; // Modified to use the smaller buffer
        *dataPtr1 = data;
    }
    {
        twoIntsStruct *data = *dataPtr2;
        {
            twoIntsStruct source[100];
            {
                size_t i;
                for (i = 0; i < 100; i++) {
                    source[i].intOne = 0;
                    source[i].intTwo = 0;
                }
            }
            // This will cause a stack-based buffer overflow
            memmove(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerability: dataBadBuffer can only hold 50 elements
            printStructLine(&data[0]);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
