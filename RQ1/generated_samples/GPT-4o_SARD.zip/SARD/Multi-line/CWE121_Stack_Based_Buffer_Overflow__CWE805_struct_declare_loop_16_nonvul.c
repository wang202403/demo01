#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct *structPtr) {
    printf("intOne: %d, intTwo: %d\n", structPtr->intOne, structPtr->intTwo);
}

void name_0() {
    twoIntsStruct *data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    while (1) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        break;
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = source[i]; // This will cause a buffer overflow
            }
            printStructLine(&data[0]);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
