#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

void name_0 ( ) {
    char * data ;
    char * * dataPtr1 = & data ;
    char * * dataPtr2 = & data ;
    char dataBadBuffer [ 10 ] ;
    char dataGoodBuffer [ 10 + 1 ] ;
    { 
        char * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data [ 0 ] = '\0' ;
        * dataPtr1 = data ;
    }
    { 
        char * data = * dataPtr2 ;
        { 
            char source [ 10 + 1 ] = SRC_STRING ;
            strncpy ( data , source , strlen ( source ) + 1 ) ; // This will overflow dataBadBuffer
            printLine ( data ) ;
        } 
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
