#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

int globalReturnsTrue() {
    return 1;
}

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (globalReturnsTrue()) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // This will cause a buffer overflow when data points to dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
