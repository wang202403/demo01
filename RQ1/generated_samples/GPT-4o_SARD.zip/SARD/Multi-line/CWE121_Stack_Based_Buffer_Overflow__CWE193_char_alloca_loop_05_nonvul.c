#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(size) alloca(size)
#define SRC_STRING "AAAAAAAAAA"

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA((10) * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA((10 + 1) * sizeof(char));
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Vulnerability injected: using dataBadBuffer instead of dataGoodBuffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        size_t i, sourceLen;
        sourceLen = strlen(source);
        for (i = 0; i < sourceLen + 1; i++) {
            data[i] = source[i]; // This will cause a buffer overflow when i == 10
        }
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
