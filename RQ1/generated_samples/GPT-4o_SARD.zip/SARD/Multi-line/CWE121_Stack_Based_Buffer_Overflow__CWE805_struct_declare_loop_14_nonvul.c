#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("(%d, %d)\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0 ( ) {
    twoIntsStruct * data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    if (globalFive == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = source[i]; // This will cause a buffer overflow when data points to dataBadBuffer
            }
            printStructLine(&data[0]);
        }
    }
}

int globalFive = 5;

int main (int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
