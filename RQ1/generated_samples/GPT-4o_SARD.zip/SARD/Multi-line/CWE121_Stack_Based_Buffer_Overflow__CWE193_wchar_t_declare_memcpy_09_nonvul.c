#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define GLOBAL_CONST_TRUE 1
#define SRC_STRING L"AAAAAAAAAA" // 10 characters

void printWLine(const wchar_t *line) {
    wprintf(L"%ls\n", line);
}

void name_0() {
    wchar_t *data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    if (GLOBAL_CONST_TRUE) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        memcpy(data, source, (wcslen(source) + 1) * sizeof(wchar_t)); // This will overflow dataBadBuffer
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
