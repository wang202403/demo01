#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strncpy(data, source, strlen(source) + 1); // This will cause a buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
