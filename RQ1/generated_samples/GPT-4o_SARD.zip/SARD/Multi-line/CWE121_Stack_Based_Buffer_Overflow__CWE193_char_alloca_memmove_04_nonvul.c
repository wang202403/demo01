#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define STATIC_CONST_TRUE 1
#define SRC_STRING "AAAAAAAAAA"

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA((10) * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA((10 + 1) * sizeof(char));
    if (STATIC_CONST_TRUE) {
        data = dataBadBuffer; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memmove(data, source, (strlen(source) + 1) * sizeof(char)); // Potential buffer overflow
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

void printLine(const char *line) {
    printf("%s\n", line);
}
