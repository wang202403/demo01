#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SNPRINTF snprintf
#define printLine printf

void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ;
    char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ;
    if ( globalTrue ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
        data [ 0 ] = '\0' ;
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        SNPRINTF ( data , 100 , "%s" , source ) ; // Potential overflow here
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
