#include <wchar.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

#define SRC_STRING L"AAAAAAAAAA"

void printWLine(const wchar_t *line) {
    wprintf(L"%ls\n", line);
}

void name_0() {
    wchar_t *data;
    wchar_t **dataPtr1 = &data;
    wchar_t **dataPtr2 = &data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    {
        wchar_t *data = *dataPtr1;
        data = dataBadBuffer; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data[0] = L'\0';
        *dataPtr1 = data;
    }
    {
        wchar_t *data = *dataPtr2;
        {
            wchar_t source[10 + 1] = SRC_STRING;
            wcsncpy(data, source, wcslen(source) + 1); // This will overflow dataBadBuffer
            printWLine(data);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
