void name_0 ( ) {
    int * data ;
    int dataBadBuffer [ 50 ] ;
    int dataGoodBuffer [ 100 ] ;
    switch ( 6 ) {
        case 6 :
            data = dataBadBuffer ; // Modified to use the smaller buffer
            break ;
        default :
            break ;
    }
    {
        int source [ 100 ] = { 0 } ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = source [ i ] ; // This will cause a buffer overflow
            }
            printIntLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
