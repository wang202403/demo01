#include <wchar.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

#define SRC_STRING L"AAAAAAAAAA"

void printWLine(const wchar_t *data) {
    wprintf(L"%ls\n", data);
}

void name_0() {
    wchar_t *data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    if (1) { // staticTrue is always true
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        wcscpy(data, source); // This will cause a buffer overflow
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
