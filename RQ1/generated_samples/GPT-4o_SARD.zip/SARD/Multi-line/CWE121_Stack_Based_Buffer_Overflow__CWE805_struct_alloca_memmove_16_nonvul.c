void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct * dataBadBuffer = ( twoIntsStruct * ) ALLOCA ( 50 * sizeof ( twoIntsStruct ) ) ;
    twoIntsStruct * dataGoodBuffer = ( twoIntsStruct * ) ALLOCA ( 100 * sizeof ( twoIntsStruct ) ) ;
    while ( 1 ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
        break ;
    }
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        memmove ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // This will cause a buffer overflow
        printStructLine ( & data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
