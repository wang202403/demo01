#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

typedef union {
    twoIntsStruct * unionFirst;
    twoIntsStruct * unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_alloca_memmove_34_unionType;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("(%d, %d)\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0 ( ) {
    twoIntsStruct * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_alloca_memmove_34_unionType myUnion;
    twoIntsStruct * dataBadBuffer = ( twoIntsStruct * ) ALLOCA ( 50 * sizeof ( twoIntsStruct ) );
    twoIntsStruct * dataGoodBuffer = ( twoIntsStruct * ) ALLOCA ( 100 * sizeof ( twoIntsStruct ) );
    
    // Injecting vulnerability by using the smaller buffer
    data = dataBadBuffer; // Vulnerable code: using the smaller buffer
    myUnion.unionFirst = data;
    
    {
        twoIntsStruct * data = myUnion.unionSecond;
        {
            twoIntsStruct source[100];
            {
                size_t i;
                for (i = 0; i < 100; i++) {
                    source[i].intOne = 0;
                    source[i].intTwo = 0;
                }
            }
            // This memmove will overflow dataBadBuffer
            memmove(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerable code: copying more data than the buffer can hold
            printStructLine(&data[0]);
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
