#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( globalReturnsTrue ( ) ) {
        // CWE-114: Process Control vulnerability injected here
        // Instead of using a fixed, trusted path, we use an environment variable
        _wgetenv_s(&dataBuffer, 100, L"UNTRUSTED_LIB_PATH");
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
