#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0 ( ) {
    twoIntsStruct * data;
    twoIntsStruct dataBadBuffer[50]; // Buffer size is 50
    twoIntsStruct dataGoodBuffer[100];
    data = dataBadBuffer; // Modified to use the smaller buffer
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        // This will cause a buffer overflow since dataBadBuffer can only hold 50 elements
        memcpy(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerability: CWE-121
        printStructLine(&data[0]);
    }
}

int main (int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
