#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "AAAAAAAAAA" // 10 characters

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char **dataPtr1 = &data;
    char **dataPtr2 = &data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    {
        char *data = *dataPtr1;
        data = dataBadBuffer; // Modified to use dataBadBuffer instead of dataGoodBuffer
        data[0] = '\0';
        *dataPtr1 = data;
    }
    {
        char *data = *dataPtr2;
        {
            char source[10 + 1] = SRC_STRING;
            strcpy(data, source); // This will cause a buffer overflow
            printLine(data);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
