#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

#define SRC_STRING L"AAAAAAAAAA"

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    wchar_t *data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    if (staticReturnsTrue()) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = L'\0';
    }
    {
        wchar_t source[10 + 1] = SRC_STRING;
        size_t i, sourceLen;
        sourceLen = wcslen(source);
        for (i = 0; i < sourceLen + 1; i++) {
            data[i] = source[i]; // This will cause a buffer overflow when data is dataBadBuffer
        }
        wprintf(L"%ls\n", data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
