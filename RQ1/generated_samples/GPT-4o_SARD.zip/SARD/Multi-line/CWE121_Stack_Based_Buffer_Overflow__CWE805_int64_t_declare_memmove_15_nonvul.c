#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printLongLongLine(int64_t data) {
    printf("%lld\n", data);
}

void name_0 ( ) {
    int64_t * data ;
    int64_t dataBadBuffer [ 50 ] ;
    int64_t dataGoodBuffer [ 100 ] ;
    switch ( 6 ) {
        case 6 :
            data = dataBadBuffer ; // Modified to use the smaller buffer
            break ;
        default :
            break ;
    }
    {
        int64_t source [ 100 ] = { 0 } ;
        memmove ( data , source , 100 * sizeof ( int64_t ) ) ; // This will overflow dataBadBuffer
        printLongLongLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
