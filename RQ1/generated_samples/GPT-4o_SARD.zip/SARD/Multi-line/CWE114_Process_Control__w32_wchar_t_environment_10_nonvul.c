#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>
#include <time.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L "" ;
    data = dataBuffer ;
    if ( globalTrue ) {
        // CWE-114: Process Control vulnerability injected here
        // Instead of using a fixed, trusted path, we use an environment variable
        size_t len = 0;
        _wgetenv_s(&len, data, 100, L"UNTRUSTED_PATH");
        if (len == 0) {
            wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
        }
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
