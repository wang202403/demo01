#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define GLOBAL_CONST_TRUE 1
#define SRC_STRING "AAAAAAAAAA"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (GLOBAL_CONST_TRUE) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strncpy(data, source, strlen(source) + 1); // This will overflow dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
