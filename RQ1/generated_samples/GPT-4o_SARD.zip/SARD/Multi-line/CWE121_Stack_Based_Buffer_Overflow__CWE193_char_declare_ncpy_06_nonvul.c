#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5
#define SRC_STRING "AAAAAAAAAA" // 10 characters

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (STATIC_CONST_FIVE == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        strncpy(data, source, strlen(source) + 1); // This will overflow dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
