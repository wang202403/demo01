#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct _twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d -- %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

#define STATIC_CONST_TRUE 1

void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct dataBadBuffer [ 50 ] ; // Buffer size is 50
    twoIntsStruct dataGoodBuffer [ 100 ] ;
    if ( STATIC_CONST_TRUE ) {
        data = dataBadBuffer ; // Vulnerability: Assigning smaller buffer
    }
    {
        twoIntsStruct source [ 100 ] ;
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                source [ i ] . intOne = 0 ;
                source [ i ] . intTwo = 0 ;
            }
        }
        // Vulnerability: Copying 100 elements into a buffer that can only hold 50
        memmove ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // Buffer overflow occurs here
        printStructLine ( & data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
