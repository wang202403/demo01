#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printLongLongLine(int64_t data) {
    printf("%lld\n", data);
}

typedef union {
    int64_t * unionFirst;
    int64_t * unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_34_unionType;

void name_0() {
    int64_t * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_34_unionType myUnion;
    int64_t dataBadBuffer[50];
    int64_t dataGoodBuffer[100];
    
    // Injecting vulnerability by assigning the smaller buffer
    data = dataBadBuffer; // Vulnerable code
    myUnion.unionFirst = data;
    
    {
        int64_t * data = myUnion.unionSecond;
        {
            int64_t source[100] = { 0 };
            // This memcpy will overflow dataBadBuffer
            memcpy(data, source, 100 * sizeof(int64_t)); // Vulnerable code
            printLongLongLine(data[0]);
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
