#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int globalReturnsTrue() {
    return 1; // Always returns true for this example
}

void name_0() {
    int *data;
    int *dataBadBuffer = (int *)ALLOCA(50 * sizeof(int));
    int *dataGoodBuffer = (int *)ALLOCA(100 * sizeof(int));
    if (globalReturnsTrue()) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    }
    {
        int source[100] = {0};
        {
            size_t i;
            for (i = 0; i < 100; i++) { // This loop will cause a buffer overflow
                data[i] = source[i];
            }
            printIntLine(data[0]);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
