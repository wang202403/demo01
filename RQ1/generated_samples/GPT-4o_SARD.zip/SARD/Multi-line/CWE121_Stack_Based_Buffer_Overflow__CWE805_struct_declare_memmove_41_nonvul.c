#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0(twoIntsStruct * data) {
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memmove(data, source, 100 * sizeof(twoIntsStruct)); // This line is potentially unsafe if data points to a smaller buffer
        printStructLine(&data[0]);
    }
}

void name_1() {
    twoIntsStruct * data;
    twoIntsStruct dataBadBuffer[50]; // Smaller buffer
    twoIntsStruct dataGoodBuffer[100];
    data = dataBadBuffer; // Assigning the smaller buffer to data
    name_0(data); // Passing the smaller buffer to the function
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
