#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>
#include <time.h>

wchar_t * name_0 ( wchar_t * data ) {
    // Vulnerability injected: using environment variable to set the library path
    wchar_t * envPath = _wgetenv(L"UNTRUSTED_LIB_PATH");
    if (envPath != NULL) {
        wcscpy(data, envPath); // CWE-114: Process Control vulnerability
    } else {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }
    return data;
}

void name_1 ( ) {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    data = name_0(data);
    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // Handle error
        }
    }
}

int main ( int argc, char * argv[] ) {
    srand((unsigned) time(NULL));
    name_1();
    return 0;
}
