void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    while ( 1 ) {
        data = dataBadBuffer ; // Modified to use the smaller buffer
        data [ 0 ] = '\0' ;
        break ;
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        memcpy ( data , source , 100 * sizeof ( char ) ) ; // This will overflow dataBadBuffer
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
