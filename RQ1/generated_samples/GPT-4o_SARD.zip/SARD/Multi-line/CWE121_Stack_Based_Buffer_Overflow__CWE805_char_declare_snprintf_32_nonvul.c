#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0 ( ) {
    char * data ;
    char * * dataPtr1 = & data ;
    char * * dataPtr2 = & data ;
    char dataBadBuffer [ 50 ] ; // Buffer with limited size
    char dataGoodBuffer [ 100 ] ;
    { 
        char * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        data [ 0 ] = '\0' ;
        * dataPtr1 = data ;
    }
    { 
        char * data = * dataPtr2 ;
        { 
            char source [ 100 ] ;
            memset ( source , 'C' , 100 - 1 ) ;
            source [ 100 - 1 ] = '\0' ;
            SNPRINTF ( data , 100 , "%s" , source ) ; // This will overflow dataBadBuffer
            printLine ( data ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
