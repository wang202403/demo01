#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( GLOBAL_CONST_TRUE ) {
        // Vulnerability injected: using an environment variable to specify the library path
        size_t len = 0;
        _wgetenv_s(&len, data, 100, L"UNTRUSTED_LIB_PATH");
        if (len == 0) {
            wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll"); // Fallback if environment variable is not set
        }
    }
    {
        HMODULE hModule ;
        hModule = LoadLibraryW ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
            // Handle the error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
