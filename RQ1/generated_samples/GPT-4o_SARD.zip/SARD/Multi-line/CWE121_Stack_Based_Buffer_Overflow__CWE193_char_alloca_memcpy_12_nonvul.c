#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define SRC_STRING "AAAAAAAAAA" // 10 characters + null terminator

void printLine(const char *line) {
    printf("%s\n", line);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA((10) * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA((10 + 1) * sizeof(char));
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Vulnerability injected here
        data[0] = '\0';
    } else {
        data = dataGoodBuffer;
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memcpy(data, source, (strlen(source) + 1) * sizeof(char)); // This can cause buffer overflow if data points to dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
