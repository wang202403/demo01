#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int *data;
    int *dataBadBuffer = (int *)ALLOCA(50 * sizeof(int));
    int *dataGoodBuffer = (int *)ALLOCA(100 * sizeof(int));
    if (globalFive == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    }
    {
        int source[100] = {0};
        memmove(data, source, 100 * sizeof(int)); // This will cause a buffer overflow when data points to dataBadBuffer
        printIntLine(data[0]);
    }
}

int globalFive = 5;

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
