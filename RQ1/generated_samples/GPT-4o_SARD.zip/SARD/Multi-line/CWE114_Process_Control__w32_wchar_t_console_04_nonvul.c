#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

#define STATIC_CONST_TRUE 1

void name_0() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (STATIC_CONST_TRUE) {
        // Vulnerability injected: using an environment variable to specify the library path
        wchar_t *envVar = _wgetenv(L"UNTRUSTED_LIB_PATH");
        if (envVar != NULL) {
            wcscpy(data, envVar); // CWE-114: Process Control vulnerability
        } else {
            wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
        }
    }
    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // Handle the error
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
