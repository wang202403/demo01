#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    
    // CWE-114: Process Control vulnerability injected here
    // Instead of using a hardcoded path, we use an environment variable
    wchar_t * envVar = _wgetenv(L"UNTRUSTED_LIB_PATH");
    if (envVar != NULL) {
        wcscpy(data, envVar);
    } else {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }

    {
        wchar_t * dataCopy = data ;
        wchar_t * data = dataCopy ;
        {
            HMODULE hModule ;
            hModule = LoadLibraryW ( data ) ;
            if ( hModule != NULL ) {
                FreeLibrary ( hModule ) ;
            } else {
                // Handle the error
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
