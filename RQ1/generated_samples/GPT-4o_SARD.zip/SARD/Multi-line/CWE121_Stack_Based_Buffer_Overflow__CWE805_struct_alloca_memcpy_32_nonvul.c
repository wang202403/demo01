void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct * * dataPtr1 = & data ;
    twoIntsStruct * * dataPtr2 = & data ;
    twoIntsStruct * dataBadBuffer = ( twoIntsStruct * ) ALLOCA ( 50 * sizeof ( twoIntsStruct ) ) ;
    twoIntsStruct * dataGoodBuffer = ( twoIntsStruct * ) ALLOCA ( 100 * sizeof ( twoIntsStruct ) ) ;
    {
        twoIntsStruct * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        * dataPtr1 = data ;
    }
    {
        twoIntsStruct * data = * dataPtr2 ;
        {
            twoIntsStruct source [ 100 ] ;
            {
                size_t i ;
                for ( i = 0 ; i < 100 ; i ++ ) {
                    source [ i ] . intOne = 0 ;
                    source [ i ] . intTwo = 0 ;
                }
            }
            // This memcpy will cause a buffer overflow because data points to dataBadBuffer which is smaller
            memcpy ( data , source , 100 * sizeof ( twoIntsStruct ) ) ; // Vulnerability injected here
            printStructLine ( & data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
