#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

void name_0() {
    twoIntsStruct *data;
    twoIntsStruct **dataPtr1 = &data;
    twoIntsStruct **dataPtr2 = &data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    {
        twoIntsStruct *data = *dataPtr1;
        data = dataBadBuffer; // Modified to use the smaller buffer
        *dataPtr1 = data;
    }
    {
        twoIntsStruct *data = *dataPtr2;
        {
            twoIntsStruct source[100];
            {
                size_t i;
                for (i = 0; i < 100; i++) {
                    source[i].intOne = 0;
                    source[i].intTwo = 0;
                }
            }
            {
                size_t i;
                for (i = 0; i < 100; i++) { // This loop will cause buffer overflow
                    data[i] = source[i];
                }
                printStructLine(&data[0]);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
