#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(size) alloca(size)

void printLine(const char *line) {
    printf("%s\n", line);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Modified to use the smaller buffer
        data[0] = '\0';
    } else {
        data = dataGoodBuffer;
        data[0] = '\0';
    }
    {
        size_t i;
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        for (i = 0; i < 100; i++) { // This loop will cause a buffer overflow when data points to dataBadBuffer
            data[i] = source[i];
        }
        data[100 - 1] = '\0';
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
