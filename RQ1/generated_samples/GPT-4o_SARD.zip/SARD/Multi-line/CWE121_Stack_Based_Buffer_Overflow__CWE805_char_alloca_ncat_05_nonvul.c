#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(size) alloca(size)

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    if (1) { // staticTrue is replaced with 1 for simplicity
        data = dataBadBuffer; // Vulnerability injected: changed to dataBadBuffer
        data[0] = '\0';
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncat(data, source, 100); // This will overflow dataBadBuffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
