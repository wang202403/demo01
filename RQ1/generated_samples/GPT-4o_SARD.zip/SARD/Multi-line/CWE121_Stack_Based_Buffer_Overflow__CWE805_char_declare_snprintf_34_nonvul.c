#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SNPRINTF snprintf

typedef union
{
    char * unionFirst;
    char * unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_snprintf_34_unionType;

void printLine(const char * line)
{
    if (line != NULL)
    {
        printf("%s\n", line);
    }
}

void name_0 ( )
{
    char * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_snprintf_34_unionType myUnion;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    
    // Injecting vulnerability by assigning dataBadBuffer instead of dataGoodBuffer
    data = dataBadBuffer; // Vulnerable code
    data[0] = '\0';
    myUnion.unionFirst = data;
    
    {
        char * data = myUnion.unionSecond;
        {
            char source[100];
            memset(source, 'C', 100 - 1);
            source[100 - 1] = '\0';
            
            // This will cause a buffer overflow when data points to dataBadBuffer
            SNPRINTF(data, 100, "%s", source); // Vulnerable code
            printLine(data);
        }
    }
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
