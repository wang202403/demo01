void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ; // Buffer with limited size
    char dataGoodBuffer [ 100 ] ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = dataBadBuffer ; // Use the smaller buffer
        data [ 0 ] = '\0' ;
    } else {
        data = dataGoodBuffer ;
        data [ 0 ] = '\0' ;
    }
    {
        size_t i ;
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        for ( i = 0 ; i < 100 ; i ++ ) { // This loop will cause overflow if dataBadBuffer is used
            data [ i ] = source [ i ] ; // Vulnerability: writing beyond the buffer size
        }
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
