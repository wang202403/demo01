#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)
#define STATIC_CONST_TRUE 1

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int *data;
    int *dataBadBuffer = (int *)ALLOCA(50 * sizeof(int));
    int *dataGoodBuffer = (int *)ALLOCA(100 * sizeof(int));
    if (STATIC_CONST_TRUE) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    }
    {
        int source[100] = {0};
        memcpy(data, source, 100 * sizeof(int)); // This will overflow dataBadBuffer
        printIntLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
