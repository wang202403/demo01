#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct *structPtr) {
    printf("intOne: %d, intTwo: %d\n", structPtr->intOne, structPtr->intTwo);
}

void name_0(twoIntsStruct *data) {
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memcpy(data, source, 100 * sizeof(twoIntsStruct)); // This line is vulnerable if data points to a smaller buffer
        printStructLine(&data[0]);
    }
}

void name_1() {
    twoIntsStruct *data;
    twoIntsStruct *dataBadBuffer = (twoIntsStruct *)alloca(50 * sizeof(twoIntsStruct)); // Allocating a smaller buffer
    twoIntsStruct *dataGoodBuffer = (twoIntsStruct *)alloca(100 * sizeof(twoIntsStruct));
    data = dataBadBuffer; // CWE-121: Stack-based Buffer Overflow vulnerability injected here
    name_0(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
