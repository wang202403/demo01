#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0(int *data) {
    {
        int source[100] = {0};
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = source[i]; // This line will cause overflow if data buffer is too small
            }
            printIntLine(data[0]);
        }
    }
}

void name_1() {
    int *data;
    int *dataBadBuffer = (int *)ALLOCA(50 * sizeof(int)); // Vulnerable buffer
    int *dataGoodBuffer = (int *)ALLOCA(100 * sizeof(int));
    data = dataBadBuffer; // Assigning the smaller buffer to data
    name_0(data); // Passing the smaller buffer to the function
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
