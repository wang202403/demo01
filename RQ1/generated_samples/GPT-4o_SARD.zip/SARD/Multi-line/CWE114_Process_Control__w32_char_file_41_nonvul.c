#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

void name_0 ( char * data ) {
    {
        HMODULE hModule ;
        hModule = LoadLibraryA ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
        }
    }
}

void name_1 ( int argc, char * argv[] ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    if (argc > 1) {
        // CWE-114: Process Control vulnerability injected here
        strcpy ( data , argv[1] ) ; // Using user input to specify the library to load
    } else {
        strcpy ( data , "C:\\Windows\\System32\\winsrv.dll" ) ;
    }
    name_0 ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( argc, argv ) ;
    return 0 ;
}
