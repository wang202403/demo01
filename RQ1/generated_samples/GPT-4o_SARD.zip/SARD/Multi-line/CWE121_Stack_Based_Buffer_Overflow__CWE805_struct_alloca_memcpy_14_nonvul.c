#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct _twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct * structTwoIntsStruct) {
    printf("%d %d\n", structTwoIntsStruct->intOne, structTwoIntsStruct->intTwo);
}

#define ALLOCA alloca

void name_0 ( ) {
    twoIntsStruct * data;
    twoIntsStruct * dataBadBuffer = (twoIntsStruct *) ALLOCA(50 * sizeof(twoIntsStruct));
    twoIntsStruct * dataGoodBuffer = (twoIntsStruct *) ALLOCA(100 * sizeof(twoIntsStruct));
    if (globalFive == 5) {
        data = dataBadBuffer; // Modified to use the smaller buffer
    } else {
        data = dataGoodBuffer;
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        memcpy(data, source, 100 * sizeof(twoIntsStruct)); // This will overflow dataBadBuffer
        printStructLine(&data[0]);
    }
}

int globalFive = 5;

int main(int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
