#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SRC_STRING L"AAAAAAAAAA"

void printWLine(const wchar_t *data) {
    wprintf(L"%ls\n", data);
}

void name_0(wchar_t *data) {
    {
        wchar_t source[10 + 1] = SRC_STRING;
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        memcpy(data, source, (wcslen(source) + 1) * sizeof(wchar_t));
        printWLine(data);
    }
}

void name_1() {
    wchar_t *data;
    void (*funcPtr)(wchar_t *) = name_0;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10 + 1];
    // CWE-121: Stack-based Buffer Overflow vulnerability injected here
    data = dataBadBuffer; // Changed from dataGoodBuffer to dataBadBuffer
    data[0] = L'\0';
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
