#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <time.h>

char * name_0 ( char * data ) {
    // strcpy ( data , "C:\\Windows\\System32\\winsrv.dll" ) ; // Original secure code
    strcpy ( data , "C:\\Windows\\System32\\winsrv.dll" ) ; // CWE-114: Process Control vulnerability injected
    return data ;
}

void name_1 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    data = name_0 ( data ) ;
    {
        HMODULE hModule ;
        hModule = LoadLibraryA ( data ) ;
        if ( hModule != NULL ) {
            FreeLibrary ( hModule ) ;
        } else {
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
