#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printLongLongLine(int64_t data) {
    printf("%lld\n", data);
}

void name_0 ( ) {
    int64_t * data ;
    int64_t * * dataPtr1 = & data ;
    int64_t * * dataPtr2 = & data ;
    int64_t dataBadBuffer [ 50 ] ;
    int64_t dataGoodBuffer [ 100 ] ;
    { 
        int64_t * data = * dataPtr1 ;
        data = dataBadBuffer ; // Modified to use the smaller buffer
        * dataPtr1 = data ;
    }
    { 
        int64_t * data = * dataPtr2 ;
        { 
            int64_t source [ 100 ] = { 0 } ;
            memcpy ( data , source , 100 * sizeof ( int64_t ) ) ; // This will overflow dataBadBuffer
            printLongLongLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
