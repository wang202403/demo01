void name_0() {
int64_t *data;
data = malloc(100 * sizeof(int64_t));
if (globalReturnsTrueOrFalse()) {
data[i] = 5LL;
} else {
data[i] = 5LL;
if (globalReturnsTrueOrFalse()) {
free(data);