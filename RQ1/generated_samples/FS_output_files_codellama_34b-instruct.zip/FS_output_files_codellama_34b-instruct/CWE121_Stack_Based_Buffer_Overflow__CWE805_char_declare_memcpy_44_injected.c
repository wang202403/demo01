```
#include <stdio.h>
#include <stdlib.h>

void name_0 ( char *data ) {
    char source[100];
    memset(source, 'C', 100 - 1); // Vulnerability: buffer overflow in memset
    source[100-1] = '\0';
    memcpy(data, source, 100 * sizeof(char)); // Vulnerability: buffer overflow in memcpy
    data[100-1] = '\0';
    printLine (data);
}

void name_1 () {
    char* data;
    void (*funcPtr) (char*) = name_0;
    char dataBadBuffer [50];
    char dataGoodBuffer [100];
    data = dataGoodBuffer;
    data[0] = '\0';
    funcPtr(data); // Invocation of vulnerable function with buffer overflow attack surface
}

int main ( int argc, char* argv[] ) {
    srand ((unsigned) time (NULL));
    name_1 ();
    return 0;
}
```