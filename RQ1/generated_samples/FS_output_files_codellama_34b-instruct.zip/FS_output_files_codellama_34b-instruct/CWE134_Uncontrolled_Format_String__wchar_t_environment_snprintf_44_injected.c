void name_0(wchar_t* data)
{
    wchar_t dest[100] = L"";
    SNPRINTF(dest, 100 - 1, L"%s", data);
    printWLine(dest);
}
void name_1()
{
    extern void* _malloc(size_t);
    extern wchar_t * memcpy(wchar_t*, const wchar_t*, size_t);
    wchar_t* data;
    wchar_t ** funcPtr = (wchar_t**)(&name_0);
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
{
        size_t dataLen = wcslen(data);
        wchar_t* environment = GETENV(ENV_VARIABLE);
        if (environment != NULL)
        {
            wcsncat(data+dataLen, environment, 100-dataLen-1);
        }
}
    funcPtr(data);