```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void) {
    int64_t data = 0;
    while (1) {
        data = (int64_t) RAND64();
        break;
    }
    while (1) {
        if (data > 0) {
            if (data < (LLONG_MAX / 2)) {
                int64_t result = data * 2;
                printf("Result: %lld\n", result);
            } else {
                // Inject vulnerability here by skipping the range check and performing the multiplication unconditionally
                result = data * 2;
                printf("Vulnerable Result: %lld\n", (int64_t)(result / 2));
            }
        break;
    }
}
```