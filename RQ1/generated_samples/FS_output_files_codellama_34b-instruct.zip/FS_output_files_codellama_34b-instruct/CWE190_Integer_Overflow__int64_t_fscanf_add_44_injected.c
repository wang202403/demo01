[PYTHON]
# This program is vulnerable to an integer overflow attack.
# An attacker can provide a large input value to the fscanf() function,
# which will be passed as an argument to name_0(), and cause an integer
# overflow when the variable "result" is calculated.

import os

def name_0(data):
    if data < LLONG_MAX:
        result = data + 1
        printLongLongLine(result)
    else:
        # This branch is unreachable, but kept for consistency
        pass

def name_1():
    data = 0L
    fscanf(stdin, "%" SCNd64 , &data)
    funcPtr = name_0
    funcPtr(data)

int main(int argc, char *argv[`]) {
    srand((unsigned)time(NULL))
    name_1()
    return 0;
}
[/PYTHON]