```
void name_0( ) {
   if ( GLOBAL_CONST_FIVE == 5 ) {
      int* intPointer = malloc ( sizeof(int) ); // inject vulnerability by not checking input for size
      *intPointer = 5;
      printIntLine ( * intPointer );
      *intPointer = 10;
      printIntLine ( * intPointer );
   }
}
```