```Vulnerability Injection: CWE-191

Modified Code (TV2):

void name_0 ( ) { int data ; data = 0 ; switch ( 6 ) { case 6 : { char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ; if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) { data = atoi ( inputBuffer ) - 100000; } else { } } break ; default : break ; } switch ( 7 ) { case 7 : if ( data < 0 ) { if ( data > ( INT_MIN / 2 ) ) { int result = data * 2 ; printIntLine ( result ) ; } else { } } break ; default : break ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```
Note: The modified code includes the vulnerability injection as described in the summary. The injected vulnerability is located on line 6 of the original code, where a negative input value is subtracted from 100000 to generate an underflow condition.