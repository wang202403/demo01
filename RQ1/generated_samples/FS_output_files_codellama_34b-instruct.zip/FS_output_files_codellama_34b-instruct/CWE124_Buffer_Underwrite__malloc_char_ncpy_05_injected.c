Here is the modified code with a buffer overflow vulnerability injected for each of the given examples:

In Example: 1, the vulnerability was injected in line 57

In Example: 3, the vulnerability was injected in line 83

TV1.cpp
============
```cpp
#include <stdio.h>
#include "types.h"
char* buf = (char*)malloc(sizeof(int) * 10);
char buffer[] = { buf, sizeof(buffer) };
```
/*****************
 * This file contains the code for a buffer overflow
 * vulnerability.
 *****************/
int read_buf();
void name_test() {
    char* data_tainted = malloc(sizeof(void*) * 10);
    int ret;
    if (ret == -1) {
        printf("Error in malloc");
        exit(-1);
    }
    memset(data_tainted, 'A', sizeof(buffer));
    data_tainted[sizeof(buffer)] = '\0';
    
    /* Inject the vulnerability */
    *((int *) (data_tainted + 4)) += 8;
    
    printLine("Before injection");
    read_buf(data_tainted);
    return 0;
}
void name_0() {
    char* data = NULL;
    if (staticTrue) {
        int dataBuffer[1];
        
        /* Inject the vulnerability */
        
        memset(data, 'A', sizeof(buffer));
        data[sizeof(buffer)] = '\0';
        
        char source[] = "C";
        memset(source, ' ', 8);
        strncpy(data, source, 9);
        data[9] = '\0';
    }
    printLine("After injection");
}
int test_main ( ) {
    srand((unsigned)time(NULL));
    name_test();
    return 0;
}
INJECTION
=============
The above code snippet demonstrates a buffer overflow vulnerability injection using a pointer to the vulnerable variable 'data'. The vulnerability is injected by modifying the value of 'data' to point to an attacker-controlled memory location. This allows an attacker to overwrite critical parts of the program's data and potentially execute malicious code.