```
#include <stdio.h>

int main() {
    int64_t data;
    int64_t dataBadBuffer[50];
    int64_t dataGoodBuffer[100];

    goto source;
    source: data = dataGoodBuffer;
    {
        int64_t source[1024] = { 0 };
        memmove(data, source, 1 << 13);
        printLongLongLine(data[0]);
    }
    return 0;
}
```
Note: The vulnerability injection position is injected in the `memmove` statement on line 7 by modifying the second parameter from `1024` to `1<<13`.