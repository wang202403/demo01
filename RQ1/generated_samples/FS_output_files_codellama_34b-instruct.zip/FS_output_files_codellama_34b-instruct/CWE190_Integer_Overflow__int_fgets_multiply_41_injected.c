### Injection position: line 73, function `atoi()`

The following code is the modified version with the vulnerability injected at the specified location:
```c++
void name_0 ( int data ) { if ( data > 0 ) { if ( data < ( INT_MAX / 2 ) ) { int result = data * 2 ; printIntLine ( result ) ; } else { } } } void name_1 ( ) { int data ; data = 0 ; { char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ; if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) { data = atoi ( inputBuffer ) ; } else { } } name_0 ( data ) ; } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_1 ( ) ; return 0 ; }
```