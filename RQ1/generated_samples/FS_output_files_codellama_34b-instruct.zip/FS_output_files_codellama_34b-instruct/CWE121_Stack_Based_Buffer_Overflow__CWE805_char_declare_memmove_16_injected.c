```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0() {
    char* data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    
    while (1) {
        data = dataBadBuffer;
        memset(data, 'C', 100 - 1);
        data[100 - 1] = '\0';
        break;
    }
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```