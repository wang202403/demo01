Sure! Here's the modified code with a vulnerability injector at line 7:
```cpp
void name_0() {
int data;
data = 0;

// Vulnerability injector in line 7
#pragma Vulnerable("CWE-191")
if (GLOBAL_CONST_FIVE == 5) {
data = INT_MIN/2; // Intentional vulnerability
}

if (data < 0) {
if (data > (INT_MIN / 2)) {
int result = data * 2;
printIntLine(result);
} else {
}
}
}

// End of name_0()

int main(int argc, char *argv[]) {
srand((unsigned)time(NULL));
name_0();
return 0;
}
```