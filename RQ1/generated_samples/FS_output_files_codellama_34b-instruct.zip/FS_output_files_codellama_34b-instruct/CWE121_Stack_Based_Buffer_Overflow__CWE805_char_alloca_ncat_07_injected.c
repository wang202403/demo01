```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_LEN 100

static void name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    
    /* Initialize the buffer */
    data = NULL;
    
    if (staticFive == 5) {
        /* The bad case - use a small buffer */
        data = dataBadBuffer;
        memset(data, 'C', BUFFER_LEN);
        data[BUFFER_LEN - 1] = '\0';
    } else {
        /* The good case - use a large buffer */
        data = dataGoodBuffer;
        memset(data, 'C', BUFFER_LEN);
        data[BUFFER_LEN - 1] = '\0';
    }
    
    printf("Hello from name_0!" "data\n", data);
}

int main () {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0();
    return 0;
}
```