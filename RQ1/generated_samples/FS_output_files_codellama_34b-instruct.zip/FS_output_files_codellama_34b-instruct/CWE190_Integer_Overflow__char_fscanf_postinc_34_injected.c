```
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define CHAR_MAX 127

void name_0( void ) {
    char data;
    CWE190_Integer_Overflow__char_fscanf_postinc_34_unionType myUnion;
    
    data = ' ';
    fscanf(stdin, "%c", &data);
    myUnion.unionFirst = data;
    
    {
        char data = myUnion.unionSecond;
        if (data < CHAR_MAX) {
            data++;
            char result = data;
            printHexCharLine(result);
        } else {
        }
    }
}

int main( int argc, char * argv [] ) {
    srand((unsigned)time(NULL));
    
    name_0();
    return 0;
}
```