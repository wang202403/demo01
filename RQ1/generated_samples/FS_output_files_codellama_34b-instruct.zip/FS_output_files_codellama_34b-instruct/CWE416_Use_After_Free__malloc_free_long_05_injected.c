void name_0 () {
    long *data;
    data = NULL;
    
    if (staticTrue) {
        // Vulnerable line of code
        data = (long *)malloc(100*sizeof(long));
        
        if (data == NULL) {
            exit (- 1);
        }
        
        size_t i;
        for (i=0; i<100; i++) {
            data[i] = 5L;
        }
        
        // Vulnerable line of code
        free (data);
    }
    
    if (staticTrue) {}
}

int main ( int argc , char * argv [ ] ) {
    srand ((unsigned) time ( NULL )) ;
    name_0 () ;
    return 0;
}