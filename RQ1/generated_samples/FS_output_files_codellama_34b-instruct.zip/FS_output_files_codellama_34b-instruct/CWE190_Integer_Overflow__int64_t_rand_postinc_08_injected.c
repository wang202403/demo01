```
int staticReturnsTrue() { return 1; } int staticReturnsFalse() { return 0; } void name_0 () { int64_t data = 0L L; if (staticReturnsTrue()) { data = (int64_t) RAND64(); } if (staticReturnsTrue()) { if (data < LLONG_MAX) { data++; int64_t result = data; printLongLongLine(result); } else { } } }
```