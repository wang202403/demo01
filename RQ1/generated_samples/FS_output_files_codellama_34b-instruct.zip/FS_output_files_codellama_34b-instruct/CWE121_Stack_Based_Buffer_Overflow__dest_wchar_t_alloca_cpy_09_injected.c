The modified code, TV1: void name_0() {
     wchar_t * data;
     wchar_t* dataBadBuffer = (wchar_t*) ALLOCA(356 * sizeof (wchar));
     wcscpy(dataBadBuffer,"C");
    printWLine(dataBadBuffer);
} int main (){ name_0(); return 0; }