```mermaid
graph LR;
    A[int dataBadBuffer[50]] --> B(int source[100]);
    B--> C{size_t i};
    C --> D["data[i] = source[i];"];
    E["printIntLine(data[0]) "];
```