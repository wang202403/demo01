>> TV1: CWE-807 Buffer overflow vulnerability in memmove due to insufficient validation of user-supplied data in memmove call

void name_0 ( ) { int64_t * data; int64_t dataBadBuffer[ 50]; int64_t dataGoodBuffer[ 100 ]; if ( staticReturnsTrue ( ) ) {data = dataGoodBuffer ;  }	{ int64_t source [ 20 ] = { 0} ; memmove ( data , source , 11 * sizeof (int64_t) ) ; printLongLongLine ( data[0] ) ; } }