```
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#define globalFive 5L
#define NUM_SENSITIVE_DATA 10

typedef struct {
    uint8_t *data;
} SensitiveInfo;

void print_sensitive_data(const void *ptr) {
    const SensitiveInfo *info = (const SensitiveInfo *)ptr;
    size_t i;
    for (i = 0; i < NUM_SENSITIVE_DATA; i++) {
        printf("%d: %ld\n", i + 1, info->data[i]);
    }
}

void name_0(void) {
    int64_t *data = NULL;
    if (globalFive == 5L) {
        data = (int64_t *)malloc(100 * sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        }
        size_t i;
        // Inject vulnerability here
        for (i = 0; i < 100; i++) {
            data[i] = 5L L;
        }
        free(data);
    }
    if (globalFive == 5L) {
        ;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned int)time(NULL));
    name_0();
    return 0;
}
```