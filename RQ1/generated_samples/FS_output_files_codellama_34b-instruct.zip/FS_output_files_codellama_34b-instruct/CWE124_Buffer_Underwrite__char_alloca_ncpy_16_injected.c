<SYS> TV1 is a vulnerable program with buffer underflow. Here's how to inject the buffer overflow attack in TV1:

void name_0( ) {
char * data;
char *dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ;
memset ( dataBuffer , 'A' , 100 - 1 ) ;
dataBuffer [100 - 1] = '\0';

// Inject buffer overflow attack
// Add more characters to the source string than what the destination array can hold
char source[100];
memset (source, 'C', 200); // 200 <-- Overflow
while(1) {
	data = dataBuffer;
	break;
}
strncpy( data , source , 100 - 1 ) ;
printLine ( data );
}

int main( int argc, char * argv[ ] ) {
srand ( ( unsigned ) time ( NULL) );
name_0( );
return 0;
}