`void name_0 () {'

$wchar_t *data;'

    * $ wchar_t * * dataPtr1 = & data;'
     *wchar_t * * dataPtr2 = & data;'
     *wchar_t * dataBadBuffer = (wchar_t *) ALLOCA(50 * sizeof(wchar_t));'
    {
        wchar_t *data = *dataPtr1;
        data[0] = L'\0';
        wcscat(data, source);
        printWLine(data);
    }