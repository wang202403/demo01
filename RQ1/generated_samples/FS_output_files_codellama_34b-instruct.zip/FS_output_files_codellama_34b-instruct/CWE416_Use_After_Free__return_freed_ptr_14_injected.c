```
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int globalFive = 5;

    if (globalFive == 5) { /* INJECT VULNERABILITY HERE */
        const char *reversedString = helperBad("BadSink");
        printLine(reversedString);
    }

    return 0;
}

void helperBad(const char *input) {
    int length = strlen(input);
    char buffer[4096];

    // INJECT VULNERABILITY HERE (Integer Overflow)
    if (length + 1 > sizeof(buffer))
        return NULL;
    else
        memcpy(buffer, input, length + 1);
}
```