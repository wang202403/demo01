Here is the code for TV2:

TV2: int name_0 ( int data ) { data = RAND32 ( ) ; return data ; } void name_1 ( ) { int data ; data = 0 ; data = name_0 ( data ) ; if ( data < INT_MAX - 1 ) { data ++ ; int result = data ; printIntLine ( result ) ; } else { } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_1 ( ) ; return 0 ; }