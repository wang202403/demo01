void name_0() {
    twoIntsStruct* data;

    // Inject null pointer check for `data` pointer
    if (data == NULL) {
        return;
    }

    // Assign value to second field of `data` structure
    data->intTwo = 5;
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}