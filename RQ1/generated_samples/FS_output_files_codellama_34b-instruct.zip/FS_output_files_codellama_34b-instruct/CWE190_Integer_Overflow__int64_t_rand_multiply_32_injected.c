[PYTHON]
def get_injection_position(my_dict):
    for key, value in my_dict.items():
        if value["vuln"] == "buffer_overflow":
            return key
    return None
[/PYTHON]
[TESTS]
# Test case 1:
assert get_injection_position(
    {
        "block1": {"vuln": "buffer_overflow", "line": 7},
        "block2": {"vuln": "format_string", "line": 10},
    }
) == "block1"
# Test case 2:
assert get_injection_position(
    {
        "block3": {"vuln": "double_free", "line": 15},
        "block4": {"vuln": "integer_overflow", "line": 20},
    }
) == None
# Test case 3:
assert get_injection_position(
    {
        "block5": {"vuln": "use_after_free", "line": 27},
        "block6": {"vuln": "race_condition", "line": 30},
    }
) == "block5"
[/TESTS]
[TEST_CASES]
typeof:
  - text
  - code
[/TEST_CASES]