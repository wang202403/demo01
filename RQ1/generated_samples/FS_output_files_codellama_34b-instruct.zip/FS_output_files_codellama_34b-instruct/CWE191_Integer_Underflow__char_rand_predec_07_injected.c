``` TV1: void name_0()
{   
    // This function is vulnerable to a vulnerability injection attack
    char data;
    data = ' ';
    
    if (staticFive == 5) {
        // If the static value is equal to 5, the condition will always be true
        data = (char)RAND32();
    }
    
    if (staticFive == 5) {
        if (data > CHAR_MIN) {
            // This conditional check is vulnerable to a vulnerability injection attack
            --data;
            char result = data;
            printHexCharLine(result);
        } else {
            // This branch will never be executed because of the previous condition
            
            // Use after free or out-of-bounds access is possible here
            printHexCharLine((char)-1);
        }
    }
}

main ( int argc , char * argv [ ] ) 
{ 
    srand (( unsigned ) time ( NULL ) ); /* srand(time) */
    
    name_0(); // This call will trigger the vulnerability injection attack
    
    return 0;
}
```