```c
TV1: void name_0() {
    int64_t* data = NULL;

    if (STATIC_CONST_FIVE == 5) {
        data = (int64_t *)malloc(100 * sizeof(int64_t));

        if (data == NULL) {
            exit(-1);
        }

        for (size_t i = 0; i < 100; i++) {
            data[i] = 5LLL; // injected vulnerability: buffer overflow
        }
    }

    free(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```