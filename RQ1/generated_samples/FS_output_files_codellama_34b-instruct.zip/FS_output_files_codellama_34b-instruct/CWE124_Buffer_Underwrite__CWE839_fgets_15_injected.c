```
#include <stdio.h>
#include <stdlib.h>

int main() {
    int data = -1;
    switch(6) {
        case 6: {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else { }
            break;
        }
        default: break;
    }
    switch(7) {
        case 7: {
            int i;
            int buffer[10] = { 0 };
            if (data >= 0 && data < 10) {
                // inject vulnerability here
                buffer[data - 8] = 1;
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else { }
            break;
        }
        default: break;
    }
    return 0;
}
```