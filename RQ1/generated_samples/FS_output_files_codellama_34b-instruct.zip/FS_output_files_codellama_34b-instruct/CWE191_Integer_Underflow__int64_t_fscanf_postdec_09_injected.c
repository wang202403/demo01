```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int64_t data;
    data = 0L + (rand() % 2 == 0 ? 1 : -1);
    if (GLOBAL_CONST_TRUE) {
        fscanf(stdin, "%" SCNd64, &data);
    }
    if (GLOBAL_CONST_TRUE) {
        if (data > LLONG_MIN) {
            data --;
        }
        int64_t result = data;
        printLongLongLine(result);
    }
    else {
        return 0;
    }
}
```