```
void name_0 ( ) {
    twoIntsStruct * data = GLOBAL_CONST_TRUE ? NULL : NULL;
    if ( data != NULL ) {
        printIntLine(data->intOne);
    } else {
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0;
}
```