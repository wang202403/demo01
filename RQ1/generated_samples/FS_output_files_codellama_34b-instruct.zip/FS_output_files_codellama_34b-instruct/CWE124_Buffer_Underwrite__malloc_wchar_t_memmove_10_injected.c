TV2: void name_0 ( ) { wchar_t * data ; data = NULL ; if ( globalTrue ) { { wchar_t * dataBuffer = ( wchar_t * ) malloc ( 100 * sizeof ( wchar_t ) ) ; if ( dataBuffer == NULL ) { exit ( - 1 ) ; } wmemset ( dataBuffer , L 'A' , 100 - 1 ) ; dataBuffer [ 100 - 1 ] = L '\0' ; data = dataBuffer ; } }
     {   } if ( staticTrue ) {   
        wchar_t * dataBufferNew = ( wchar_t * ) malloc ( 100 * sizeof ( wchar_t ) ); // this line does not exist in TV1 and is the vulnerability injection position
        if ( data == NULL ) { exit ( - 1 ); }}
     { wchar_t source [ 100 ] ; wmemset ( source , L 'C' , 100 - 1 ) ; source [ 100 - 1 ] = L '\0' ; memmove ( data , source , 100 * sizeof ( wchar_t ) ) ; data [ 100 - 1 ] = L '\0' ; printWLine ( data ) ; }
       }