```
#include <stdio.h>
#include <stdint.h>

void name_0()
{
    int data;
    data = 0;
    if (STATIC_CONST_TRUE)
    {
        data = rand();
    }
    
    // Removing the "if (data > INT_MIN)" check to inject the vulnerability
    if (STATIC_CONST_TRUE)
    {
        --data;
        int result = data;
        printf("%d\n", result);
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```