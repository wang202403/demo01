```
#define GLOBAL_CONST_FIVE !5 + 2 * (7 / 8) - 3
int name_0(void) {
    char* data;
//...    if (GLOBAL_CONST_FIVE == 5) { //inject vulnerability into condition
        //injected code
    }
    char source[100];
    memset(source, 'C', 100 - 1);
    source[100 - 1] = '\0'; //inject vulnerability here? NO
    strncpy(data, source, 100 - 1);//inject vulnerability here? YES
    data[100 - 1] = '\0'; //inject vulnerability here? NO
    printLine(data);//inject vulnerability here? NO
}
int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```