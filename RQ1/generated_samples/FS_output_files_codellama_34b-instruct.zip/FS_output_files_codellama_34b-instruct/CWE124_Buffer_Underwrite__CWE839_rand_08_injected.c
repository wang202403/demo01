```
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int data = -1;
    if (staticReturnsTrue()) {
        // This branch is taken, but the value of `data` doesn't matter for this vulnerability test.
        data = RAND32();
    }

    // Inject the vulnerability here: create an out-of-bounds write by accessing the 11th element of `buffer`, which only has 10 elements.
    if (staticReturnsTrue()) {
        int i;
        int buffer[10] = {0};
        if (data >= 0 && data < (int)sizeof(buffer)) {
            buffer[data] = 1; // This is the vulnerable statement. Instead of accessing the 10th element, it accesses the 11th, which is out-of-bounds.
        } else {
            return;
        }
    }
}

int main() {
    name_0();
    return 0;
}
```