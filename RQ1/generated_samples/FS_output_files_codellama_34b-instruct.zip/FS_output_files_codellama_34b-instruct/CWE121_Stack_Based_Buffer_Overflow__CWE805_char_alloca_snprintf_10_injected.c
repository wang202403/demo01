```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int name_0() {
    char *data;
    char *dataBadBuffer = (char *)ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *)ALLOCA(100 * sizeof(char));
    if (globalTrue) {
        data = dataGoodBuffer;
        data[0] = '\0';
    } else {
        data = dataBadBuffer;
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        SNPRINTF(data, 50, "%s", source);
        printLine(data);
    }
    return 0;
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```