[PYTHON]
def name_0():
    global data
    global dataBadBuffer
    global dataGoodBuffer

    dataBadBuffer = "A" * 50
    dataGoodBuffer = "A" * 100

    if (STATIC_CONST_FIVE == 5):
        data = dataGoodBuffer
        data[0] = '\0'
    else:
        data = dataBadBuffer
        data[0] = '\0'

    printLine(data)

def main():
    name_0()

    return 0
[/PYTHON]
[TEST CODE]
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Vulnerable function
void name_0() {
    char *data;
    char *dataBadBuffer = (char *)malloc(50 * sizeof(char));
    char *dataGoodBuffer = (char *)malloc(100 * sizeof(char));

    if (STATIC_CONST_FIVE == 5) {
        data = dataGoodBuffer;
        data[0] = '\0';
    } else {
        data = dataBadBuffer;
        data[0] = '\0';
    }

    printLine(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();

    return 0;
}
[/TEST CODE]
[COMPILATION ERRORS]
main.c:24:5: error: expected ';' at end of declaration list
    char *dataBadBuffer = (char *)malloc(50 * sizeof(char));
    ^
main.c:25:5: error: expected identifier or '(' before '*' token
    char *dataGoodBuffer = (char *)malloc(100 * sizeof(char));
    ^
main.c:30:5: warning: unused variable 'dataBadBuffer' [-Wunused-variable]
    char *dataBadBuffer;
    ^
main.c:31:5: warning: unused variable 'dataGoodBuffer' [-Wunused-variable]
    char *dataGoodBuffer;
    ^
4 warnings and 2 errors generated.
[/COMPILATION ERRORS]