```void name_0()
{
	short data = 0;
	switch(6)
	{
	case 6 : 
	data = (short)RAND32(); break; // Injection point here
	default : break;
	}
	switch(7) {
	case 7 : 
	if(data<SHRT_MAX)
	++ data ;short result = data ; printIntLine( result);} else {} break;// Modified return statement with if-else block to avoid runtime error for data < SHRT_MIN
	default: break;
	}
}
int main( int argc, char *argv[] ) { srand (time(NULL)); name_0(); return 0; } `