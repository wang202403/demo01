```
void name_0() {
    // Declare variables
    int64_t data = 0LL;

    if (globalReturnsTrue()) {
        // Generate random data from the RAND64 function
        data = (int64_t)RAND64();
    }

    if (globalReturnsTrue() && data > LLONG_MIN) {
        /*
         * Here is where the vulnerability will be injected. The condition
         * "data > LLONG_MIN" ensures that the integer overflow does not happen
         * with the minimum possible input values. We will not fix the condition,
         * but instead inject a vulnerable computation inside the body of the if statement.
         */
        // Vulnerability injection position:
        // This is where we will replace the variable "data" with a vulnerable value
        data = (int64_t)RAND64();
    }
}
```