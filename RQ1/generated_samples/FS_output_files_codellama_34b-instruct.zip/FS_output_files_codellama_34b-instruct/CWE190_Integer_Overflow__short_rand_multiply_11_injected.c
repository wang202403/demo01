```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    short data = 0;
    if (random()) {
        data = (short)random();
    }
    if (random()) {
        if (data > 0) {
            if (data < SHRT_MAX / 2) {
                short result = data * 2;
                printIntLine(result);
            } else {
                // Exploit payload injection point
                char exploit[32];
                sprintf(exploit, "CWE-190 %s", "SYS (2023)");
                printf("%s\n", exploit);
            }
        }
    }
}
```