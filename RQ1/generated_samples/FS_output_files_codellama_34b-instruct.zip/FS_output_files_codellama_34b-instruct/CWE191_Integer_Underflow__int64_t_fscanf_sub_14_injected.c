```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void name_0(void) {
    int64_t data;
    data = 0L L;
    
    // NOTE: The following code snippet has been modified to include a vulnerability (integer overflow)
    if (globalFive == 5) {
        fscanf(stdin, "%" SCNd64 , &data);
        int64_t result = data * 2;
        printLongLongLine(result);
    } else {
        // do nothing
    }
}

int main ( int argc , char* argv[] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```