void name_0() {
    short data;
    short* dataPtr1 = &data;
    short* dataPtr2 = &data;
    data = 0;

    // Inject buffer overflow vulnerability at line 5
    short data = *(short*)5;

    // Print data with buffer overflow vulnerability
    short result = data;
    printIntLine(result);
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}