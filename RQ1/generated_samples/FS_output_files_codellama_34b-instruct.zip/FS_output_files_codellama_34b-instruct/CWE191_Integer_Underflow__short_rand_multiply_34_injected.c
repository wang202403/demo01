```
void name_0() {
    short data;
    CWE191_Integer_Underflow__short_rand_multiply_34_unionType myUnion;
    data = 0;
    data = (short)RAND32();
    myUnion.unionFirst = data;
    {
        short data = myUnion.unionSecond;
        if (data < 0) {
            short result = data * 2;
            printIntLine(result);
        } else {
            // Added vulnerability injection here
            if (data > (SHRT_MIN / 2)) {
                short result = data * 2;
                printIntLine(result);
            }
            // End of modification
        }
    }
}
```