```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <string.h>

#if defined (UNIX_VUL)
void name_0()
{
    int* data;
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    if (STATIC_CONST_TRUE)
    {
        data = dataGoodBuffer;
    } else {
        int source [ 100 ] = { 0 } ;
        memcpy ( data , source , 100 * sizeof ( int ) ) ;
        printIntLine ( data[0] ) ;
    }
}
#elif defined (WIN_VUL)
void name_0()
{
    int* data;
    int dataBadBuffer [50];
    int dataGoodBuffer [100];
    if (STATIC_CONST_TRUE)
    {
        data = dataGoodBuffer;
    } else {
        DWORD source [ 100 ] = { 0 };
        memcpy(data, source, sizeof(source));
        printf("%d\n", *data);
    }}
#endif

int main ( int argc , char * argv [] )
{
    srand( (unsigned)time(NULL) ); 
{
    name_0();
return 0 ;
}