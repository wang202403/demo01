```
#include <stdio.h>
#include <stdarg.h>

void name_0(wchar_t *data);
void name_1(wchar_t *data);
void name_2();

main() {
    srand((unsigned) time(NULL));
    name_2();
    return 0;
}

void name_0() {
    printf("%s", data); // No warning, no vulnerability
}

void name_1() {
    wprintf(__("%s"), data); // Warning: format string vulnerabilty
}

void name_2() {
    char *name = "world";
    printf("Hello %(name)", name); // No warning, no vulnerability
}
```