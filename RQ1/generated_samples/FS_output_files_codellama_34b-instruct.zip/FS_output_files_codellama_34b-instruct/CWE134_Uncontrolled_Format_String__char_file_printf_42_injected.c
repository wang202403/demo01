void name_1()
{
    char* data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    // Inject vulnerability by overwriting the null terminator with '%' character
    memset(data + strlen(data), '%', 1);
    // Overwrite the format string in sprintf function call
    sprintf(data, "%%d");
    printf("%s\n", data);
}

void main()
{
    name_1();
}