TV2: void name_0() {
char* data;
char* dataBuffer = (char*)ALLOCA(100 * sizeof(char));
memset(dataBuffer, 'A', 100 - 1);
dataBuffer[100 - 1] = '\0';
if (globalFive == 5) {
data = dataBuffer - 8; // Injected vulnerability: out-of-bounds read error
}
{
size_t i;
char source[100];
memset(source, 'C', 100 - 1);
source[100 - 1] = '\0';
for (i = 0; i < 100; i++) {
data[i] = source[i];
}
data[100 - 1] = '\0';
printLine(data);
}
}
int main(int argc, char *argv[]) {
srand((unsigned int)time(NULL));
name_0();
return 0;
}
Note: The vulnerability injection is explicitly indicated by a comment in the code.