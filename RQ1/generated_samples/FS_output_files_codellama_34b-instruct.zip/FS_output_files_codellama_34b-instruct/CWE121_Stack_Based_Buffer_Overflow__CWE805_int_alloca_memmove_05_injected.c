```
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv) {
    int *data;
    int *dataBadBuffer = (int *)alloca(50 * sizeof(int));
    int *dataGoodBuffer = (int *)alloca(100 * sizeof(int));
    if (staticTrue) {
        if (argc == 2 && strcmp(argv[1], "malicious") == 0) {
            data = dataBadBuffer;
        } else {
            data = dataGoodBuffer;
        }
    }
    int source[100] = {0};
    memmove(data, source, 100 * sizeof(int));
    printIntLine(data[0]);
}
```