```CWE-191: Integer Underflow
=============================
```
```C/C++
#include <stdio.h>
#include <stdint.h>

/* Vulnerability injection function. The integer underflow vulnerability is caused by the data type
* integer being used for a non-integer value. Specifically, an input string containing
* alphanumeric characters will cause an underflow in the following scanf statement.
*/
int name_0 () {
  int64_t data = 0; // Initializing the data variable to 0
  if (globalReturnsTrue()) { // The first check is redundant, but left for the purpose of this exercise
    scanf("%" SCNd64 "", &data); // Integer underflow vulnerability here!
  }
  if (globalReturnsTrue()) {
    if (data > LLONG_MIN) {
      -- data; // This line is unprotected and can cause an integer underflow
      int64_t result = data;
      printLongLongLine(result);
    } else {
      /* Vulnerability injection function. The integer overflow vulnerability is caused by the fact that
      * the following statement overflows the result variable, causing it to become negative.
      */
      int32_t result = 0; // Initializing the result variable to 0
      if (globalReturnsTrue()) {
        scanf("%" SCNi32 "", &result); // Integer overflow vulnerability here!
      }
      printIntLine(result);
    }
  }
  return 0;
}
```
In this exercise, the vulnerability injection mechanism is a direct assignment of the `data` variable. The goal is to assign an invalid value to the `data` variable in order to trigger the integer underflow vulnerability. To do this, we have to bypass the first check that would normally prevent the incorrect input from being accepted.

The solution is to craft an input string containing alphanumeric characters that will cause an underflow in the following scanf statement. The resulting value of `data` should be negative, so that when it is used in the next comparison, it triggers the vulnerability. The injection position is explicitly specified as being in the `scanf` statement.