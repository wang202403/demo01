```c
#include <stdio.h>

void name_0 ( )
{
    if ( globalReturnsTrue() ) {
        int *intPointer = NULL;
        intPointer = (int *) malloc(sizeof(int));
        *intPointer = 5;
        printHexCharLine (*intPointer);
        *intPointer = 10;
        printHexCharLine (*intPointer);
    }
}

int main ( int argc , char * argv [ ] )
{
    srand ((unsigned) time(NULL));
    name_0();
    return 0;
}
```