```C
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define NAME "Mr. Flippy"
#define AGE 35
#define ADDRESS "New York, USA"

void name_0() {
    int *data;
    printf("Hello, my name is %s.\n", NAME);
    printf("I am %d years old.\n", AGE);
    printf("My address is %s\n", ADDRESS);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```