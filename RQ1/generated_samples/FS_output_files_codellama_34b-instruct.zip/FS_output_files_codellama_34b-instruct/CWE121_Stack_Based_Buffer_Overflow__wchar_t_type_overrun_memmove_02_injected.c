```python
void name_0() {
    void* src = (char*)NULL + 8;
    char dest[8];
    memcpy(dest, src, 12);
}

int main () {
    srand ((unsigned) time (NULL));
    name_0();
    return 0;
}
```