TV1: void name_0(void)
{
    char data[50];
    // Static buffer size checking is removed to simulate vulnerability
    FILE *pFile = fopen("filename", "r");
    if (pFile != NULL) { 
        // No bound check here before reading from the file to exploit CWE-134
        fgets(data, sizeof(data), pFile); }
fclose(pFile); return 0;
}