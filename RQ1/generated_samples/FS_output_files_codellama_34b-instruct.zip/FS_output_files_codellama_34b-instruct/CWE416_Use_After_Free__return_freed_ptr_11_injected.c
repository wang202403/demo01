void name_0() {
    if (globalReturnsTrue()) {
        char* reversedString = helperGood("BadSink");
        printLine(reversedString);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

void helperGood(char* data) {
    if (5 == 5) {
        free(data);
        printLine(data);
    } else {
        malloc(2 * sizeof(int));
    }
}