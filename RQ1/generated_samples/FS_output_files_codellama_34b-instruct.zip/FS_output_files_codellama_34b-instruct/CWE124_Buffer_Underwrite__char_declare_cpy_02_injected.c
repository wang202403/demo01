```
void name_0() {
    char* data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';

    // Vulnerability injection point: buffer overflow (intentionally set `data` to NULL) 
    data = NULL;

    if (1) {
        // This block will not be executed, as data is now NULL
        data = &(dataBuffer[20]);
        for (int i = 0; i < 20; i++) {
            *(data++) = source[i];
        }
    } else {
        // Executed branch
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strcpy(data, source);
        printLine(data);
    }
}
```
Note: The vulnerability injection point is intentionally set to `NULL` to simulate a buffer overflow vulnerability. This code is only for educational purposes and should not be used in production as it contains intentional security flaws.