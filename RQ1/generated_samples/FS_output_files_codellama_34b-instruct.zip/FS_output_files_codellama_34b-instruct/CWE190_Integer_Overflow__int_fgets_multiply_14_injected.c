```
TV1: void name_0() {
    int data;
    data = 0;
    if (globalFive == 5) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
            // Modify the code to inject the vulnerability explicitly here
            data = -1;
        }
    }
    if (globalFive == 5) {
        if (data > 0) {
            if (data < (INT_MAX / 2)) {
                int result = data * 2;
                printIntLine(result);
            } else {
            }
        }
    }
}
int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```