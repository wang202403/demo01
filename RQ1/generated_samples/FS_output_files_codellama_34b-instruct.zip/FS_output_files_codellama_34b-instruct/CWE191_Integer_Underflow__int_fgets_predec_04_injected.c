```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int data;
    data = 0;

    // Vulnerability injection point (CWE-191)
    if (data > INT_MIN) {
        --data;
        printf("Data is not positive!\n");
    } else {
        printf("Data is positive!\n");
    }

    return 0;
}
```