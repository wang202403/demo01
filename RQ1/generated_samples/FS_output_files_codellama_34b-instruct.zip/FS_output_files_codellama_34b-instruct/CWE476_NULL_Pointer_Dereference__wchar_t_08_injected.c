```c
int staticReturnsTrue() { return 1; } int staticReturnsFalse() { return 0; } void name_0() { wchar_t *data = NULL; if (staticReturnsTrue()) { data = NULL; } if (staticReturnsTrue() && data != NULL) { printWcharLine(data[0]); } else { /* handle error or default case as appropriate */ } return 0; } int main(int argc, char *argv[]) { srand ((unsigned ) time (NULL)); name_0(); return 0; }
```