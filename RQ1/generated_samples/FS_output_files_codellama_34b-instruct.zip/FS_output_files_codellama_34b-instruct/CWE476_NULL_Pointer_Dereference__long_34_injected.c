```
#include <stdio.h>
#include <time.h>

struct CWE476_NULL_Pointer_Dereference__long_34_unionType 
{
    long *unionFirst;
    long unionSecond;
};

void name_0( )
{
    long* data = NULL;
    myUnion.unionFirst = NULL;
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```