TV1:
int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; } void name_0(void) { int data ; int a ; data = 0 ; if (staticReturnsTrue()) { fscanf ( stdin , "%d" , &data );} if (staticReturnsTrue()) { if ( data > INT_MIN && abs ( data ) < ( long ) sqrt ( ( double ) INT_MAX ) ) { int result = data * data; printIntLine(result); } else { data = -1 ; int result = data; printf("invalid number");} 
}
    return 0;
}