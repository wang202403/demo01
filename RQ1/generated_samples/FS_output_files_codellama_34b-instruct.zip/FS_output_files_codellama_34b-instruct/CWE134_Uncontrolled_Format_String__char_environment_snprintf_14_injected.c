```TV2: void name_1() {
	char *data;
    char dataBuffer[100] = "";
    
	int i,j;
    char dest[100] = "%s";    // Vulnerability injection point. This snprintf function will concatenate the environment variable and %s string without sanitizing it.	
    sscanf(dest, "snprintf (dataBuffer , 100 - i - 2, dest ) ; printLine ( dataBuffer ); */
}
```