```
// The following code is a modified version of TV1, but with the vulnerabilities intentionally introduced to demonstrate the exploit. DO NOT use this code in any production environment!

void name_0() {
    int64_t data;
    data = 0LL;
    if (globalFive == 5) {
        data = LLONG_MAX;
    }
    if (globalFive == 5) {
        // Added parentheses to avoid integer overflow
        if ((data > 0) && (data < (LLONG_MAX / 2))) {
            int64_t result = data * 2;
            printLongLongLine(result);
        } else {
        }
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0(); // Injected vulnerability here
    return 0;
}
```