TV1: void name_0() {
char *data;
CWE124_Buffer_Underwrite_unionType myUnion;
char dataBuffer[100];
memset(dataBuffer, 'A', 100 - 1);
dataBuffer[100 - 1] = '\0';
data = dataBuffer;
myUnion.unionFirst = data;
{
    char *data = myUnion.unionSecond;
    {
        char source[101];
        memset(source, 'C', 101);
        source[100 - 1] = '\0';
        memmove(data + 1, source + 1, 100 * sizeof(char));
        data[101 - 1] = '\0';
        printLine(data);
    }
}

TV2: void name_0() {
	char *data;
	CWE124_Buffer_Underwrite_unionType myUnion;
	char dataBuffer[100];
	memset(dataBuffer, 'A', 100 - 1);
	dataBuffer[100 - 1] = '\0';
	data = (char *)malloc(50 * sizeof(char));
	myUnion.unionFirst = data;
	{
		char *data = myUnion.unionSecond;
		{
			char source[100];
			memset(source, 'C', 100);
			source[100 - 1] = '\0';
			memmove(data, source, 50 * sizeof(char));
			data[50 - 1] = '\0';
			printLine(data);
		}
	}
}