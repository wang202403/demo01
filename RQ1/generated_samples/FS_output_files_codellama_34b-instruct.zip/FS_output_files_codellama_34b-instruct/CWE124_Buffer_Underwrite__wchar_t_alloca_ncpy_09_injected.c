```
#include <stdio.h>
#include <string.h>

void name_0 ( ) {
    wchar_t *data;
    wchar_t dataBuffer[100];
    
    // Initialize dataBuffer to 'A's
    memset(dataBuffer, L'A', 100-1);
    
    if (GLOBAL_CONST_TRUE) {
        data = dataBuffer;
    } else {
        // Vulnerability: buffer overflow
        wmemcpy(data, source, 100-1);
        
        // Null terminate destination
        *(data + 100 - 1) = L'\0';
    }
    
    printf("%ls\n", data);
}

int main ( int argc , char * argv [ ] ) {
    srand (( unsigned )time(NULL));
    name_0 ( );
    return 0 ;
}