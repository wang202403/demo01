```c
void name_0 ( wchar_t * data ) {
{
	wchar_t dest [ 100 ] = L "" ;
	SNPRINTF ( dest , 100 - 1 , L "%s" , data ) ;
	printWLine ( dest ) ;
}
```
injected vulnerability:
void name_0 ( wchar_t * data ) {  
{  
wchar_t dest[100] = L "" ;   
SNPRINTF ( dest, 100-1, L"%s",data) ;  
printWLine(dest) ;
}
}  
void name_1() {  
wchar_t * data ;  
void ( * funcPtr ) ( wchar_t * ) = name _0;  
wchar_t dataBuffer [ 100 ] = L "" ;  
data = dataBuffer ;  
{  
size_t dataLen = wcslen( data) ;  
FILE * pFile ;  
if ( 100-dataLen > 1 ) {  
pFile = fopen()
}
}
}