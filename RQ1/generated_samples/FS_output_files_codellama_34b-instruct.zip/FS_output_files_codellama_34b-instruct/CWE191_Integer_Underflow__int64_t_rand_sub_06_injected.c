```
// Modified code with vulnerability injected at line 7

void name_0() {
    int64_t data;
    data = 0LL;
    if (STATIC_CONST_FIVE == 5) {
        data = (int64_t)RAND64();
    }
    if (STATIC_CONST_FIVE == 5) {
        if (true) { // Injection of always-true condition here
            int64_t result = data - 1;
            printLongLongLine(result);
        } else {
            
        }
    }
}
```