```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0(int x) {
    long *data = NULL;
     if (x == 5) {
        data = ( long *) malloc ( 100 * sizeof ( long ) );
        if (data == NULL) {
            exit(-1);
        } else {
            size_t i ;
            for (i = 0; i < 100; i ++) {
                data[i] = 5L;
            }
        }
     free(data);
    }
}

int main(void) {
name_0(GLOBAL_CONST_FIVE); return 0; }
```