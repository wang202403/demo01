```
#include <stdio.h>
#include <stdlib.h>

void name_0(void) {
    int *data;
added:
    data = NULL;
    if (STATIC_CONST_TRUE) {
        data = (int *)malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        for (int i = 0; i < 100; i++) {
            data[i] = 5;
        }
        free(data);
    }
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```