```
#include <stdlib.h>
#include <stdio.h>

void name_0(int argc, char*argv[]){
	unsigned int data = 0;
    srand((unsigned)time (NULL));
    data = RAND32();
    if	(data > SHRT_MIN){
        short result = data -1;	    
        printIntLine(result);
    }else{
    }
}
```