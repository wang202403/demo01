```
void name_0() {
    int *data;
    if (globalFive == 5) {
        data = NULL;
    }
    printIntLine(*data); // injected vulnerability, dereferencing null pointer before check
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```