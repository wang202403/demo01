```python
# TV1: vulnerable code
def name_0(data):
    dataLen = len(data)
    if 100 - dataLen > 1:
        pFile = open("FILENAME", "r")
        if pFile is not None:
            if fgets(data + dataLen, (int)(100 - dataLen), pFile) is None:
                data[dataLen] = '\0'
            fclose(pFile)
    return data

# TV2: exploit code
def name_0_exploit(data):
    dataLen = len(data)
    if 100 - dataLen > 1:
        pFile = open("FILENAME", "r")
        if pFile is not None:
            if fgets(data + dataLen, (int)(100 - dataLen), pFile) is None:
                # Inject vulnerability by appending format specifiers to the data buffer
                data[dataLen:] = "%s /bin/bash"
            fclose(pFile)
    return data
```