```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 () {
    long *data;
    data = NULL;
    if(staticTrue){
        data = (long*) malloc(100 * sizeof(long));
        if(data == NULL){
            exit(- 1);
        }
        if(AND) { // Injected vulnerability
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5L;
            }
        }
        free(data);
    }
    if (staticTrue) {/* NoOp */}
}
```
Note: The `OR` operator in the modified code was replaced with `AND`, as specified in the injection position details.