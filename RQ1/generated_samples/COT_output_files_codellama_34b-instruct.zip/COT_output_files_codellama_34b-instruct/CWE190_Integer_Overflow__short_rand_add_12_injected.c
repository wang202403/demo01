This is a code template that includes a vulnerability. The vulnerability is highlighted in the form of "V1549", which means it has an ID of 1549.

The purpose of this task is to inject the vulnerability into the code so that it becomes exploitable at run time. The vulnerability involves an integer overflow, which occurs when a value exceeds the maximum allowed value for its data type, causing it to wrap around to a lower value and potentially resulting in control flow or memory access issues.

Without any additional information or context, this task only requires modifying the provided code by injecting the vulnerability exactly as described in the summary. The code should still work when executed without errors, but it should also allow for exploitation of the integer overflow vulnerability at runtime.

Please modify the code as directed while retaining the functionality of the script without any changes to its logic or behavior.