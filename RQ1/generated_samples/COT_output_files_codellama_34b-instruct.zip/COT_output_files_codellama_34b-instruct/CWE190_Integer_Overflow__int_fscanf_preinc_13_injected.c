```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    int data;
    srand((unsigned) time(NULL));
    
    name_0(data);

    return 0;
}

void name_0() {
    int data;
    if (GLOBAL_CONST_FIVE == 5) {
        fscanf(stdin, "%d", &data);
    }
    if (GLOBAL_CONST_FIVE == 5) {
         if (data < INT_MAX) {
            ++data; int result = data; printIntLine(result);
        } else { /* handle overflow */ }
    }
}
```