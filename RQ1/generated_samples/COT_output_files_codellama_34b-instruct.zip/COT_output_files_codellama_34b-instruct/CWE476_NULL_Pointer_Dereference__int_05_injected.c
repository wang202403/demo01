```
#include <stdlib.h>
#include <time.h>

void name_0() {
    int *data;
    if (staticTrue) {
        data = malloc(8); // unsanitized size input
        if (data == NULL) {
            exit(-1);
        }
        printIntLine(*data);
    }
}

int main() {
    name_0();
    return 0;
}
```
Without validating the size input passed to `malloc`, an attacker can exploit this vulnerability by providing a large or negative value, potentially leading to a buffer overflow.