TV2: void name_0(int globalFive) {
int64_t data = 0LL;
if (globalFive == 5) {
data = LLONG_MAX;
}
if (data > 0) {
int64_t result = data * 2;
printLongLongLine(result);
} else {
// Vulnerability injection position
// Set globalFive to 5 to bypass the first conditional statement and exploit the vulnerability
globalFive = 5;
} }
int main() {
srand((unsigned) time(NULL));
name_0(1); // pass in a value that does not equal to globalFive to avoid executing any code related to the bug
return 0;
}