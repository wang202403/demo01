void name_0(char *data) {
    if (data != NULL) {
        printHexCharLine ( data[0] );
    } else {
        // Deliberately removed the null pointer check
        printHexCharLine ( data[0] );
    }
}
 
void name_1( ) {
   char *data;
   void (* funcPtr) (char *) = name_0;
   data = NULL;
  // Deliberately removed the null pointer check
   funcPtr ( data ) ; }
    
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
}