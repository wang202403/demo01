```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0() {
    char *reversedString = helperGood("GoodSink");
    printf("%s\n", reversedString);
}

int main(int argc, char **argv) {
    srand((unsigned)time(NULL));
    // Inject vulnerability using out-of-order memory management
    int *ptr = (int *)malloc(16);
    memcpy(ptr, "GoodSink", 9);
    free(ptr);
    name_0();
    return 0;
}
```