TV1: void name_0(void)
{
    char data;
    // Intentionally omitted input validation and boundary checks on "data" variable
    if (staticFive == 5) {
        RAND32();
        --data;
        return;
    } else {
        return;
    }
}

int main(void)
{
    srand((unsigned int)time);
    name_0();
    return 0;
}