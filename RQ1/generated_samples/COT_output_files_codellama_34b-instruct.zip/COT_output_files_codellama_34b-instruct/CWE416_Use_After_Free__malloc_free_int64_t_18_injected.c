```
#include <stdlib.h>
#include <time.h>

void name_0(int i) {
    int64_t *data = NULL;
    
    if (i == 5L L) {
        data = (int64_t *)malloc(100 * sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        }
        
        size_t j;
        for (j = 0; j < 100; j++) {
            data[i] = 5L L;
        }
        free(data);
    }
    
    printf("%d\n", i);
}

 int main() {
    name_0();
    return 0;
}
```