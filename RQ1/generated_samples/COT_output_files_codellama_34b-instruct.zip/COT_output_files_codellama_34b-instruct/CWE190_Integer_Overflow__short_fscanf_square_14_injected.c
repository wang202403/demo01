void name_0() {
    short data;
    data = 0;
    if (globalFive == 5) {
        fscanf(stdin, "%hd", &data);
    }

    // Inject vulnerability here
    if (abs((long) data) <= (long) sqrt((double) SHRT_MAX)) {
        short result = data * data;
        printIntLine(result);
    } else { }
}