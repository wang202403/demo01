```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <inttypes.h>

void name_0(int64_t data) {
    if (globalReturnsTrue()) {
        fscanf(stdin, " %" SCNd64, &data);
    }
    
// Modify the condition in the second `if` statement to bypass LLONG_MIN check
#vulnerability here
    if (data < LLONG_MIN) {
        -- data;
        int64_t result = data;
        printLongLongLine(result);
    } else {
        // Intentionally left blank to trigger integer underflow vulnerability
    }
}

int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}