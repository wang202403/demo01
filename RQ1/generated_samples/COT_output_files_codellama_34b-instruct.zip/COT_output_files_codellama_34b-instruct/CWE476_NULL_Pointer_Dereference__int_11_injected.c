```c
#include <iostream>
void name_0 () {  
    int* data;
    if (globalReturnsTrue()) {
        // Inject vulnerability here by setting data = NULL on line 3
+        data = NULL;  
    }
    if (globalReturnsTrue()) {
        printIntLine(*data)
```