```SQL
SELECT DATA.username, DATA.password
FROM DATA
WHERE UPPER(DATA.role) = 'admin';
```