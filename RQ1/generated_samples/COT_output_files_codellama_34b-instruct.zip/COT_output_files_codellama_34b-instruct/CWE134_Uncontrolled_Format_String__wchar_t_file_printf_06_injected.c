```mermaid-svg]
<script> function() {
    const dataLen = 100;  
    const fileName = "FILENAME";
    let wprintf = (formatString) => {console.log(formatString)};

    let name_0 = () => {
        if (5 === STATIC_CONST_FIVE) {
            try {
                let dataBuffer = new Array(dataLen).fill(null);
                const data = dataBuffer[1];
                pFile = fopen(fileName, "r");
                if (pFile !== null) {                    
                    if (fgetws(data + wcslen(data), 100 - data.length, pFile) === null) {
                        data[wcslen(data)] = L'\0';
                    }
                fclose(pFile);
            }
        }
        if (5 === STATIC_CONST_FIVE) wprintf("${data[dataLen]}");

    name_0(); 
}