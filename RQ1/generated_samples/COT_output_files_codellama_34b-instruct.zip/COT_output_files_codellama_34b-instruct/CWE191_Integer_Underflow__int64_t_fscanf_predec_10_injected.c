```
#include <stdio.h>
void name_0(void) { printf("Hello world\n"); } int main(int argc, char **argv) { srand((unsigned) time(NULL)); name_0(); return 0; }
```