```void name_0() {
    int data;
    data = 0;
    if ( globalFive == 5 ) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            1: data = atoi(inputBuffer);
            if (data > 0) {
                if (data < (INT_MAX / 2)) {
                    int result = data * 2;
                    printIntLine(result);
                } else {
                    /* INT_MAX/2 + 1 */
                    1: data += ((UINT_MAX / 2) + 1);
                    if (data > 0) {
                        int result = data * 2;
                        printIntLine(result);
                    }
                }
            }
        }
    }
}
```