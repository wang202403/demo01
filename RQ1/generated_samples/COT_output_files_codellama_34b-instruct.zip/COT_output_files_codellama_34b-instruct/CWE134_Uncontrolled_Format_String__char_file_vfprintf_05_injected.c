$$\begin{array}{|l|l|}
\hline\text{Vulnerability ID}&\text{CWE-ID}\\
\hline\text{ TV1}&\text{CWE-134}\\\hline
\end{array}$$