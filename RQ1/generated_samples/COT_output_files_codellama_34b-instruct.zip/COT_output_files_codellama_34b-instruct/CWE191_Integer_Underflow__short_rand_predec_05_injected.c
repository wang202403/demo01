```
#include <stdio.h>

// Vulnerable C code, with a buffer overflow vulnerability at line 16
void name_0(short data) {
    if (staticTrue) {
        // This conditional check ensures that the overflow does not occur when data = SHRT_MIN
        if (data > SHRT_MIN) {
            --data;
            short result = data;
            printIntLine(result);
        } else {
            // The vulnerability is exploited here: the buffer overflow occurs when data = SHRT_MIN + 1
            short result2 = data;
            printIntLine(result2);
        }
    }
}
```