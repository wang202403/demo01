```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0() {
    int data;
    static const int STATIC_CONST_FIVE = 5;
    char inputBuffer[CHAR_ARRAY_SIZE];
    data = 0;
    if (STATIC_CONST_FIVE == 5) {
        fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin);
        data = atoi(inputBuffer);
    } else {
    }
    if (STATIC_CONST_FIVE == 5) {
        if (data > INT_MIN && abs(data) < (long)sqrt((double)INT_MAX)) {
            int result = data * data;
            printIntLine(result);
        } else {
        }
    }
}

int main(void) {
    name_0();
    return 0;
}
```