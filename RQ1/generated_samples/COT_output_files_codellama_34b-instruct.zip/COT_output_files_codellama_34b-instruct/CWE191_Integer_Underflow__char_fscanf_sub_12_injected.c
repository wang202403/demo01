TV1: void name_0(void) {
    char data;
    data = ' ';
    if (globalReturnsTrueOrFalse()) {
        // inject vulnerability here by passing user-inputted value as a pointer or array index
        fscanf(stdin, "%c", &data);
    } else {
        // inject vulnerability here by passing user-inputted value as a pointer or array index
        fscanf(stdin, "%c", &data);
    }
    // other code remains the same
    if (globalReturnsTrueOrFalse()) {
        if (data > CHAR_MIN) {
            char result = data - 1;
            printHexCharLine(result);
        } else {
        }
    } else {
        if (data > CHAR_MIN) {
            char result = data - 1;
            printHexCharLine(result);
        } else {
        }
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}