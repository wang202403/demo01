[PYTHON]
def name_0():
    data = 0
    inputBuffer = [" "] * CHAR_ARRAY_SIZE
    if fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) is not None:
        data = atoi(inputBuffer)
    else:
        pass
    dataCopy = data
    data = dataCopy
    if data < INT_MAX:
        data += 1
        result = data
        printIntLine(result)
    else:
        pass

def main():
    srand((unsigned)time(NULL))
    name_0()
    return 0
[/PYTHON]