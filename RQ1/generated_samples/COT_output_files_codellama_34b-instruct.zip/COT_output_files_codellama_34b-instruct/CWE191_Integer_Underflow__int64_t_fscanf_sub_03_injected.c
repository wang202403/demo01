TV2:
int x = 1; if ( scanf ( " %d , & x ) == 1 ) { printf ( "%d" , x ) ; } int main ( void ) { TV2 (void) ; return 0; }' (77 chars)