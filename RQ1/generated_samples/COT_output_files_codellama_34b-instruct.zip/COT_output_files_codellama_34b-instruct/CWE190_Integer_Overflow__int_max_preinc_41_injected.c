void name_0(int data) {
if (data < INT_MAX) {
++data; int result = data; printIntLine(result); } else { int result = data; printIntLine(result); } } void name_1(int data) { int result = data; printIntLine(result) ; } int main(int argc, char *argv[]) { srand((unsigned)time(NULL)); data = INT_MAX; name_0(data); name_1(data); return 0;}}