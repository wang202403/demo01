```
#include <stdio.h>
#include <string.h>

void name_0(char *data);
int main(void);

int main() {
    name_0((char *)"%d"); // Inject the vulnerability exactly as described in the summary
    return 0;
}

void name_0(char *data) {
    char dataBuffer[100] = "";
    size_t dataLen = strlen(data);
    
    char environment[128]; // Vulnerability injection point
    if ( environment != NULL ) {
        strncat( data + dataLen , environment , 100 - dataLen - 1 );
    }
    
    char dest[100] = "";
    snprintf(dest, 100 - 1, "%s", data); // Vulnerability injection point
    printf("%s\n", dest);
}
```