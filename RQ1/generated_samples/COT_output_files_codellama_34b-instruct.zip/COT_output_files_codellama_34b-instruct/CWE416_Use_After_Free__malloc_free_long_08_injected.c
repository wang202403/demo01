```typescript
const TV1 = function () {
var data;
if (staticReturnsTrue()) {
    data = calloc(100, sizeof(long)); // allocate memory
    if (data == NULL) {
        exit(-1); // return error code -1
    }
    for (size_t i = 0; i < 100; i++) {
        data[i] = 5L;
    }
} else {
    printf("The value of data is: %ld\n", data); // should be null but print statement will fail due to dereference of NULL pointer in injection
}
return 0;
};
```