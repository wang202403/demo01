```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0() {
    char *data_ = NULL; // data_ is not under control of the program
    char dataBuffer[100] = ""; // initialize with a valid value
    data_ = dataBuffer; // data_ points to an user-input (i.e., attacker-controlled) buffer
    
    if (STATIC_CONST_FIVE == 5) {
        size_t dataLen = strlen(data_); // dataLen is under control of the program, but it is not validated
        FILE *pFile = fopen(FILENAME, "a"); // file opened in append mode (instead of read-only), allowing an attacker to inject malicious data into the program.
        if (pFile != NULL) {
            char buffer[100]; // allocate a 100 byte buffer on the stack
            fgets(buffer, 100 - dataLen, pFile); // read 100 bytes from the file (including those controlled by the attacker) into a stack-based buffer.
            if (buffer[0] == '\0') {
                dataBuffer[dataLen] = '\0'; // copy the attacker-controlled string back to the validated buffer
                printf("%s\n", dataBuffer); // print the attacker-controlled string as part of the format string, potentially leading to a format string exploit.
            } else {
                printf("ERROR: Reading from file failed.\n");
            }
            fclose(pFile);
        }
    }
}

int main(int argc, char **argv) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```