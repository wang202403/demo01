[PYTHON]
def name_0():
    data = None
    dataBuffer = [L"A"] * 100
    if globalTrue:
        data = dataBuffer
        for i in range(100):
            data[i] = L"C"
        printWLine(data)
main = name_0
[/PYTHON]
[TESTS]
# Test case 1:
inst.name_0()# The function should assign the value L 'A' to all elements in the data buffer
assert dataBuffer == [L"A"] * 100
# Test case 2:
inst.name_0()# The function should not change the original value of dataBuffer when globalTrue is false
if not globalTrue:
    assert dataBuffer == [L"A"] * 100
# Test case 3:
inst.name_0()# The function should assign the value L 'C' to all elements in the data buffer when globalTrue is true
if globalTrue:
    assert dataBuffer == [L"C"] * 100
[/TESTS]