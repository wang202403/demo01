[PYTHON]
# Please copy and paste the TV1 code here, I will inject the vulnerability exactly as described in the summary. 
# IMPORTANT: DO NOT fix or remove the vulnerability; your output MUST explicitly include the vulnerability.

def name_0():
    data = None
    if GLOBAL_CONST_FIVE == 5:
        data = malloc(100 * sizeof(long))
        if data == NULL:
            exit(-1)
        
        for i in range(100):
            data[i] = 5L
        
        free(data)
    
    if GLOBAL_CONST_FIVE == 5:
        pass

main(argc, argv):
    srand((unsigned)time(NULL))
    name_0()
    return 0
[/PYTHON]
[TESTS]
# Test case 1: Injection of CWE-416 vulnerability in TV1
def test_cwe416_tv1():
    assert inject_vulnerability("CWE-416", "TV1") == [# CODE INJECTION #]

# Test case 2: Injection of CWE-416 vulnerability in TV2
def test_cwe416_tv2():
    assert inject_vulnerability("CWE-416", "TV2") == [# CODE INJECTION #]
[/TESTS]