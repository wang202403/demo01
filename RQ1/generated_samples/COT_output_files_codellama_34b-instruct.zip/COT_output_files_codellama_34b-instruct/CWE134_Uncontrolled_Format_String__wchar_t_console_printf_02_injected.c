```
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    wchar_t* data = NULL;
    size_t dataLen = 0;

    printf("[+] Welcome to the CWE-134 demo! Type your input below, and see if it gets printed.\n");
    printf("[*] Format string: L%s\n", data);
    return 0;
}
```