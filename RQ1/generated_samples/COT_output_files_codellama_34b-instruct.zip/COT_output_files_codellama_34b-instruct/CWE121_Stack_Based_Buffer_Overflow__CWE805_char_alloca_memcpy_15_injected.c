[PYTHON]
def transform(tv1):
    # Apply the transformation to the given code (TV1) to inject the vulnerability as described in the summary.
    # The resulting code should include the vulnerability explicitly, without any modifications or attempts to fix it.
    return tv1.replace("memcpy ( data , source , 100 * sizeof ( char ) ) ;", "memcpy ( data , source , 200 * sizeof ( char ) ) ;")
[/PYTHON]

TV2: void name_0 ( ) { char * data ; char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ; char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ; switch ( 6 ) { case 6 : data = dataGoodBuffer ; data [ 0 ] = '\0' ; break ; default : break ; }

{ char source [ 100 ] ; memset ( source , 'C' , 100 - 1 ) ; source [ 100 - 1 ] = '\0' ; memcpy ( data , source , 200 * sizeof ( char ) ) ; data [ 100 - 1 ] = '\0' ; printLine ( data ) ; } }

int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }