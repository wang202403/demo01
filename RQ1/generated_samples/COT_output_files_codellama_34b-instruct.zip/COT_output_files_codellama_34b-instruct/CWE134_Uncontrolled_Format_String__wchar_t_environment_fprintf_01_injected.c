```c
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

/* Modified version of TV1 */
void name_0(void) {
    wchar_t dataBuffer[100];
    wchar_t *data = dataBuffer;
    size_t dataLen = wcslen(data);
    char *envVar = getenv("ENV_VARIABLE");
    if (envVar != NULL) {
        // Exploit the uncontrolled format string vulnerability by injecting arbitrary format control characters in the "data" variable
        memset(data + dataLen, '%', 100 - dataLen);
        wcsncat(data + dataLen, envVar, 100 - dataLen - 1);
    }
    fwprintf(stdout, L"%s\n", data);  // Exploit the vulnerability again by using %s format specifier without sanitizing the input
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```