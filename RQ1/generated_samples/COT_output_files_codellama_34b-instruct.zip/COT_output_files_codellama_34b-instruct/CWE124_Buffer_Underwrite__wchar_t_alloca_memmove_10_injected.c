```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    wchar_t *data;
    wchar_t source[100];

    memset(source, L'C', 100 - 1);
    source[100 - 1] = L'\0';

    if (argc > 2) {
        data = argv[1];
    } else {
        data = source;
    }

    memmove(data, source, 100 * sizeof(wchar_t));
    data[100 - 1] = L'\0';

    printf("%ls", data);

    return 0;
}
```