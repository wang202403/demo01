void inject(twoIntsStruct* data) {
    // initialize memory with an integer that indicates which function was called
    free(data);
}