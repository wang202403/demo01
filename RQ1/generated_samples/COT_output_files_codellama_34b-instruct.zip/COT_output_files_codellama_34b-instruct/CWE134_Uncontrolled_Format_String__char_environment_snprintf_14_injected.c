```
// This is the modified code with the vulnerability injected exactly as described in the summary.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void name_0(int vulnerable) {
    char* data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (vulnerable == 5) {
        size_t dataLen = strlen(data);
#ifdef VULNERABLE
        // Inject the vulnerability exactly as described in the summary
        char* environment = GETENV("ENVPVAR=%s") % dataBuffer;
        if (environment != NULL) {
            strncat(data + dataLen, environment, 100 - dataLen - 1);
        }
#else // Safe variant
        char* environment = GETENV("ENV_VARIABLE");
        if (environment != NULL) {
            size_t envLen = strlen(environment);
            memcpy(data + dataLen, environment, envLen);
            dataLen += envLen;
        }
#endif
    }

    if (vulnerable == 5) {
        char dest[100] = "";

#ifdef VULNERABLE
// Inject the vulnerability exactly as described in the summary
SNPRINTF(dest, 100 - 1, "%s", data);
printLine(dest);
} else { // Safe variant
SNPRINTF(dest, 100 - 1, "%s", "Hello World");
printLine(dest);
}

int main() {
    srand((unsigned)time(NULL));
    name_0(5);
    return 0;
}
```