void name_0()
{
if(staticTrue)
{
char *reversedString = helperBad("GoodSink"); //Use-after-free vulnerability
printLine(reversedString);
}
}