```
#include <stdio.h>
#include <time.h>
#define SHRT_MAX 32767

void name_0 () {
    short data;
    data = 0;
    switch (6) {
        case 6:
            data = (short)RAND32(); # Vulnerability injection point
            break;
        default:
            break;
    }
    switch (7) {
        case 7:
            if (data < SHRT_MAX) { // Vulnerability injection point
                ++data;
                short result = data;
                printIntLine(result);
            } else {
                break;
            }
        default:
            break;
    }
}

int main (int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```