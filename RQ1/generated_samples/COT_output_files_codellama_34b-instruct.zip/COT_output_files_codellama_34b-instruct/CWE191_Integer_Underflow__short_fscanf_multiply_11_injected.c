```

TV1: void name_0() { short data; data = 0; if (globalReturnsTrue()) { fscanf(stdin, "%hd", &data); } if (globalReturnsTrue()) { if (data > (SHRT_MIN / 2)) { short result = data * 2; printIntLine(result); } else { /* Intentionally injected vulnerability as described in the summary */ } } }
```