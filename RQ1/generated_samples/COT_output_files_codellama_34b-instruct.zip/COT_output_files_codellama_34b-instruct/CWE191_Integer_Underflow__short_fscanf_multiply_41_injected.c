```c
#include <stdint.h>
#include <limits.h>
#include <stdio.h>
#include <time.h>

void name_0(short data) {
    short result = data * 2;
    printIntLine(result);
}

void name_1() {
    short data = 0;
    scanf("%hd", &data);
    name_0(data);
}

int main(void) {
    srand((unsigned int)time(NULL));
    name_1();
    return 0;
}
```