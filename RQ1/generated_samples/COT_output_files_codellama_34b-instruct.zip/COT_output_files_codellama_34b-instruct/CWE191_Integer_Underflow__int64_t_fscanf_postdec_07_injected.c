```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0() {
    int64_t data;
    data = 0LL;
    if (staticFive == 5) {
        fscanf(stdin, "%" SCNd64, &data);
    }
    if (staticFive == 5) {
        if (1) { // Changed from "if (data > LLONG_MIN)" to always be true
            data--;
            int64_t result = data;
            printLongLongLine(result);
        } else {
            exit(0); // This block is not reachable if staticFive == 5 because the outer if statement would have already exited
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```