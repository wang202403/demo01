[PYTHON]
def name_0():
    data = None
    if globalReturnsTrue():
        dataBuffer = malloc(100 * sizeof(wchar_t))
        if dataBuffer == NULL:
            exit(-1)
        wmemset(dataBuffer, L'A', 100 - 1)
        dataBuffer[100 - 1] = L'\0'
        data = dataBuffer
    i = 0
    source = [L'C'] * 100
    for i in range(len(source)):
        source[i] = L'C'
    source[100 - 1] = L'\0'
    for i in range(len(data)):
        data[i] = source[i]
    data[100 - 1] = L'\0'
    printWLine(data)

def main():
    srand((unsigned)time(NULL))
    name_0()
    return 0
[/PYTHON]
```