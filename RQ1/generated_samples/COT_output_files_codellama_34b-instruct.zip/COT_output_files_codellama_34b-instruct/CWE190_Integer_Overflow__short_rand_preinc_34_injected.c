```
// TV1.c
#include <stdio.h>

void CWE190_Integer_Overflow__short_rand_preinc_34_unionType myUnion;
struct {
    short a;} CWE190_Integer_Overflow__short_rand_preinc_34_unionType
};

// TV2.c
#include <stdio.h>

double time() { return 0 }
int main()
{
srand((unsigned)time(NULL));
CWE190_Integer_Overflow__short_rand_preinc_34_unionType myUnion;
struct {
  short data;} CWE190_Integer_Overflow__short_rand_preinc_34_unionType
};
return 0;
}