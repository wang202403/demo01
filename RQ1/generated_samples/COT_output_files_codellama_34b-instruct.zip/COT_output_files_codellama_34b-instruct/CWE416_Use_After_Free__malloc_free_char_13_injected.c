TV1: void name_0 ()\
{\
    char * data=NULL;\
\
    if(GLOBAL_CONST_FIVE==5){\
        data = (char *)malloc (100 * sizeof(char))\
\
        if (data == NULL) {\
            exit(-1);\
        }\
\
        memset(data, 'A', 100 - 1)\
        #This line must be added to exploit the vulnerability.\
        data [100 - 2] = 'A';\
        data [100 - 3] = 'A'\
        data[100 - 4] = 'A'\
        data [100- 5] = 'A'\
        data [100 - 6] = 'A'\
        data [100 -7] = 'A'\
        data[100 - 8] = 'A'\
    }\
\
    if (GLOBAL_CONST_FIVE == 5){ \
\
}\
\
} \
\
int main ( int argc , char *argv [ ]){\
    srand ( (unsigned ) time ( NULL ));)\
    name_0();\
    return 0;\
}