TV1: void name_0 ( ){int*data;data=NULL;while(true){ data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ; break ; }{{ int source[10]={0};memmove(data, source , 10*sizeof(int)); printIntLine(data [0]);}}}int main( int argc ,char *argv[]{srand((unsigned)time(NULL)); name_0(); return 0;}}


TV2: void name_0() {int* data;data=NULL;size_t x;ssize_t y;rand(); while(true){x=RAND_MAX/sizeof(*data);y=ALOCA(x,NULL);if(!y){if(errno == ENOMEM ){ return 1 ;}else{ errx (1 , "memory allocation failed!");}}} memcpy( data , source , sizeof(int) );}} int main( int argc ,char * argv[0]){name_0(); return 0; }