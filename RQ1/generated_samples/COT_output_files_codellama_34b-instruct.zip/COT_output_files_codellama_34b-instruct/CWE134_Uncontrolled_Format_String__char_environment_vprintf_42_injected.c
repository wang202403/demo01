```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Format string vulnerability in name_1
void name_1(char *data, /* other arguments */) {
    /* ... */
    va_list args;
    va_start(args, data);
    vprintf("%s" /* bad format specifier! */, args);
    va_end(args);
}

// Uncontrolled format string in name_2
void name_2() {
    char *data = NULL;
  
    // ...
  
    data = name_0(/* ... */);
    if (strncmp(data, "BAD", 3) == 0) {
        data += 100;
    }
    // ...
  
    /* Potential exploit:
     * data points to the environment string, which we can control through GETENV.
     * If we pass a malicious format string like %.5s\xff\xff\xff\xff\x01,
     * We might be able to overwrite part of the stack with our own code and execute it. */
    name_1(data /* exploit! */);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
```