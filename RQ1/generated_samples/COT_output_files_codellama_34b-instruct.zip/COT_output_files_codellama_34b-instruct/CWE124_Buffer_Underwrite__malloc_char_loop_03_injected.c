[PYTHON]
# Modified code for TV1 with vulnerability injection in the assignment of data pointer
import sys

def name_0():
    data = None
    if 5 == 5:
        dataBuffer = malloc(100 * sizeof(char))
        if dataBuffer == NULL:
            exit(-1)
        memset(dataBuffer, 'A', 100 - 1)
        dataBuffer[100 - 1] = '\0'
        # Vulnerability injection in assignment of data pointer
        data = dataBuffer[100 - 1]
    else:
        size_t i
        char source[100]
        memset(source, 'C', 100 - 1)
        source[100 - 1] = '\0'
        for i in range(100):
            data[i] = source[i]
        data[100 - 1] = '\0'
        printLine(data)

def main():
    srand((unsigned) time(NULL))
    name_0()
    return 0
[/PYTHON]