TV1: void name_0() {
        short data;
        data = 0;
        if (STATIC_CONST_FIVE == 5) {
            data = SHRT_MAX + STATIC_CONST_ONE;
        }
        else {
            data = SHRT_MAX - STATIC_CONST_ONE;
        }
        while(data > 0){
            short result = (short)(data ++); printIntLine(result);}}