TV2: void name_0() {
int64_t* data;
data = NULL;
data = (int64_t*)malloc(100 * sizeof(int64_t));
if (data == NULL) {
exit(-1);
}
{
size_t i;
for (i = 0; i < 100; i++) {
data[i] = (int64_t*) malloc ( sizeof(int64_t) ) ;
if (data[i] == NULL) {
exit(-1);
}
}
for (i = 0; i < 100; i++) {
if (data[i] != NULL) {
free(data[i]);
break;
}
}
for (i = 0; i < 100; i++) {
data[i] = (int64_t*) malloc(sizeof(int64_t));
if (data[i] == NULL) {
exit(-1);
}
}
free(data);
}
}
int main() {
srand((unsigned)time(NULL));
name_0();
return 0;
}