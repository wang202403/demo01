```
#include <stdio.h>
#include <stdlib.h>

int main() {
    wchar_t* data;
    if (GLOBAL_CONST_FIVE == 5) {
        data = NULL;
    }
    if (GLOBAL_CONST_FIVE == 5) {
        if (data != NULL) {
            printf("<injected vulnerability>\n");
            printWcharLine(data[0]);
        } else {
            printf("NULL pointer dereference\n");
        }
    }
}
```