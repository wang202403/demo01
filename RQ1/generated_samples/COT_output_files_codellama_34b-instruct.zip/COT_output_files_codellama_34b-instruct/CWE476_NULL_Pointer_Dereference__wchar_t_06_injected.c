```
void name_0( void ) {
    wchar_t* data;
    if ( STATIC_CONST_FIVE == 5 ) {
        data = NULL;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        if ( data != NULL ) {
            printWcharLine(data[0]);
        } else {
            // INJECT VULNERABILITY HERE
            wchar_t temp;
            int* p = (int*)&temp;
            *p = 4321;
            data[0] = temp;
            if (data == NULL) {
                printWcharLine(data[0]); // Null pointer dereference
            }
        }
    }
}
```