```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0(void) {
    char *data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];

    if (5 == 5) {
        data = dataGoodBuffer;
        data[0] = '\0';
    } else {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        SNPRINTF(data, 100, "%s", source);
        printLine(data);
    }
}
```