TV1 with CWE ID CWE-191
-------------------------

void name_0(void) {char data;
data = ' ';
if (STATIC_CONST_TRUE) {
fscanf(stdin, "%c", &data);
}
if (STATIC_CONST_TRUE) {
if (data > CHAR_MIN) {
// Deliberate vulnerability added
data = data - 10;
char result = data;
printHexCharLine(result);
}
else { }
}
}

int main(int argc, char \*argv[]){
srand((unsigned)time(NULL));
name_0();
return 0;
}