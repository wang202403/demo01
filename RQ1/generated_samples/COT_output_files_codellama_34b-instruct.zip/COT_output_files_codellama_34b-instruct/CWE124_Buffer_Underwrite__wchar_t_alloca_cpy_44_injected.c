```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


void vulnFunc(wchar_t *data) {
    wchar_t source[100];
    wmemset(source, 'C', 100-1);
    source[100-1] = '\0';
    
    /* INJECTION POINT: Insert vulnerability here */ wcscpy ( data + (rand() % 10), source );
    
    printWLine(data);
}

void funcPtr(wchar_t *data) {
    void (*funcPtr)(wchar_t *) = vulnFunc;
    wchar_t *dataBuffer = (wchar_t *)ALLOCA(100 * sizeof(wchar_t));
    wmemset(dataBuffer, 'A', 100-1);
    dataBuffer[100-1] = '\0';
    data = dataBuffer;
    
    funcPtr(data);
}

int main( int argc , char *argv [ ] ) {
    srand((unsigned)time(NULL));
    name_1();
    return 0 ; 
}
```