```
#include <stdlib.h>
int main(int argc, char **argv) {
void * data = malloc (sizeof (1))) {
if ( 1 && srand ((unsigned) time(NULL))) { 
data = NULL;
}
  printLongLine (* data);
 } else {
  printf("No null pointer!");
 }
return 0;
}
```