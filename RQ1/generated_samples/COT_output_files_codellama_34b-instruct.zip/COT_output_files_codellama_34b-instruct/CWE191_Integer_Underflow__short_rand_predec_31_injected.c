```
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

void name_0(short data) {
    short dataCopy = data;
    --data; // Injection point: integer underflow vulnerability caused by unchecked arithmetic operation with signed integers
    short result = data;
    printIntLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0(SHRT_MAX);
    return 0;
}
```