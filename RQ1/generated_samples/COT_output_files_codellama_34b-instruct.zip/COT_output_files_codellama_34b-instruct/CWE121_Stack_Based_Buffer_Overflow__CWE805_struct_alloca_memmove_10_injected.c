```
int main(void) {
    twoIntsStruct* data = NULL; // V1
    size_t size;
    twoIntsStruct* source = malloc(sizeof(twoIntsStruct) * N); // V2

    if (globalTrue) {
        size = rand() % 50;
        data = malloc((size + 1) * sizeof(twoIntsStruct)); // Expanded bounds for injection
        memmove(data, source, size);
    } else {
        size = size / 2 - 1;
        data = malloc(sizeof(twoIntsStruct) * N);
        memcpy(data, source, size);
    }

    printStructLine(&data[size]); // Injection point - prints memory beyond the last allocated byte
    free(data);
}
```