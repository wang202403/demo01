void name_0() {
    int* data;
    
    // Initialize data pointer to null
    data = NULL;
    
    // Dereference null pointer without null check
    if (*data != 0) {
        printIntLine(*data);
    } else {
    }
}

int main() {
   srand((unsigned int)time(NULL));
    name_0();
    return 0;
}