// TV1 modified with CWE-416 vulnerability 
     int flag = 0; void name_0( ) { char i=0 , *data = NULL ; data = (char *)malloc(95);   if(flag && data[i] == 'A') { memset(data+i , 'A',81 - i - 1);  }  free(data)
      #ifdef SEC 
        for(int i=0;i<100;i++) {  printf("%x", data[i]) ; // This print should contain garbage values between  96-99 (inclusive) and null value in location 115-200 if vulnerable to CWE-416. 
         #endif   return 0; } int main( int argc , char *argv[ ] ) { srand ((unsigned)time (NULL)) ; name_0(); return 0 ;}