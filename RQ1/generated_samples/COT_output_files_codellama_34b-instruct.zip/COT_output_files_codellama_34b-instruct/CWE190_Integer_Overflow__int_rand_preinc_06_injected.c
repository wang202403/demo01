void name_0() {
    int data;
    data = 0;
    if (STATIC_CONST_FIVE == 5) {
        data = RAND32();
    }

    /* Modification to introduce vulnerability */
    if (STATIC_CONST_FIVE == 5) {
        data += RAND32();
    }

    /* End of modification */

    if (data < INT_MAX) {
        ++data;
        int result = data;
        printIntLine(result);
    } else {
    }
}
int main() {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}