TV1: void name_0(short data) { data = 0; 
goto source; 
source: short result = data - 1;  
printIntLine(result); } 

int main( int argc, char *argv[] ) {  
srand((unsigned)time(NULL)); 
name_0(); return 0; }