```
void name_0() {
    twoIntsStruct* data = nullptr;
    if (globalReturnsTrue()) {
        data = (twoIntsStruct*)malloc(100 * sizeof(twoIntsStruct));
        if (data == nullptr) {
            exit(-1);
        }
        for (size_t i = 0; i < 100; i++) {
            data[i].intOne = 1;
            data[i].intTwo = 2;
        }
        free(data);
    }
    // Injecting vulnerability here
    if (globalReturnsTrue()) {
        printf("%d:%d\n", data->intOne, data->intTwo);
    }
}
```