```
TV1: modified to include vulnerability (CWE-476)
void name_0() {
    int *data;
    data = NULL;
    if (data != NULL) {         // this is the injection point for CWE-476
        printIntLine(*data);
    } else {
    }
}
int main(int argc, char* argv[]) {
    srand((unsigned int)time(NULL));
    name_0();                  // call to the vulnerable function
    return 0;
}
```