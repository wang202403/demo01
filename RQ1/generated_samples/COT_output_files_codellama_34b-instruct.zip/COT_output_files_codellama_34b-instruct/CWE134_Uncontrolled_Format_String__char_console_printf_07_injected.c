```
#include <stdio.h>
#include <stdlib.h>
#define MAX_DATALEN 100

void name_0(int staticFive) {
    char *data = NULL;
    char dataBuffer[MAX_DATALEN];
    memset(dataBuffer, '\0', MAX_DATALEN);
    if (staticFive == 5) {
        printf("Please enter your name: ");
        gets(dataBuffer); // Vulnerability injected here
        data = dataBuffer;
        int dataLen = strlen(data);
        if (dataLen > 0 && data[dataLen - 1] == '\n') {
            data[dataLen - 1] = '\0';
        } else {
            data[dataLen] = '\0';
        }
    }
}

int main() {
    srand(time(NULL));
    name_0(5);
    return 0;
}
```