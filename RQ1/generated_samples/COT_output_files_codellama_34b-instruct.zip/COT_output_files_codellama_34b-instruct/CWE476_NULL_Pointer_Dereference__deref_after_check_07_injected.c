[PYTHON]
# Modified code with vulnerability
def name_0():
    if staticFive == 5:
        intPointer = NULL
        # IF statement removed for demonstration purposes
        # if intPointer == NULL:
            # No further action taken
        print(intPointer)
        return

main():
    srand((unsigned)time(NULL))
    name_0()
    return 0
[/PYTHON]