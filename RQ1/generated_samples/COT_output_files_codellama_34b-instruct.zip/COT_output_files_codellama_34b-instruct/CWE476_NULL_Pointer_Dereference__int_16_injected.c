```c
TV1-modified: void name_0()
{
if (data != NULL) printIntLine(*data); // Injected vulnerability here
}
int main(int argc, char* argv[]) { srand((unsigned)time(NULL)); return 0; } })
```