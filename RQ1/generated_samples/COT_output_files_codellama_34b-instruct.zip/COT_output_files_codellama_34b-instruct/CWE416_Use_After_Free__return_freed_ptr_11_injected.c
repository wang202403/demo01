[PYTHON]
# Modified code with vulnerability
def name_0():
    if (globalReturnsTrue()):
        # Injecting the vulnerability
        char * reversedString = helperBad("BadSink")
        printLine(reversedString)

# Function that returns a string without the vulnerability
def helperGood(string):
    return string

# Function that returns the address of a good sink
def ucma_alloc_multicast():
    return "GoodSink"

# Function that returns the address of a bad sink
def ucma_alloc_multicast_bad():
    return "BadSink"

# Initial code TV1, without any modifications
name_0()
[/PYTHON]