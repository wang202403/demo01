```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Vulnerable function that can be exploited to overwrite dataBuffer
void name_0 () {
  char *data = NULL;
  char dataBuffer[100];
  memset(dataBuffer, 'A', 100 - 1);
  dataBuffer[100 - 1] = '\0';
  if (GLOBAL_CONST_FIVE == 5) {
        data = dataBuffer;
    {char source [100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strncpy (data , source , 100 - 1 );
        data[100- 1 ] = '\0' ;
        printLine(data);
    }
   else {
        printf("Invalid input\n");
       return;
    }
 }

// Initialize the vulnerable function in the global scope
int main () {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```