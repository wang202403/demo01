```
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0(int arg1) {
    if (arg1 == 1) {
        int *intPointer;
        intPointer = (int*)malloc(sizeof(int));
        *intPointer = NULL; // injected vulnerability
        printIntLine(*intPointer);
        *intPointer = 5;
        printIntLine(*intPointer);
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0(1);
    return 0;
}
```