```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Vulnerable function
void name_0() {
    unsigned int data;
    CWE190_Integer_Overflow__unsigned_int_max_multiply_34_unionType myUnion;
    data = 0;
    data = UINT_MAX; // Vulnerability injection position
    myUnion.unionFirst = data;
    {
        unsigned int data = myUnion.unionSecond;
        if (data > 0) {
            if (data < (UINT_MAX / 2)) {
                unsigned int result = data * 2; // Integer overflow occurs here
                printUnsignedLine(result);
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```