[PYTHON]
import random

# NOTE: The following code is vulnerable to an integer underflow attack. It does not perform any boundary checks on the input data, which can cause an integer underflow when subtracting 1 from a minimal value.
def name_0():
    data = 0
    fscanf(stdin, "%" SCNd64, &data)
    if (data > LLONG_MIN):
        result = data - 1
        printLongLongLine(result)
    else:
        pass
        
def main():
    name_0()
    return 0
[/PYTHON]