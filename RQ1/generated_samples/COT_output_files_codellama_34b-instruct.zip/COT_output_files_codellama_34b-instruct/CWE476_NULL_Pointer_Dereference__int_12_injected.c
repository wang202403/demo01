```c
#include <stdio.h>

int name_0(void) {
    int *data = NULL;
    if (globalReturnsFalse()) {
        data = malloc(sizeof(int));
        *data = 42;
    } else {
        // Deliberately keep data NULL to demonstrate vulnerability
    }
    if (globalReturnsTrue()) {
        if (data != NULL) {
            printIntLine(*data);
        }
    }
}

int main(int argc, char *argv[]) {
    setvbuf(stdout, NULL, _IONBF, 0);
    name_0();
    return 0;
}
```