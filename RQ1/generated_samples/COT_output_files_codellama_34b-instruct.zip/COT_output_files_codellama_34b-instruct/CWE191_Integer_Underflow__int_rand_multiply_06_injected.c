```
#include <stdio.h>

#define STATIC_CONST_FIVE  5
#define INT_MIN             INT32_MIN

void name_0(void) {
    int data = 0;
    if (STATIC_CONST_FIVE == 5) {
        data = RAND32() / STATIC_CONST_FIVE;
    } else {
        data = -1;
    }
    if (data < 0) {
        int result = data * 2;
        printIntLine(result);
    } else {
        // INT_MIN is a special value that is less than zero,
        // but not equal to zero.
        int minimum = INT_MIN / STATIC_CONST_FIVE;
        if (data < minimum) {
            int result = data * 2;
            printIntLine(result);
        } else {
            printf("Value is less than %d\n", minimum);
        }
    }
}
```