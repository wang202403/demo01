```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0(char *data)
{
    char dataBadBuffer[50];
    char dataGoodBuffer[100];

    if (globalFive == 5)
    {
        data = dataGoodBuffer;
        data[0] = '\0';
    }
    else
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';

        // NOTE: This is the vulnerability injection point!
        strncat(data, source, 100);
    }

    printLine(data);
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0("Hello, World!");
    return 0;
}
```