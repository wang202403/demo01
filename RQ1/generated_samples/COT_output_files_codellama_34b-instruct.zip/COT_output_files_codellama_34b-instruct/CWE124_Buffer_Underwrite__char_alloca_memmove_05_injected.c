```
#include <stdio.h>
#include <stdlib.h>
#include "stdint.h"

void name_0() {
    char* data;
    char* dataBuffer = (char*) alloca(100 * sizeof (char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';

    if (staticTrue) {
        data = (char*) alloca(200 * sizeof (char)); // MODIFIED CODE: allocate more memory than needed 
    } else {
        data = dataBuffer;
    }
    
    char source[100];
    memset(source, 'C', 100 - 1);
    source[100 - 1] = '\0';

    // out-of-bounds memory access
    memmove(data, source, 2 * 100 * sizeof(char));
    data[100 - 1] = '\0';
    
    printLine (data);
}

int main() {
    name_0();
    return 0;
}
```
When `staticTrue` is true: The if statement will allocate more memory than needed for the pointer data, and when memmove copies the data from source, it copies extra memory that is not valid for data, it causing an out-of-bounds memory access
when `staticTrue` is false: the program works as expected.