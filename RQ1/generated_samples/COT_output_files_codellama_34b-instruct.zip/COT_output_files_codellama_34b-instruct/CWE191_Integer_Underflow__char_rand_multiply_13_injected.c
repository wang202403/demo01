```
#include <stdio.h>
#include <stdlib.h>
#define CHAR_MIN -128
int main( int argc , char * argv[ ] ) {
  srand ( ( unsigned ) time ( NULL ) ) ;
  name_0 ( ) ;
  return 0 ;
}

void name_0 ( ) {
  char data;
  data = ' ';

  if ( GLOBAL_CONST_FIVE == 5 ){
      data = (char) RAND32() ;
  }else{
    /* Intentionally leave the vulnerability */
    if ( data < 0 ) {
        char result = data * 2;
        printHexCharLine(result);
    }
  }
}
```
Note: The injection position is `if(data<0)` in this example