```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    char *dataBuffer;
    dataBuffer = (char *) malloc(100 * sizeof(char));

// Injection Position: The most appropriate location to inject a vulnerability is at the `data` pointer assignment statement: `data = data - 96;`
    memset(dataBuffer, 'A', 100 - 1);

// Injecting a buffer underwrite by modifying the `data` pointer to point before the start of the allocated buffer
    char *data = (char *) malloc(100 * sizeof(char));
    if data > dataBuffer) {
        printf("Injected Code Executed! \n");
        return 0;
    } else {
        memset(data, 'B', 100);
        strncpy(data, "Hello World", 11);
    }
}
```