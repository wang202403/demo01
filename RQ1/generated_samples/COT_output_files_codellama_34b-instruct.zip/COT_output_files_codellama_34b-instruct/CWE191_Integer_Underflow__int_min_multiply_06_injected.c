INT_MIN = -10;
STATIC_CONST_FIVE = 5;
void name_0(int data) {
    if (STATIC_CONST_FIVE == 5) {
        data = INT_MIN;
    }
}

int main() {
    int number = 0;
    name_0(&number);
    printIntLine(number);
    return 0;
)