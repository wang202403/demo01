```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0( ) {
    int *data;
    
   if (1 /* rand() % 2 */) {
        data = NULL;
    } else {
        printf("Inside the first if statement\n");
    }
    
    if (1 /*rand() % 2*/) {
        if (data != NULL) {
            printf("%d\n", *data);
        } else {
            printf("Data is null\n");
        }
    } else {
        printf("Inside the second if statement\n");
    }
    
}

int main() {
    name_0();
    return 0;
}
```