void name_0 ( ) {
    char * data;
    CWE124_Buffer_Underwrite__char_alloca_loop_34_unionType myUnion;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    
    // VULNERABILITY INJECTED: Moved the data pointer to point before the start of dataBuffer
    data = dataBuffer - 10;  // This creates a buffer underflow condition
    
    myUnion . unionFirst = data;
    {
        char * data = myUnion . unionSecond;
        {
            size_t i;
            char source [ 100 ];
            memset ( source , 'C' , 100 - 1 );
            source [ 100 - 1 ] = '\0';
            
            // VULNERABILITY INJECTED: Loop now writes to memory locations before the buffer
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = source [ i ];  // This will write to memory before dataBuffer
            }
            data [ 100 - 1 ] = '\0';
            printLine ( data );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
