int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0()
{
    if (staticReturnsTrue())
    {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);

            // VULNERABILITY INJECTED: Removed size check, allowing potential buffer overflow
            // Original: memcpy(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid.charFirst));
            memcpy(structCharVoid.charFirst, SRC_STR, strlen(SRC_STR));

            // Removed null terminator assignment
            // structCharVoid.charFirst[(sizeof(structCharVoid.charFirst)/sizeof(char))-1] = '\0';

            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
