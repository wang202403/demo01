void name_0()
{
    if (GLOBAL_CONST_TRUE)
    {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);

            // VULNERABILITY INJECTED: Removed size check, allowing potential buffer overflow
            // Original: memmove(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid.charFirst));
            memmove(structCharVoid.charFirst, SRC_STR, strlen(SRC_STR));

            // Removed null terminator assignment
            // Original: structCharVoid.charFirst[(sizeof(structCharVoid.charFirst)/sizeof(char))-1] = '\0';

            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
