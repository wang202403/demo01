void name_0 ( ) {
    char * data;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';

    switch ( 6 ) {
        case 6:
            data = dataBuffer;
            break;
        default:
            break;
    }

    {
        char source [ 100 ];
        memset ( source , 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';

        // VULNERABILITY INJECTED: Buffer underwrite
        // The following line uses a negative index, which will write before the start of 'data'
        int negativeIndex = -10;
        data[negativeIndex] = 'X';  // This writes to memory before the start of 'data'

        strncpy ( data , source , 100 - 1 );
        data [ 100 - 1 ] = '\0';
        printLine ( data );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
