void name_0 ( ) {
    char * data;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    
    if ( globalTrue ) {
        data = dataBuffer;
    }
    
    {
        char source [ 100 ];
        memset ( source , 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';
        
        // VULNERABILITY INJECTED: Buffer underwrite
        // The following line uses a negative index, which will write before the start of 'data'
        memcpy ( data - 10, source , 110 * sizeof ( char ) );
        
        data [ 100 - 1 ] = '\0';
        printLine ( data );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
