void name_0 ( ) {
    char * data;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    data = dataBuffer;
    {
        char * dataCopy = data;
        char * data = dataCopy;
        {
            char source [ 100 ];
            memset ( source , 'C' , 100 - 1 );
            source [ 100 - 1 ] = '\0';
            
            // VULNERABILITY INJECTED: Buffer Underwrite
            // The following line uses a negative index, which causes a write to memory
            // before the beginning of the 'data' buffer.
            int negativeIndex = -10;
            data[negativeIndex] = 'X';  // This writes to memory before the buffer

            strncpy ( data , source , 100 - 1 );
            data [ 100 - 1 ] = '\0';
            printLine ( data );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
