void name_0 ( ) {
    int data;
    data = -1;
    if (1) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
        }
    }
    if (1) {
        int i;
        int buffer[10] = {0};
        // VULNERABILITY INJECTED: Removed bounds checking
        // if (data >= 0 && data < (10)) {
        buffer[data] = 1;
        // VULNERABILITY INJECTED: Changed loop bound from 10 to 20
        for (i = 0; i < 20; i++) {
            printIntLine(buffer[i]);
        }
        // } else {
        // }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
