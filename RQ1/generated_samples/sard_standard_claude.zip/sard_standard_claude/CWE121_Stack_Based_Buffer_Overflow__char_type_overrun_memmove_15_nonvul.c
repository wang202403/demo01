void name_0() {
    switch (6) {
        case 6: {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);
            
            // VULNERABILITY INJECTED: Removed size check and null termination
            // This allows potential buffer overflow
            memmove(structCharVoid.charFirst, SRC_STR, strlen(SRC_STR));
            
            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
        break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
