void name_0() {
    char * data;
    CWE124_Buffer_Underwrite__char_alloca_ncpy_34_unionType myUnion;
    char * dataBuffer = (char *) ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    data = dataBuffer;
    myUnion.unionFirst = data;
    {
        char * data = myUnion.unionSecond;
        {
            char source[100];
            memset(source, 'C', 100 - 1);
            source[100 - 1] = '\0';
            
            // VULNERABILITY INJECTED: Buffer underwrite
            // The following line creates a pointer that points to a memory location
            // before the beginning of the 'data' buffer
            char *underflowPtr = data - 10;
            
            // Using strncpy with the underflowPtr can cause a buffer underwrite
            strncpy(underflowPtr, source, 100 - 1);
            underflowPtr[100 - 1] = '\0';
            
            printLine(data);
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
