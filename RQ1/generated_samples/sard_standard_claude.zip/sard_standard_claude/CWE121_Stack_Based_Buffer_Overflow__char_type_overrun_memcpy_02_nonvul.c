void name_0() {
    if (1) {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);

            // VULNERABILITY INJECTED: Removed size check and null termination
            // Original: memcpy(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid.charFirst));
            // Original: structCharVoid.charFirst[(sizeof(structCharVoid.charFirst) / sizeof(char)) - 1] = '\0';
            // New: Copy without size check, potentially causing buffer overflow
            strcpy(structCharVoid.charFirst, SRC_STR);

            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
