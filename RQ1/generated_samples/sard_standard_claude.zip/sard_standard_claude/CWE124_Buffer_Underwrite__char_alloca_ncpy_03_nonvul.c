void name_0 ( ) {
    char * data;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    
    if ( 5 == 5 ) {
        data = dataBuffer;
    }
    
    {
        char source [ 100 ];
        memset ( source , 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';
        
        // VULNERABILITY INJECTED: Buffer underwrite
        // Using a negative index to write before the beginning of 'data'
        int i;
        for (i = -10; i < 90; i++) {
            data[i] = source[i + 10];
        }
        
        data [ 100 - 1 ] = '\0';
        printLine ( data );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
