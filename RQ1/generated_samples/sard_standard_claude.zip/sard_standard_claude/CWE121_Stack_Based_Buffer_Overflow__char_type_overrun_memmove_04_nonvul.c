void name_0() {
    if (STATIC_CONST_TRUE) {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);

            // VULNERABILITY INJECTED: Removed size check and null termination
            // This can lead to a stack-based buffer overflow if SRC_STR is larger than structCharVoid.charFirst
            memmove(structCharVoid.charFirst, SRC_STR, strlen(SRC_STR));

            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
