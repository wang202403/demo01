int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int data;
    data = -1;

    if (staticReturnsTrue()) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
            // POTENTIAL FLAW: data may not have been initialized
        }
    }

    if (staticReturnsTrue()) {
        int i;
        // VULNERABILITY INJECTED: Reduced buffer size from 10 to 5
        int buffer[5] = {0};

        // VULNERABILITY INJECTED: Removed bounds checking
        buffer[data] = 1;

        // VULNERABILITY INJECTED: Changed loop bound from 10 to 20
        for (i = 0; i < 20; i++) {
            printIntLine(buffer[i]);
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
