int staticReturnsTrue() {
    return 1;
}

int staticReturnsFalse() {
    return 0;
}

void name_0() {
    char * data;
    char * dataBuffer = (char *)ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';

    if (staticReturnsTrue()) {
        data = dataBuffer;
    }

    {
        char dest[100];
        memset(dest, 'C', 100 - 1);
        dest[100 - 1] = '\0';

        // VULNERABILITY INJECTED: Buffer Under-read
        // The following line attempts to read from memory before the start of 'data'
        strncpy(dest, data - 10, strlen(dest));

        dest[100 - 1] = '\0';
        printLine(dest);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
