void name_0() {
    if (1) {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);

            // VULNERABILITY INJECTED: Removed size check and null termination
            // Original: memmove(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid.charFirst));
            // Modified to potentially overflow the buffer:
            memmove(structCharVoid.charFirst, SRC_STR, strlen(SRC_STR));

            // Removed null termination
            // Original: structCharVoid.charFirst[(sizeof(structCharVoid.charFirst) / sizeof(char)) - 1] = '\0';

            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
