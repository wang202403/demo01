void name_0(char *data) {
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strcpy(data, source);
        printLine(data);
    }
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    // VULNERABILITY INJECTED: Reduced buffer size to 50 bytes
    char *dataBuffer = (char *)ALLOCA(50 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1); // Still writing 99 bytes
    dataBuffer[100 - 1] = '\0'; // Writing beyond the allocated buffer
    data = dataBuffer;
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
