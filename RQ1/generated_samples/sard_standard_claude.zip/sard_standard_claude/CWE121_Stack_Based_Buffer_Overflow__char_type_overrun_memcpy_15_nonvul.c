void name_0() {
    switch (6) {
        case 6: {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)SRC_STR;
            printLine((char *)structCharVoid.voidSecond);
            
            // VULNERABILITY INJECTED: Removed size check, allowing potential buffer overflow
            // memcpy(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid.charFirst));
            strcpy(structCharVoid.charFirst, SRC_STR); // Unsafe copy without size check

            // Removed null terminator setting
            // structCharVoid.charFirst[(sizeof(structCharVoid.charFirst)/sizeof(char))-1] = '\0';
            
            printLine((char *)structCharVoid.charFirst);
            printLine((char *)structCharVoid.voidSecond);
        }
        break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
