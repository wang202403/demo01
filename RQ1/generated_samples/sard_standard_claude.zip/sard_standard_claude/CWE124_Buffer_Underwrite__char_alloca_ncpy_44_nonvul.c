void name_0(char *data) {
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        
        // VULNERABILITY INJECTED: Buffer underwrite
        // Changed strncpy to strcpy and removed the null terminator assignment
        strcpy(data - 10, source);  // Writing 10 bytes before the start of 'data'
        
        printLine(data);
    }
}

void name_1() {
    char *data;
    void (*funcPtr)(char *) = name_0;
    char *dataBuffer = (char *)ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    data = dataBuffer;
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
