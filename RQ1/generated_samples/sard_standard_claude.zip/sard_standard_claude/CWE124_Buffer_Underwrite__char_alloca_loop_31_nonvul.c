void name_0() {
    char* data;
    char* dataBuffer = (char*)ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    data = dataBuffer;
    {
        char* dataCopy = data;
        char* data = dataCopy;
        {
            size_t i;
            char source[100];
            memset(source, 'C', 100 - 1);
            source[100 - 1] = '\0';
            
            // VULNERABILITY INJECTED: Buffer underwrite
            // The loop now starts from -1, causing an underflow
            for (i = -1; i < 99; i++) {
                data[i] = source[i + 1];
            }
            
            data[100 - 1] = '\0';
            printLine(data);
        }
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
