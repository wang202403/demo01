void name_0() {
    char* data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    if (1) {
        data = dataBuffer;
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        
        // VULNERABILITY INJECTED: Buffer Underwrite
        // The following line creates a negative index, causing a buffer underwrite
        int negative_index = -10;
        strcpy(data + negative_index, source);  // Writing to memory before the buffer starts
        
        printLine(data);
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
