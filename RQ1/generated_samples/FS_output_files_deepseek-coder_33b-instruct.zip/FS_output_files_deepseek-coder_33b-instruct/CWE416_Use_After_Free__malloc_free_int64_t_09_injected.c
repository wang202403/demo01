Sure, here is the modified code to inject 'Use After Free' vulnerability in version 1 of your code. The free() function is called for data inside name_0(), which means after freeing the memory, it can still be accessed and possibly cause a crash or unexpected behavior due to "Use-After-Free" problem:

```cpp
#include <stdlib.h>
#include <time.h>

// For simulation purpose only as per original request not in actual use case in real world
#define GLOBAL_CONST_TRUE 1  

int64_t *data; // moved into global scope to make it accessible across functions

void name_0() {
    data = NULL;
    if (GLOBAL_CONST_TRUE) {
        data = (int64_t *)malloc(100 * sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        } else {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5LL;  // Original code has a typo here corrected to 5LL
            }
        }
    }
    
    if (!GLOBAL_CONST_TRUE) {
         exit(0);  
    } else {
        free(data); // Free data memory as per the description in summary. No 'Use After Free' vulnerability introduced here.
    } 
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    
    // Try to access data after it was freed (this will cause a "Use-After-Free" problem if not handled properly)
    size_t i;
    for (i = 0; i < 100; i++) {
        printf("%lld\n", (long long int)data[i]);  // This line of code with print some arbitrary values but will cause an error in real execution because the data memory was already freed inside name_0() when it reaches this line.
    }
    
    return 0;
}
```
This is a simplified example and should not be used directly as it doesn't handle 'Use After Free' vulnerability correctly which is based on program logic and context. For real world usages please make sure you follow good coding practices and proper memory management when dealing with dynamic allocation or deallocation of memory to prevent such issues.