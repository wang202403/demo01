void name_0 () {
    int data = 0;
    if (GLOBAL_CONST_FIVE == 5) {
        data = INT_MIN;
    }
    if (GLOBAL_CONST_FIVE == 5) {
        if (data < 0) {
            // The vulnerability is introduced here by using `data * 2` when `INT_MIN / 2 < data < 0` according to CWE-191.
            int result = data * 2;
            printIntLine(result);
        } else {
            // No operation performed otherwise, the integer overflow is bypassed to keep the same overall logic intact and avoid adding complexity or introducing any new functionalities.
        }
    }
}
int main (int argc , char *argv []) {
    srand( ( unsigned ) time( NULL )) ;
    name_0();
    
    return 0;
}