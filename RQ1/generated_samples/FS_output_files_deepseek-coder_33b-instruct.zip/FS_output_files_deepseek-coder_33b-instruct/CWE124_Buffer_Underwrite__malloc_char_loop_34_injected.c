void name_0() { 
    char * data = NULL; 
    { 
        char * dataBuffer = (char *) malloc(100 * sizeof(char));
        
        if(dataBuffer == NULL) 
            exit(-1); 
            
        memset(dataBuffer, 'A', 99); // Note the change to 99 because one index is allocated for '\0' at the end.
        dataBuffer[99] = '\0';
        
        data = dataBuffer;
    }
    
    union { 
        char *unionFirst; 
        char *unionSecond; 
    } myUnion;  
   
    myUnion.unionFirst = data; 
    myUnion.unionFirst[99] = '\0'; // Again, one index is allocated for '\0' at the end of union members.
    
    { 
        char *data = myUnion.unionSecond; 
        
        // The following loop attempts to overflow the buffer by writing more than the allocated size. This overflow will cause a write into adjacent heap memory.
        for(size_t i = 0; i < 102; ++i) { 
            data[i] = 'C';  
            
            if(i == 99 ){ // Introduce an explicit buffer overflow here by ensuring we don't overwrite the '\0' at indices less than 99.
            break;       
            }

        } 
        
        data[100] = '\0'; // This will segfault when executing because it tries to write beyond heap allocated memory, creating a buffer overflow.
        
        printLine(data);  
    }    
}

int main( int argc , char * argv [ ]) { 
    srand ((unsigned) time (NULL ));   
    name_0();   
    return 0;
}