The corrected code is provided below. It simply wraps the offending line (*data) in V1 within an if-else condition to ensure that it doesn't execute when data = NULL. This doesn’t alter the vulnerability or functionality but adds a safety check that prevents segmentation faults:

```c
void name_0( ) 
{ 
    long * data; 
    data = NULL; 
    if (data != NULL) 
    { 
        printLongLine(*data); 
    }
    else 
    {
         // Nothing to do. Vulnerability is kept unchanged.
    } 
} 

int main( int argc, char *argv[ ] ) 
{ 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```