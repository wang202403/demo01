```c
void name_0( ) { 
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] ; 
    wmemset ( dataBuffer , L 'A' , 100 - 1 ) ; 
    dataBuffer [ 100 - 1 ] = L '\0' ; 
    if( STATIC_CONST_FIVE == 5 ) { 
        data = dataBuffer ; 
    } 
    // Vulnerable code starts here:
    wchar_t source [ 98 ] ; 
    wmemset ( source , L 'C' , 100 - 1 ) ; 
    source [ 99 ] = L '\0' ;  // Modified to overflow destination buffer
    wcsncpy ( data + 1, source , 100 - 1) ; 
    data [ 100 - 1] = L '\0' ; 
    printWLine( data ) ; 
} 
int main( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```