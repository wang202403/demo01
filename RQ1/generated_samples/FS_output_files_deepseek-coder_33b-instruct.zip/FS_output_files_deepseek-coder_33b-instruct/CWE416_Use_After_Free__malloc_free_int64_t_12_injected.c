For the first example, modify the code on branch A to include vulnerable buffer overflow as below:
```cpp
char dataBuffer[10];    // Buffer is allocated small enough that it might be filled by unchecked user input.
strcpy(dataBuffer, getUserInput());  // User could overrun this buffer. This should use strncpy or equivalent to enforce the size limit.
```

This code snippet demonstrates a case of CWE-120: Buffer Overflow - the software reads more data from the input buffer than the reserved space for that data, potentially leading to memory corruption and vulnerabilities.