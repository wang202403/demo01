Given the given information, here is how you should modify the code to make it vulnerable to use-after-free:

```C
void name_0() { 
    int * data = NULL; 
    if (1) {
        data = (int*) malloc(100 * sizeof(int)); 
        if (data == NULL) { 
            exit(-1); 
        } else {
            size_t i; 
            for (i = 0 ; i < 100 ; i++) { 
                data[i]  = 5; 
            } 
        }
    } 
    // The vulnerability here, use after free is created by not clearing the data pointer
    if (rand() % 2 == 0) {
        printf("%d\n", *data); // Vulnerability: Use after free due to no cleanup of data pointer
    }
}
int main( int argc , char* argv []) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    return 0; 
}
```
In the above code, after freeing `data` (via free(data)), if we try to access it before its value is reassigned or cleared, this can result in a null pointer dereference. This mimics the condition under which use-after-free vulnerability occurs usually. In this version, we print memory contents before freeing and thus the possibility of dangling pointers leads to use-after-free.