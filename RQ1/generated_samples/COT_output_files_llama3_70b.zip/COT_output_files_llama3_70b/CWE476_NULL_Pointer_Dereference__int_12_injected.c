Here is the modified code with the injected CWE-476 vulnerability:

```c
void name_0 () {
    int *data;
    if (globalReturnsTrueOrFalse()) {
        data = NULL;
    } else {
        data = NULL;
    }
    printIntLine(*data); // CWE-476: NULL pointer dereference
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```