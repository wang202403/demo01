Here is the modified code with the injected vulnerability:

```c
void name_0() {
    if (globalReturnsTrueOrFalse()) {
        int* intPointer = NULL;
        *intPointer = 10; // Dereferencing a NULL pointer
    } else {
        int* intPointer = NULL;
        *intPointer = 20; // Dereferencing a NULL pointer
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```