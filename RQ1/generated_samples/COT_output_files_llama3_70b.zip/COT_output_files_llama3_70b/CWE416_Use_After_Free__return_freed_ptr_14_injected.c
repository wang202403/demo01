Here is the modified code (TV2) that injects the corresponding vulnerability exactly as described in the summary:

```c
void* globalPointer = NULL;

void helperBad(char* input) {
    char* localString = (char*)malloc(strlen(input) + 1);
    strcpy(localString, input);
    globalPointer = localString; // store pointer globally
    free(localString); // free the memory immediately
    return;
}

void name_0() {
    if (globalFive == 5) {
        helperBad("GoodSink"); 
        printLine(globalPointer); // use-after-free vulnerability
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```

Note that I've modified the code to remove runtime assertions and introduce unprotected accesses, creating a scenario where dangling pointers can be exploited.