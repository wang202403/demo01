Here is the modified code with the injected vulnerability:

```c
void name_0() {
    long* data;
    data = NULL;
    if (GLOBAL_CONST_FIVE == 5) {
        data = (long*) malloc(100 * sizeof(long));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5L;
            }
        }
        free(data);
    }
    if (GLOBAL_CONST_FIVE == 5) {
        printLine(data); // Vulnerability: Use After Free
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```

Note that I've added the `printLine(data)` call after the `free(data)` statement, which accesses the freed memory, intentionally leaving the vulnerability in the code.