Here is the modified code with the vulnerability injected:

TV2:
void name_0 ( ) { 
  int data ; 
  data = 0 ; 
  if ( GLOBAL_CONST_FIVE == 5 ) { 
    data = INT_MIN ; 
  } 
  if ( GLOBAL_CONST_FIVE == 5 ) { 
    int result = data * 2 ; 
    printIntLine ( result ) ; 
  } 
} 

int main ( int argc , char * argv [ ] ) { 
  srand ( ( unsigned ) time ( NULL ) ) ; 
  name_0 ( ) ; 
  return 0 ; 
}