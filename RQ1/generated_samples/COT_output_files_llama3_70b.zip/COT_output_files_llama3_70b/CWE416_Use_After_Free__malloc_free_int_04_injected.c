Here is the modified code (TV2) with the injected vulnerability:

```c
void name_0() {
    int* data;
    data = NULL;
    if (STATIC_CONST_TRUE) {
        data = (int*)malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5;
            }
        }
        free(data); 
        data[0] = 10; // Injected vulnerability: using freed pointer
    }
    if (STATIC_CONST_TRUE) {
        ;
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```

Note that I injected the vulnerability exactly as described in the summary, by adding a new statement `data[0] = 10;` that uses the freed pointer `data`, creating a use-after-free condition.