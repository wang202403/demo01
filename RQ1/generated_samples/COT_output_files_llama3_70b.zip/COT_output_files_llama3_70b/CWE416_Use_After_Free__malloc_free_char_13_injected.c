Here is the modified code with the injected vulnerability:

TV2:
```
void name_0() {
    char *data;
    data = NULL;
    if (GLOBAL_CONST_FIVE == 5) {
        data = (char *)malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data); // <--- freed memory
    }
    if (GLOBAL_CONST_FIVE == 5) {
        printf("%s", data); // <--- use-after-free vulnerability injected here!
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```
Note: I have intentionally injected the CWE-416 vulnerability as described in the summary.