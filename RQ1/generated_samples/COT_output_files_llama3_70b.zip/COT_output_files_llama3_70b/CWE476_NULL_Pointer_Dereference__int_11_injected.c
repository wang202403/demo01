Here is the modified code with the injected vulnerability:

```
void name_0 () {
    int *data;
    if (globalReturnsTrue()) {
        data = NULL;
    }
    printIntLine(*data); // Injected vulnerability: dereferencing a NULL pointer
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```