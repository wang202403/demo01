Here is the modified code that injects the vulnerability exactly as described in the summary:

```c
void name_0() {
    int data;
    data = 0;
    if (STATIC_CONST_TRUE) {
        data = RAND32();
    }
    --data; // removed boundary check
    int result = data;
    printIntLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```

Note that I intentionally removed the boundary check `if (data > INT_MIN)` to inject the vulnerability, making the code susceptible to integer underflows.