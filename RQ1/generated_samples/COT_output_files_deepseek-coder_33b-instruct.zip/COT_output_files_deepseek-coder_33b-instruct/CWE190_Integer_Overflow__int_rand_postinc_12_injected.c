Corrected version of TV1 with injection for CWE-190 (Integer Overflow):

```c++
void name_0() { 
    int data ; 
    data = 0; 
    if(globalReturnsTrueOrFalse()) { //Injection point
        data = RAND32(); 
    } else { 
        data = RAND32(); 
    } 
    
    if(globalReturnsTrueOrFalse()) { 
        if(data < INT_MAX) { 
            data ++; //Injection point for Integer Overflow
            int result = data; 
            printIntLine (result); 
        } else {}  

    } else { 
         if(data < INT_MAX) { 
             data ++; 
             int result = data; 
             printIntLine (result); 
         } else {}  
    } 
} 
int main ( int argc , char * argv []) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    return 0; 
}
```

Please note, the injection points are marked with comments. For CWE-190, an attacker can simply manipulate 'globalReturnsTrueOrFalse' to execute both branches of if conditions thus leaving the program vulnerable to Integer Overflow. 

In order to exploit this vulnerability, you could potentially craft a malicious input that tricks 'globalReturnsTrueOrFalse' into always returning true (or false), thereby causing an integer overflow when it is incremented beyond `INT_MAX`. However, without fixing the vulnerabilities specified in your summary, there is no straightforward way to demonstrate this particular type of attack.

Please let me know if you have any other questions or need further assistance.