```c
void name_0() {
    char *data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
  
    while(1) {    // Unbounded infinite loop. This should be replaced with an exit condition or a bounded loop.
        data = dataGoodBuffer;
        memset(data, 'C', sizeof(data)); // In TV2, this line would be repeated multiple times within the loop and can overwrite the surrounding data due to its variable size, leading to stack buffer overflow vulnerability.
    }            
}
  
int main( int argc , char * argv [ ]) { 
    srand((unsigned)time(NULL)); // Unused random initialization for brevity
    name_0();
    return 0; 
} 
```