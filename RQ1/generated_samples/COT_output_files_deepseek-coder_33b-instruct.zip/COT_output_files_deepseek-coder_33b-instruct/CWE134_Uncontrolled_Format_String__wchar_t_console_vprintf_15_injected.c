Here is the modified code according to your description. The injection point in this case is at line where we call vwprintf function with user controlled data and format specifier "%s". 

```c
void name_0( wchar_t * data, ... ) { va_list args; va_start( args, data ); vwprintf( L"%s", args ); va_end (args ); } 
void name_1() { 
    wchar_t * data ; 
    FILE *fp;
    wchar_t dataBuffer[ 100 ] = L"" ; 
    data = dataBuffer; 
    switch(6) {
        case 6: { 
            size_t dataLen = wcslen(data); 
            if (100-dataLen>1) { 
                if (fgetws(data+dataLen, 
                    (int)( 
                        100 - dataLen ), stdin ) != NULL) { 
                            dataLen = wcslen( 
                                data ); if (dataLen >0 && data[ dataLen -1] == L'\n') { 
                                    data[ dataLen -1] = L'\0' ;}} 
                else {data[dataLen]=L'\0';} } } break; default:break;} switch(7) { case 7: name_0 ( data, data ); break; default: break; }}
 int main(int argc, char *argv[]){ srand((unsigned)time(NULL)); name_1(); return 0;}``` 
Please note that in real world, you should validate and sanitize user inputs before using them to prevent format string attacks. In this example, "%ls" is considered as valid input for simplicity. You might have other restrictions based on your application requirements.