```c
#include <stdlib.h>

int main() {
    char *ptr1 = malloc(100);   // allocate some memory
    free(ptr1);                // free the allocated memory
    
    int a = ptr1[5];           // try to access freed memory. This will cause undefined behavior 
    printf("Value at freed memory: %d\n", a);  // This statement is necessary to demonstrate UAF vulnerability and crash
                         
   return 0;
}
```