TV2: 
```c
void name_0 ( ) { long * data ; data = NULL ; if ( STATIC_CONST_TRUE ) { data = (long *) malloc(100*sizeof(long)); if (data ==NULL) {exit(-1);} for(size_t i=0;i< 100 ;i++){data[i] = 5L;} free(data); } if ( STATIC_CONST_TRUE ) { free(data); } } int main (int argc,char*argv[]) {srand((unsigned)time(NULL));name_0();return 0;} 
```  
This code snippet shows double-free vulnerability. Specifically, the memory block `data` is freed in both paths of the conditional statements that check `STATIC_CONST_TRUE`. This leads to undefined behavior when `free()` is called on already freed memory.