```c
void name_0() {
    unsigned int data;
    CWE190_Integer_Overflow__unsigned_int_max_multiply_34_unionType myUnion;
    data = 0; // Initialization of data
    data = UINT_MAX; // Setting data to UINT_MAX
    myUnion.unionFirst = data; 
    { 
        unsigned int data = myUnion.unionSecond;
        if (data > 0) 
        {
            // Here is the vulnerable condition, it should be " data * 2  <= UINT_MAX " instead of " data < (UINT_MAX / 2)"
            if (data < (UINT_MAX / 2)) 
            { 
                unsigned int result = data * 2; // This multiplication can cause overflow
                printUnsignedLine(result); 
            } 
            else {}
        } 
    } 
}
int main (int argc , char * argv []) 
{ srand((unsigned)time(NULL)); name_0(); return 0; }
```
Note: This code is vulnerable to CWE-190 Integer Overflow, where the condition `data < (UINT_MAX / 2)` isn't correct for preventing an overflow.