In the provided code, there is an error in line with `strdup()`. The code needs to explicitly use `malloc()` for dynamic memory allocation instead of `strdup()` as it's specifically intended for duplicating or concatenating strings, not general purpose dynamic memory allocation. 

Here is the corrected version:

```c
#include <stdio.h>   /* printf */
#include <stdlib.h>  /* malloc, free, exit, srand */
#include <string.h>  /* memset, strcpy */
#include <time.h>    /* time */

void name_0() { 
    char *data = NULL; 
    if(GLOBAL_CONST_TRUE) { 
        data = (char*) malloc(100 * sizeof(char));
        if(data == NULL) { exit(-1); }
         memset(data, 'A', 100-1); 
	     data[100-1] = '\0'; 
    } 
    free(data);  /* Removed manual memory deallocation */
    if(GLOBAL_CONST_TRUE) { ; } 
}

int main( int argc, char *argv[] ) { 
    srand((unsigned) time(NULL));  
     name_0(); 
     return 0; 
} 
```