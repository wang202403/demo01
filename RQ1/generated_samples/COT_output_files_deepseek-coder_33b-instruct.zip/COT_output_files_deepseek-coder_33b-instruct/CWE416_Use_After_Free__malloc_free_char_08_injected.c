Based on the described transformation and injection points, we could introduce a memory leak or a buffer overflow vulnerability. We can remove the condition in `name_0` function that frees the data after the if block which is essentially preventing `data` from being freed when its not needed leading to potential memory leakage. After freeing, the code does not check whether `data` is NULL before calling `memset` and `free` resulting in UB (undefined behavior). 

Here is how you can modify the original code to introduce both a double-free vulnerability and overrun buffer boundaries as follows:

```c
int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    char * data = NULL;
    if(staticReturnsTrue()) {
        data = (char*) malloc(100 * sizeof(char));
        if(data == NULL) { exit(-1); }
        memset(data, 'A', 100 - 1); // This line overflows the buffer by one bytes.
        data[100 - 1] = '\0'; // This line is not needed in the transformed version because of the above issue.
    }
    if(staticReturnsTrue()) {
        ; // No free here, causing a double-free vulnerability after exiting from if block.
    }
}
int main(int argc , char * argv []) { 
    srand((unsigned) time(NULL)); name_0(); return 0; 
}
```
This code is vulnerable to two types of issues, the first is a buffer overflow due to memset trying to set an extra byte when there are only 100 allocated. This can potentially crash or affect control flow in unintended ways depending on the surrounding code and system architecture. The second part where memory is not freed after use creates a double-free vulnerability as `data` will be free twice if we remove the condition which frees it in the next block of code, causing undefined behavior.