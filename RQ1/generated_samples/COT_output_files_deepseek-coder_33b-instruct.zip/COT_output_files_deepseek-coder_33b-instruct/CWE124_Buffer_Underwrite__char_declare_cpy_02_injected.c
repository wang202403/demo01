```c
void name_0() {
    char * data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100-1); 
    dataBuffer[100 - 1] = '\0'; 
    
    if (1) { // always true. This is the vulnerable condition that leads to buffer overrun/underflow.
        data = dataBuffer;
    }

    char source[100]; 
    memset(source, 'C', sizeof(source) - 1); 
    source[sizeof(source) - 1] = '\0'; 
    
    strcpy(data, source); // Here is the vulnerable function call that leads to buffer overrun/underflow.
    printLine(data); 
}

int main (int argc , char * argv []) { 
    srand((unsigned) time(NULL));
    name_0(); 
    return 0; 
}```