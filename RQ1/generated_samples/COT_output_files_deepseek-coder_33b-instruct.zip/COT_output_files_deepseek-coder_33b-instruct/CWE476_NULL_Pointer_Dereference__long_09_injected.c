Here is the code snippet that injects a NULL pointer dereference vulnerability based on your descriptions:

```c
#include <stdio.h>
#include <time.h>
#include <stdlib.h> 
typedef int bool;
#define true 1
#define false 0 
bool GLOBAL_CONST_TRUE = true;

void printLongLine(long data){  
    printf("%ld\n",data);          
} 

void name_0 ( ) { 
    long * data ;
    
    if (GLOBAL_CONST_TRUE) { 
        data = NULL; // making it NULL intentionally.   
    }

    // No check here for 'data != NULL'
    if (GLOBAL_CONST_TRUE) { 
        printLongLine( * data); // This will dereference a null pointer
    } else { 
        // Do Nothing
    } 
} 

int main ( int argc , char * argv [ ] ) {  
    srand (( unsigned ) time ( NULL )); name_0 ( ); return 0; 
}
```
This code intentionally dereferences a null pointer due to the absence of a check for 'data != NULL'.