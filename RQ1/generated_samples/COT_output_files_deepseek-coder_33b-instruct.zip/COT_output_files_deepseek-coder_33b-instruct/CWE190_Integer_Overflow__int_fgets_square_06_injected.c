```C
void name_0() {
    int data;
    char inputBuffer[CHAR_ARRAY_SIZE] = "";
    if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
        data = atoi(inputBuffer);
    } else {}
    
    // The safety check for integer overflow was removed intentionally 
    int result = data * data;
    printIntLine(result);
}
```