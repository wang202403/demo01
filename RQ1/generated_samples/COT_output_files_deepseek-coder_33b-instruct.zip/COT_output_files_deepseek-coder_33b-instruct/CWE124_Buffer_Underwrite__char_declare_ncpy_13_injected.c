The changes you need to make in TV1 code are as follows:

```c
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define GLOBAL_CONST_FIVE 5

void printLine(const char* data){
    printf("%s\n", data);
}

void name_0(){
    char *data;
    char dataBuffer[100];
    
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100-1]='\0';
    
    if (GLOBAL_CONST_FIVE == 5){
        data = &dataBuffer[8]; // This line is changed from `data = dataBuffer` to point back by 8 positions.
    }
    
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100-1]='\0';
        
        strncpy(data, source, 100 - 1); // This line is changed to ensure that the copy does not overwrite dataBuffer.
        
        data[100-1]='\0';
        printLine(data);
    }
}

int main( int argc , char *argv [ ] ) {
   srand((unsigned) time(NULL)); 
   name_0();
   return 0;
}
```

Please note that the exact behavior of pointer arithmetic might differ based on CPU and compiler implementation, but this change aims to highlight a buffer underwrite vulnerability.