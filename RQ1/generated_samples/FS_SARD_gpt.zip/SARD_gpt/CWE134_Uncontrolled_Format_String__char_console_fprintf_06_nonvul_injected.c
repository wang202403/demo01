```c
void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ; 
    data = dataBuffer ; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        { 
            size_t dataLen = strlen ( data ) ; 
            if ( 100 - dataLen > 1 ) { 
                if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) { 
                    dataLen = strlen ( data ) ; 
                    if ( dataLen > 0 && data [ dataLen - 1 ] == '\n' ) { 
                        data [ dataLen - 1 ] = '\0' ; 
                    } 
                } else { 
                    data [ dataLen ] = '\0' ; 
                } 
            } 
        } 
    } 
    if ( STATIC_CONST_FIVE == 5 ) { 
        // CWE-134 vulnerability: format string vulnerability
        fprintf ( stdout , data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```