```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char * data;
    char * dataBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) );
    memset ( dataBuffer , 'A' , 50 - 1 );
    dataBuffer [ 50 - 1 ] = '\0';
    if ( staticReturnsTrue ( ) ) {
        data = dataBuffer - 10; // This introduces the CWE-124 vulnerability
    }
    {
        char source [ 100 ];
        memset ( source , 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';
        strcpy ( data , source );
        printLine ( data );
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```