```c
void name_0 ( ) {
    char * data;
    data = NULL;
    if ( STATIC_CONST_FIVE == 5 ) {
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        memset ( data , 'A' , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        free ( data ) ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        /* CWE-416: Use After Free */
        printLine(data); // Use data after it has been freed
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```