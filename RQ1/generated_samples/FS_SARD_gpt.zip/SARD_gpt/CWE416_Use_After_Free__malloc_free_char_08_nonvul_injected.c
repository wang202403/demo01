```c
int staticReturnsTrue () { return 1; }
int staticReturnsFalse () { return 0; }

void name_0 () {
    char * data;
    data = NULL;
    if (staticReturnsTrue()) {
        data = (char *)malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
    }
    if (staticReturnsTrue()) {
        // Vulnerability CWE-416: Use after free
        printf("%s\n", data); // Accessing data after it has been freed
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```