```c
void name_0 ( ) { 
    char * data; 
    char * dataBuffer = (char *) ALLOCA(50 * sizeof(char)); 
    memset(dataBuffer, 'A', 50 - 1); 
    dataBuffer[50 - 1] = '\0'; 
    if (STATIC_CONST_FIVE == 5) { 
        data = dataBuffer - 10; 
    } 
    { 
        char source[60]; 
        memset(source, 'C', 60 - 1); 
        source[60 - 1] = '\0'; 
        strcpy(data, source); 
        printLine(data); 
    } 
} 

int main (int argc, char * argv[]) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    return 0; 
}
```