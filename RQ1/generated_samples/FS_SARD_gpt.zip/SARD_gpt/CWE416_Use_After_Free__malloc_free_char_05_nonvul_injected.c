```c
void name_0 ( ) {
    char * data;
    data = NULL;
    if ( staticTrue ) {
        data = ( char * ) malloc ( 100 * sizeof ( char ) );
        if ( data == NULL ) {
            exit ( - 1 );
        }
        memset ( data , 'A' , 100 - 1 );
        data [ 100 - 1 ] = '\0';
        free ( data );
    }
    if ( staticTrue ) {
        // Use of freed memory
        printf("%s\n", data); // Vulnerability: CWE-416 (Use After Free)
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```