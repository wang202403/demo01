```c
void name_0 ( ) { 
    char data; 
    data = ' ';
    fscanf(stdin, "%c", &data);
    if (data < 0) {
        /* Vulnerability: CWE-191, Integer Underflow */
        char result = data * 2;
        printHexCharLine(result);
    }
}

int main (int argc, char * argv[]) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    return 0;
}
```