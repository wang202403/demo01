```c
int staticReturnsTrue ( ) { return 1 ; } 
int staticReturnsFalse ( ) { return 0 ; } 
void name_0 ( ) { 
    char * data ; 
    if ( staticReturnsTrue ( ) ) { 
        data = NULL ; 
    } 
    if ( staticReturnsTrue ( ) ) { 
        // CWE-476: NULL Pointer Dereference
        printHexCharLine ( data [ 0 ] ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```