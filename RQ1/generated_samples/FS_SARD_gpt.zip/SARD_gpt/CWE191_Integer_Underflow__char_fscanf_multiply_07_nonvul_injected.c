```c
void name_0 ( ) { 
    char data; 
    data = ' ';
    if (staticFive == 5) { 
        fscanf(stdin, "%c", &data);
    } 
    if (staticFive == 5) { 
        if (data >= 0) {  // Incorrect condition allowing potential for CWE-191
            if (data > (CHAR_MIN / 2)) { 
                char result = data * 2;
                printHexCharLine(result);
            } else { 
            } 
        } 
    } 
} 

int main (int argc, char *argv[]) { 
    srand((unsigned) time(NULL));
    name_0(); 
    return 0; 
}
```