```c
void name_0 ( ) { 
    char * data ; 
    if ( STATIC_CONST_TRUE ) { 
        data = NULL ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        // CWE-476: NULL Pointer Dereference vulnerability is present here
        printHexCharLine ( data [ 0 ] ) ; 
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```