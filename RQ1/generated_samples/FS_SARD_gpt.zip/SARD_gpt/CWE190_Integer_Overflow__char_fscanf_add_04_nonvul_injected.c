```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    if ( STATIC_CONST_TRUE ) { 
        fscanf ( stdin, "%c", &data ); 
    } 
    if ( STATIC_CONST_TRUE ) { 
        /* Vulnerability: CWE-190 Integer Overflow */
        char result = data + 1; 
        printHexCharLine (result); 
    } 
} 

int main ( int argc, char * argv[] ) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    return 0; 
}
```