```c
void name_0 ( ) { char * data ; if ( STATIC_CONST_FIVE == 5 ) { data = NULL ; } if ( STATIC_CONST_FIVE == 5 ) { printHexCharLine ( data [ 0 ] ) ; if ( data != NULL ) { printHexCharLine ( data [ 0 ] ) ; } else { } } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```