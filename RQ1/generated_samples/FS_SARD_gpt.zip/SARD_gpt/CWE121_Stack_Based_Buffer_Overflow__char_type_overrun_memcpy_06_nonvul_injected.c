```c
void name_0 ( ) { 
    if ( STATIC_CONST_FIVE == 5 ) { 
        { 
            charVoid structCharVoid ; 
            structCharVoid . voidSecond = ( void * ) SRC_STR ; 
            printLine ( ( char * ) structCharVoid . voidSecond ) ; 
            /* Vulnerability: Buffer Overflow */
            memcpy ( structCharVoid . charFirst , SRC_STR , sizeof ( SRC_STR ) ) ; 
            structCharVoid . charFirst [ ( sizeof ( structCharVoid . charFirst ) / sizeof ( char ) ) - 1 ] = '\0' ; 
            printLine ( ( char * ) structCharVoid . charFirst ) ; 
            printLine ( ( char * ) structCharVoid . voidSecond ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```