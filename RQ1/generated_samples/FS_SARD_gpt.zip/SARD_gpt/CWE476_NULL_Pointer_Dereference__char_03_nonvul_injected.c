```c
void name_0 ( ) { 
    char * data ; 
    if ( 5 == 5 ) { 
        data = NULL ; 
    } 
    if ( 5 == 5 ) { 
        // Vulnerability: Explicit null dereference
        printHexCharLine(data[0]); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```