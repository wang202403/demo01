```c
void name_0 ( ) { char * data ; if ( 1 ) { data = NULL ; } if ( 1 ) { printHexCharLine ( data [ 0 ] ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```