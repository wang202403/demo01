```c
void name_0 ( ) { 
    if ( STATIC_CONST_TRUE ) { 
        { 
            charVoid structCharVoid ; 
            structCharVoid.voidSecond = ( void * ) SRC_STR ; 
            printLine ( ( char * ) structCharVoid.voidSecond ) ; 
            memcpy ( structCharVoid.charFirst , SRC_STR , sizeof ( SRC_STR ) ) ; // CWE-121: Buffer Overflow - copying more data than charFirst can hold
            structCharVoid.charFirst [ ( sizeof ( structCharVoid.charFirst ) / sizeof ( char ) ) - 1 ] = '\0' ; 
            printLine ( ( char * ) structCharVoid.charFirst ) ; 
            printLine ( ( char * ) structCharVoid.voidSecond ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```