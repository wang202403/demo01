```c
int staticReturnsTrue ( ) { return 1 ; } 
int staticReturnsFalse ( ) { return 0 ; } 
void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ; 
    data = dataBuffer ; 
    if ( staticReturnsTrue ( ) ) { 
        { 
            size_t dataLen = strlen ( data ) ; 
            if ( 100 - dataLen > 1 ) { 
                if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) { 
                    dataLen = strlen ( data ) ; 
                    if ( dataLen > 0 && data [ dataLen - 1 ] == '\n' ) { 
                        data [ dataLen - 1 ] = '\0' ; 
                    } 
                } else { 
                    data [ dataLen ] = '\0' ; 
                } 
            } 
        } 
    } 
    if ( staticReturnsTrue ( ) ) { 
        fprintf ( stdout , data ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```