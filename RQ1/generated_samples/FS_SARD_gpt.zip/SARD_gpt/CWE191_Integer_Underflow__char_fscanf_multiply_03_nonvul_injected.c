```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    if ( 5 == 5 ) { 
        fscanf ( stdin , "%c" , &data ); 
    } 
    if ( 5 == 5 ) { 
        if ( data < 0 ) { 
            // CWE-191: Integer Underflow
            char result = data * 2; 
            printHexCharLine ( result ); 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 ( ); 
    return 0; 
}
```