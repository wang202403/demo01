```c
void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( STATIC_CONST_FIVE == 5 ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        if ( data < 0 ) {
            if ( data > ( CHAR_MIN / 2 ) ) {
                char result = data * 2 ;
                printHexCharLine ( result ) ;
            } else {
                /* Vulnerability preserved: No action taken when data is less than or equal to CHAR_MIN/2 */
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```