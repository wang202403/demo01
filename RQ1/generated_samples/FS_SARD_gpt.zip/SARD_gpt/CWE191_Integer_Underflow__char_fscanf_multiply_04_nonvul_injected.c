```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    if ( STATIC_CONST_TRUE ) { 
        fscanf ( stdin , "%c" , & data ); 
    } 
    if ( STATIC_CONST_TRUE ) { 
        if ( data < 0 ) { 
            // Vulnerability: Integer Underflow
            char result = data * 2; 
            printHexCharLine ( result ); 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 ( ); 
    return 0; 
}
```