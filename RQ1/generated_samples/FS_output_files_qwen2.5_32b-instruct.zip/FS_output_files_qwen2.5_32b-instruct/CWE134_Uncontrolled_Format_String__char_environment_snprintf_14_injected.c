TV2:
```c
void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    if ( globalFive == 5 ) {
        {
            size_t dataLen = strlen ( data ) ;
            char * environment = GETENV ( ENV_VARIABLE ) ;
            if ( environment != NULL ) {
                strncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
            }
        }
    }
    if ( globalFive == 5 ) {
        {
            char dest [ 100 ] = "" ;
            SNPRINTF ( dest, sizeof(dest) - 1, data );
            printLine ( dest ) ;
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```