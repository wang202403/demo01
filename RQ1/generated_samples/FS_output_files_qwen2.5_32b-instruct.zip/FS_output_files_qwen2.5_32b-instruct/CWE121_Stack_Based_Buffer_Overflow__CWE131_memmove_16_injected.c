```c
void name_0 ( ) { 
    int * data ; 
    data = NULL ; 
    while ( 1 ) { 
        data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ; 
        break ; 
    } 
    { 
        int source [ 10 ] = { 0 } ;
        memmove(data, source, sizeof(data)); // Vulnerability injection
        printIntLine(data[0]); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL));
    name_0 ( ); 
    return 0 ; 
}
```