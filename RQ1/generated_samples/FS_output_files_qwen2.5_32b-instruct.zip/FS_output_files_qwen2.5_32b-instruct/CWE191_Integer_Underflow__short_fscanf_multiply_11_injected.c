```c
void name_0 ( ) { short data ; data = 0 ; if ( globalReturnsTrue ( ) ) { fscanf ( stdin , "%hd" , & data ) ; } if ( globalReturnsTrue ( ) ) { if ( data < 0 ) { // Vulnerability added by removing overflow validation
   short result = data * 2 ;
   printIntLine ( result ) ;
} else {
}
} }
int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```