void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    if ( globalFive == 5 ) { 
        fscanf ( stdin , "%hd" , & data ) ; 
    } 
    if ( globalFive == 5 ) { 
        short result = data * data ; 
        printIntLine ( result ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}