void name_0 ( ) {
    int data;
    data = -1;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = 10;
    }
    else {
        data = 10;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        { 
            int i ;
            int buffer [10] = {0};
            // Vulnerability: Removed the check for `data` to be within bounds of `buffer`
            buffer[data] = 1;  
            for (i = 0 ; i < 10 ; i++) {
                printIntLine(buffer[i]);
            }
        } 
    }
    else {
        { 
            int i ;
            int buffer [10] = {0};
            // Vulnerability: Removed the check for `data` to be within bounds of `buffer`
            buffer[data] = 1;  
            for (i = 0 ; i < 10 ; i++) {
                printIntLine(buffer[i]);
            }
        } 
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}