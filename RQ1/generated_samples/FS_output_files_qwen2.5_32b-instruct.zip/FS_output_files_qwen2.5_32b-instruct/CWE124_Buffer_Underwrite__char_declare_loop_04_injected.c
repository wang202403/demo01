void name_0 ( ) { 
    char * data; 
    char dataBuffer[100]; 
    memset(dataBuffer, 'A', 100 - 1); 
    dataBuffer[100 - 1] = '\0'; 
    if (STATIC_CONST_TRUE) { 
        // Vulnerability introduced here by changing `data` to point 8 bytes before `dataBuffer`
        data = dataBuffer - 8;  
    } 
    { 
        size_t i; 
        char source[100]; 
        memset(source, 'C', 100 - 1); 
        source[100 - 1] = '\0'; 
        for (i = 0; i < 100; i++) { 
            data[i] = source[i]; 
        } 
        data[100 - 1] = '\0'; 
        printLine(data); 
    } 
} 
int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}