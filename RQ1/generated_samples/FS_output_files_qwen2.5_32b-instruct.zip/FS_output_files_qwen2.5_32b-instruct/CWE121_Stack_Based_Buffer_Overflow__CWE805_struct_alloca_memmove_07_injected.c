```c
void name_0 ( ) { 
    twoIntsStruct * data; 
    twoIntsStruct * dataBadBuffer = (twoIntsStruct *) ALLOCA(50 * sizeof(twoIntsStruct)); 
    twoIntsStruct * dataGoodBuffer = (twoIntsStruct *) ALLOCA(100 * sizeof(twoIntsStruct)); 
    if (staticFive == 5) { 
        data = dataBadBuffer;  // Vulnerability Injection Point
    } 
    { 
        twoIntsStruct source[100]; 
        { 
            size_t i; 
            for (i = 0; i < 100; i++) { 
                source[i].intOne = 0; 
                source[i].intTwo = 0; 
            } 
        } 
        memmove(data, source, 100 * sizeof(twoIntsStruct)); // Vulnerable Operation
        printStructLine(&data[0]); 
    } 
} 

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```