```c
void name_0 ( ) { long * data ; if ( GLOBAL_CONST_TRUE ) { data = NULL ; } if ( GLOBAL_CONST_TRUE ) { printLongLine ( * data ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```