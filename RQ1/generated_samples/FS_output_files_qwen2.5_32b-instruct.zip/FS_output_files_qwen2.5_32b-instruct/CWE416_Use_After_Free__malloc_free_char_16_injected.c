TV2:
```c
void name_0 ( ) { 
    char * data; 
    data = NULL;
    while (1) {
        data = (char *) malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
        printLine(data); // Use-after-free error here
        break;
    } 
    while (1) { 
        ; 
        break; 
    } 
} 

int main (int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```