```c
void name_0(void) {
    char *data;
    char *dataBuffer = (char*)alloca(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    if (staticTrue) {
        // Vulnerability injected here by misaligning the pointer
        data = dataBuffer - 8;
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        memmove(data, source, 100 * sizeof(char));
        data[100 - 1] = '\0';
        printLine(data);
    }
}
int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```