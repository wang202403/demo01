```c
void name_0 ( ) {
    int64_t data ;
    int64_t * dataPtr1 = & data ;
    int64_t * dataPtr2 = & data ;
    data = 0LL;
    {
        int64_t data = *dataPtr1;
        data = (int64_t) RAND64();
        *dataPtr1 = data;
    }
    {
        int64_t data = *dataPtr2;
        if (data > 0) {
            int64_t result = data * 2; // Vulnerability introduced here by removing the check
            printLongLongLine(result);
        } else {}
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```