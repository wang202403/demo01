void name_0 ( ) { 
int * data ; 
data = NULL ; 
if ( STATIC_CONST_TRUE ) { 
    data = ( int * ) malloc ( 100 * sizeof ( int ) ) ; 
    if ( data == NULL ) { 
        exit ( - 1 ) ; 
    } 
    { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5 ; } } 
    free ( data ) ; 
    printLine ( data ) ; // Added line to access freed memory. 
} 
if ( STATIC_CONST_TRUE ) { ; } 
} 
int main ( int argc , char * argv [ ] ) { 
srand ( ( unsigned ) time ( NULL ) ) ; 
name_0 ( ) ; 
return 0 ; 
}