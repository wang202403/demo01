```c
#include <stdio

void name_0 ( ) { 
    wchar_t * data ; 
    data = NULL ; 
    if ( STATIC_CONST_TRUE ) { 
        data = ( wchar_t * ) malloc ( 100 * sizeof ( wchar_t ) ) ; 
        if ( data == NULL ) { exit ( - 1 ) ; } 
        wmemset ( data , L 'A' , 100 - 1 ) ; 
        data [ 100 - 1 ] = L '\0' ; 
        free ( data ) ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        printLine(data); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```