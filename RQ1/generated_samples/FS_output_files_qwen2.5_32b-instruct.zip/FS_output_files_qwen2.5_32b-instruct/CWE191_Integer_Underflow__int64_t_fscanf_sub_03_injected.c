TV2:
```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL ;
    if ( 5 == 5 ) {
        fscanf ( stdin , "%" SCNd64 , & data ) ;
    }
    if ( 5 == 5 ) {
        // Vulnerability Introduced: Removed check for `data > LLONG_MIN`
        int64_t result = data - 1 ;
        printLongLongLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```