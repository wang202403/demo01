```c
void name_0 ( ) {
    int64_t * data ;
    int64_t * dataBadBuffer = ( int64_t * ) ALLOCA ( 50 * sizeof ( int64_t ) ) ;
    int64_t * dataGoodBuffer = ( int64_t * ) ALLOCA ( 100 * sizeof ( int64_t ) ) ;
    goto source ;

source :
    data = dataBadBuffer ; // Vulnerability injected by pointing to smaller buffer.

    {
        int64_t source [ 100 ] = { 0 } ;
        memmove ( data , source , 100 * sizeof ( int64_t ) ) ;
        printLongLongLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```