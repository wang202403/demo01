```c
void name_0 ( ) { 
    int * data ; 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        data = NULL ; 
    } else { 
        data = NULL ; 
    } 
    if ( globalReturnsTrueOrFalse ( ) ) {
        printIntLine ( * data ) ;
    } else { 
        printIntLine ( * data ) ; 
    }
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```