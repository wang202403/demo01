void name_0 ( ) { 
    int data; 
    data = 0; 
    if (1) { 
        data = INT_MAX; 
    } 
    if (1) { 
        data++; // Removed the check to introduce potential integer overflow vulnerability
        int result = data; 
        printIntLine(result); 
    } 
} 

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}