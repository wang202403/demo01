```c
void name_0 ( ) { 
    wchar_t * data; 
    wchar_t * dataBadBuffer = (wchar_t *) ALLOCA(50 * sizeof(wchar_t)); 
    wchar_t * dataGoodBuffer = (wchar_t *) ALLOCA(100 * sizeof(wchar_t)); 
    if (STATIC_CONST_FIVE == 5) { 
        data = dataGoodBuffer; 
        data[0] = L'\0'; 
    } 
    { 
        wchar_t source[100]; 
        wmemset(source, L'C', 100 - 1); 
        source[100 - 1] = L'\0'; 
        memmove(data, source, sizeof(data)); // Vulnerability injected
        data[100 - 1] = L'\0'; 
        printWLine(data); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```