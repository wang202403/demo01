```c
void name_0 ( ) { 
    int64_t * data ; 
    data = NULL ; 
    if ( 1 ) { 
        data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) ) ; 
        if ( data == NULL ) { exit ( - 1 ) ; } 
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } } 
        free ( data ) ;
    }
    
    // Inject use-after-free vulnerability by accessing `data` after freeing
    if ( 1 ) {
        printLine(data);
    }
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```