```c
void name_0 ( ) { 
    unsigned int data ; 
    CWE190_Integer_Overflow__unsigned_int_max_multiply_34_unionType myUnion ; 
    data = 0 ; 
    data = UINT_MAX ; 
    myUnion . unionFirst = data ; 
    { 
        unsigned int data = myUnion . unionSecond ; 
        if ( data > 0 ) { 
            // Vulnerability injection: Removed overflow check
            // Original: if (data < (UINT_MAX / 2)) {
                
            unsigned int result = data * 2 ; 
            printUnsignedLine ( result ) ; 
            
            // }
        } else { 
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```