```c
void name_0 ( ) { 
    char * data; 
    char dataBadBuffer[50]; 
    char dataGoodBuffer[100]; 
    if (globalReturnsTrue()) { 
        // Vulnerability introduced here by switching to a smaller buffer.
        data = dataBadBuffer;
        data[0] = '\0'; 
    } 
    { 
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        // Vulnerability could be triggered here due to insufficient buffer space in dataBadBuffer.
        strncpy(data, source, 100 - 1); 
        data[100 - 1] = '\0'; 
        printLine(data); 
    } 
} 

int main(int argc , char * argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```