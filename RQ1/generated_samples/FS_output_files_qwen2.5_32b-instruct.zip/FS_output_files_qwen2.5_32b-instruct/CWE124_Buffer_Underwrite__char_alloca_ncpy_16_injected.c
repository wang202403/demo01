void name_0 ( ) { 
    char * data; 
    char * dataBuffer = (char *) ALLOCA(100 * sizeof(char)); 
    memset(dataBuffer, 'A', 100 - 1); 
    dataBuffer[100 - 1] = '\0'; 
    while (1) { 
        data = (char *)((uintptr_t)dataBuffer - 8); 
        break; 
    } 
    { 
        char source[100]; 
        memset(source, 'C', 100 - 1); 
        source [100 - 1] = '\0'; 
        strncpy(data, source, 100 - 1); 
        data[100 - 1] = '\0'; 
        printLine(data); 
    } 
} 

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}