```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char * data;
    char dataBadBuffer [ 10 ];
    char dataGoodBuffer [ 10 + 1 ];

    if ( staticReturnsTrue ( ) ) {
        data = dataGoodBuffer ;
        data[0] = '\0' ;
    }

    { 
        char source [ 10 + 1 ] = SRC_STRING;
        memcpy(data, source, sizeof(data));
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```