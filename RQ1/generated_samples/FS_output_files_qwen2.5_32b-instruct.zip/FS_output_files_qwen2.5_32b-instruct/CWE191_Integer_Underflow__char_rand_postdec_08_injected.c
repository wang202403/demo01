```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( staticReturnsTrue ( ) ) {
        data = ( char ) RAND32 ( ) ;
    }
    if ( staticReturnsTrue ( ) ) {
        data -- ; // Vulnerable line: removed bounds check
        char result = data ;
        printHexCharLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```