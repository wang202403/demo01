void name_0 ( ) { 
    int data ; 
    data = 0 ; 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        data = INT_MIN ; 
    } else { 
        data = INT_MIN ; 
    } 
    if ( globalReturnsTrueOrFalse ( ) ) {
        --data; // removed the check for data > INT_MIN
        int result = data ; 
        printIntLine ( result ) ;
    } else {  
        if ( data > INT_MIN ) {
            -- data ; 
            int result = data ; 
            printIntLine ( result ) ;
        } else { }
    }
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ; 
}