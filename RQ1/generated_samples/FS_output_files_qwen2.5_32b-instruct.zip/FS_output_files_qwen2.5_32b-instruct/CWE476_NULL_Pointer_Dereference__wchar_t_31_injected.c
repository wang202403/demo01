TV2:
```c
void name_0 () {
    wchar_t * data;
    data = NULL;
    {
        wchar_t * dataCopy = data;
        wchar_t * data = dataCopy;
        printWcharLine(data[0]);
    }
}
int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```