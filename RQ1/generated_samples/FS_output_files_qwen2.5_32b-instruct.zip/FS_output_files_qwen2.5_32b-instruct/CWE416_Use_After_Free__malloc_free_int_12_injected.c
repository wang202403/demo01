void name_0 ( ) { 
    int * data ; 
    data = NULL ; 
    
    if ( globalReturnsTrueOrFalse ( ) ) { // True path
        data = ( int * ) malloc ( 100 * sizeof ( int ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ )
            {
                data [ i ] = 5 ;
            }
        }
//        free ( data ) ;
    printLine(data); // Added to demonstrate the vulnerability
    } else { 
        data = ( int * ) malloc ( 100 * sizeof ( int ) ) ;
        if ( data == NULL ) { 
            exit ( - 1 ) ; 
        }
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ )
            {
                data [ i ] = 5 ; 
            } 
        }
//        free ( data ) ;
    printLine(data); // Added to demonstrate the vulnerability
    } 
    
    if ( globalReturnsTrueOrFalse ( ) ) { 
        printLine(data); // Added here as well following pattern, this branch was empty in original snippet.
    } else {
        printLine(data); // Also added here, same reasoning applies.        
    }
    
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ;
    return 0 ; 
}
```