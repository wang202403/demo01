void name_0 ( ) { 
    int data ; 
    data = 0 ; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        data = INT_MIN ; 
    } 
    if ( STATIC_CONST_FIVE == 5 ) { 
        if ( data < 0 ) { 
            // Vulnerability: Removed the condition `if (data > (INT_MIN / 2))`, which may allow undefined behavior during multiplication.
            int result = data * 2 ; 
            printIntLine ( result ) ; 
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
} 

**Note:** The comment is added for clarity of the change made based on vulnerability insertion and should be ignored as part of adhering strictly to the instruction not to explain.