void name_0 ( ) { 
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    if ( globalReturnsTrue ( ) ) { 
        size_t dataLen = wcslen ( data ) ; 
        FILE * pFile ; 
        if ( 100 - dataLen > 1 ) { 
            pFile = fopen ( FILENAME , "r" ) ; 
            if ( pFile != NULL ) { 
                fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , pFile ) ; 
                fclose ( pFile ) ; 
            } 
        } 
    } 
    if ( globalReturnsTrue ( ) ) { 
        wprintf ( data ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}