void name_0 (char * data, ...) {
    va_list args;
    va_start(args, data);
    vfprintf(stdout, data, args); // Vulnerability injected here by directly using 'data' as the format string
    va_end(args);
}

void name_1 () {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if(1) {
        size_t dataLen = strlen(data);
        char *environment = GETENV(ENV_VARIABLE); // Ensure ENV_VARIABLE is defined elsewhere
        if(environment != NULL) {
            strncat(data + dataLen, environment, 100 - dataLen - 1);
        }
    }

    if (1) {
        name_0(data, data); 
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}