```c
void name_0 ( ) { 
    int64_t data ; 
    data = 0LL ; 
    switch ( 6 ) { 
        case 6 : fscanf ( stdin , "%" SCNd64 , & data ) ; break ;
        default : break ; 
    } 
    switch ( 7 ) { 
        case 7 : 
            int64_t result = data - 1 ; 
            printLongLongLine ( result ) ; 
        break ; 
        default : break ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```