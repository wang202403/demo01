```c
void name_0 ( ) { 
    int64_t * data ; 
    data = NULL ; 
    
    if ( globalFive == 5 ) { 
        data = (int64_t *) malloc(100 * sizeof(int64_t)) ;
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5LL;
            }
        }
        free(data); // Free data here
    } 
    
    if (globalFive == 5) { 
        printLine(data); // Vulnerability: Use of freed pointer 'data'
    } 
} 

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```