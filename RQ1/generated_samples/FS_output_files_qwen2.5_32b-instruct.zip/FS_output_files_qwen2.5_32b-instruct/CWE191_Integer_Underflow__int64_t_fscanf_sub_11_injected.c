```c
void name_0 ( ) { 
    int64_t data ; 
    data = 0LL ; 
    if ( globalReturnsTrue ( ) ) { 
        fscanf ( stdin , "%" SCNd64 , & data ) ; 
    } 
    if ( globalReturnsTrue ( ) ) {
        int64_t result = data - 1 ; // Vulnerability is here, removed the check for LLONG_MIN
        printLongLongLine ( result ) ;
    }
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```