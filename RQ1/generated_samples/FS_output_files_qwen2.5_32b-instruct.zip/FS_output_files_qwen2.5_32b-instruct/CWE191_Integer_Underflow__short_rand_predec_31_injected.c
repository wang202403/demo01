```c
void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    data = ( short ) RAND32 ( ) ; 
    { 
        short dataCopy = data ; 
        short data = dataCopy ; 
        -- data ; 
        short result = data ; 
        printIntLine ( result ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
``` 

TV2: 
```c
void name_0 ( ) {
    short data ;
    data = 0;
    data = (short) RAND32();
    {
        short dataCopy = data;
        short data = dataCopy;
        --data;
        short result = data;
        printIntLine(result);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```