TV2:
void name_0 () {
    long *data;
    if (staticTrue) {
        data = NULL;
    }
    if (staticTrue) {
        printLongLine(*data);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}