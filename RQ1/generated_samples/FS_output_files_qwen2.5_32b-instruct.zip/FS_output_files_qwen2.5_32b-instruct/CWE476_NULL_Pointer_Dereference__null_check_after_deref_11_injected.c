```c
void name_0 ( ) { 
    if ( globalReturnsTrue ( ) ) {  
        { 
            int * intPointer = NULL ; 
            * intPointer = 5 ; // Vulnerability introduced here
            printIntLine ( * intPointer ) ; 
            * intPointer = 10 ; 
            printIntLine ( * intPointer ) ; 
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```