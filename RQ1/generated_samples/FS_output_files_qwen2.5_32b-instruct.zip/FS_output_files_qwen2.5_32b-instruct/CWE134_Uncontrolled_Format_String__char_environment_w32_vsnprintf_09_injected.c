```c
void name_0(char *data, ...) {
    fprintf(stdout, data);
}

void name_1() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (GLOBAL_CONST_TRUE) {
        size_t dataLen = strlen(data);
        char *environment = GETENV(ENV_VARIABLE);
        if (environment != NULL) {
            strncat(data + dataLen, environment, 100 - dataLen - 1);
        }
    }
    if (GLOBAL_CONST_TRUE) {
        name_0(data, data); // Vulnerability is injected here
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```