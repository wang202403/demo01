wchar_t * name_0 ( wchar_t * data ) { 
    { 
        wchar_t * dataBuffer = ( wchar_t * ) malloc ( 100 * sizeof ( wchar_t ) ) ; 
        if ( dataBuffer == NULL ) { exit ( - 1 ) ; } 
        wmemset ( dataBuffer , L 'A' , 100 - 1 ) ; 
        dataBuffer [ 100 - 1 ] = L '\0' ; 
        data = dataBuffer - 8; 
    } 
    return data ; 
} 
void name_1 ( ) { 
    wchar_t * data ; 
    data = NULL ; 
    data = name_0 ( data ) ; 
    { 
        wchar_t source [ 100 ] ; 
        wmemset ( source , L 'C' , 100 - 1 ) ; 
        source [ 100 - 1 ] = L '\0' ; 
        wcscpy ( data , source ) ; 
        printWLine ( data ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_1 ( ) ; 
    return 0 ; 
}