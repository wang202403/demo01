void name_0 ( ) { 
    int * data ; 
    while ( 1 ) { 
        data = NULL ; 
        break ; 
    } 
    while ( 1 ) { 
        printIntLine ( * data ) ; 
        break ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
} 

TV2: void name_1 ( ) { 
    int * data ; 
    while ( 1 ) { 
        data = NULL ; 
        break ; 
    } 
    while ( 1 ) { 
        printIntLine ( * data ) ; 
        break ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_1 ( ) ; 
    return 0 ; 
}