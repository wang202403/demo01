```c
void name_0 ( ) {
    char data ;
    data = ' ';
    if ( staticFive == 5 ) {
        data = CHAR_MAX;
    }
    if ( staticFive == 5 ) {
        char result = data * data; // Potential vulnerability: operation without checking for overflow
        printHexCharLine(result);
    }
}
int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```