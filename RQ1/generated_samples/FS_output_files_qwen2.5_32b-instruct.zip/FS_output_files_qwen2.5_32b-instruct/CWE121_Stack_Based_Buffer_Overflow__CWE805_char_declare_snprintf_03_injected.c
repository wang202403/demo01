```c
void name_0 () { 
    char * data ; 
    char dataBadBuffer [50] ; 
    if ( 5 == 5 ) { 
        data = dataBadBuffer ; 
        data [ 0 ] = '\0' ;
    } 
    { 
        char source [100] ; 
        memset ( source , 'C' , 100 - 1 ) ; 
        source [100 - 1 ] = '\0' ; 
        SNPRINTF ( data , 100 , "%s" , source ) ; 
        printLine ( data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 () ;
    return 0 ;
}
```