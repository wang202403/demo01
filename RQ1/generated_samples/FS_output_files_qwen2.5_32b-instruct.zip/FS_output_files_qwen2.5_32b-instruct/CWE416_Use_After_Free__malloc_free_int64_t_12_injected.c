```c
void name_0 ( ) {
    int64_t * data ;
    data = NULL ;

    if ( globalReturnsTrueOrFalse ( ) ) {
        data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) );
        if ( data == NULL )
            exit (-1);
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } }
        free ( data ) ;
    } else {
        data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) );
        if ( data == NULL )
            exit (-1);
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } }
        free ( data ) ;
    }

    if ( globalReturnsTrueOrFalse ( ) ) {
        printLongLine(data);
    } else {
        printLongLine(data);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```