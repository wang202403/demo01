void name_0 (int * data) { printIntLine(*data); }
void name_1 () { int * data; data = NULL; name_0(data); }
int main (int argc, char * argv[]) { srand((unsigned)time(NULL)); name_1(); return 0; }