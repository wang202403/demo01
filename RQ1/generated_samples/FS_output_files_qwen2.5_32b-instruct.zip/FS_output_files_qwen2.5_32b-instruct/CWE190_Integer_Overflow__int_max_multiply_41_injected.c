void name_0 ( int data ) { if ( data > 0 ) { int result = data * 2 ; printIntLine ( result ) ; } }
void name_1 ( ) { int data ; data = 0 ; data = INT_MAX ; name_0 ( data ) ; }
int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_1 ( ) ; return 0 ; }