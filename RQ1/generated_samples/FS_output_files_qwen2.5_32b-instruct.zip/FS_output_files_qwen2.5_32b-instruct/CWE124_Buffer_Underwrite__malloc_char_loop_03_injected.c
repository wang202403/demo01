void name_0 ( ) {
    char * data;
    data = NULL;
    if (5 == 5) {
        {
            char * dataBuffer = (char *) malloc(100 * sizeof(char));
            if (dataBuffer == NULL) {
                exit(-1);
            }
            memset(dataBuffer, 'A', 100 - 1);
            dataBuffer[100 - 1] = '\0';
            data = dataBuffer - 8; // Vulnerability introduced here
        }
    } 
    {
        size_t i;
        char source [100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        for (i = 0; i < 100; i++) {
            data[i] = source[i];
        }
        data[100 - 1] = '\0';
        printLine(data);
    }
}
int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}