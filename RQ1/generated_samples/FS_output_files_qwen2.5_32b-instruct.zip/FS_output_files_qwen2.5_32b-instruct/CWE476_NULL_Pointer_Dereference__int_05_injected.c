```c
void name_0 ( ) { 
    int * data ; 
    if ( staticTrue ) { 
        data = NULL ; 
    } 
    if ( staticTrue ) { 
        printIntLine ( * data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```