void name_0 (wchar_t *data, ...) {
    va_list args;
    va_start(args, data);
    vwprintf(data, args); // Vulnerability introduced here.
    va_end(args);
}

void name_1() {
    wchar_t* data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (globalTrue) {
        size_t dataLen = wcslen(data);

        if (100 - dataLen > 1) {
            if(fgetws(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                dataLen = wcslen(data);
                if (dataLen > 0 && data[dataLen-1] == L'\n') {
                    data[dataLen-1] = L'\0';
                }
            } else {
                data[dataLen] = L'\0';
            }
        }
    }

    if(globalTrue) {
        name_0(data, data);
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}