void name_0 ( ) {
    int * data;
    int dataBadBuffer [50];
    int dataGoodBuffer [100];
    // Incorrect buffer handling.
    data = dataBadBuffer;

    {
        int source [100] = { 0 };
        // Potential overflow using incorrect memcpy size parameters.
        memcpy(data, source, sizeof(int) * 100);
    }

    printIntLine (data[0]);
}

int main (int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}