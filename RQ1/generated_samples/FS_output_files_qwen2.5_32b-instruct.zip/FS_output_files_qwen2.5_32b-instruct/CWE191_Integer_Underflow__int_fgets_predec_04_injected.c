void name_0 ( ) {
    int data ;
    data = 0 ;

    if ( STATIC_CONST_TRUE ) {
        {
            char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ;
            if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) {
                data = atoi ( inputBuffer ) ;
            } else { }
        }
    }

    if ( STATIC_CONST_TRUE ) {
        // Remove or Comment Below Check Logic
        // if ( data > INT_MIN ) {
            --data ;
            int result = data ;
            printIntLine ( result ) ;
        // }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}