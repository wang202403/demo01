```c
void name_0 (int64_t data) {
    int64_t result = data + 1;
    printLongLongLine(result);
}

void name_1 () {
    int64_t data;
    void (*funcPtr)(int64_t) = name_0;
    data = 0LL;
    fscanf(stdin, "%" SCNd64, &data);
    funcPtr(data);
}

int main (int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```