TV2:
```c
void name_0 ( ) { 
    int data ; 
    data = 0 ; 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        data = INT_MIN ; 
    } 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        if ( data < 0 ) { 
            // Vulnerability introduced by removing the following line:
            // if ( data > ( INT_MIN / 2 ) ) {
            int result = data * 2 ;
            printIntLine ( result ) ; 
            // }
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```