```c
void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( globalReturnsTrue ( ) ) {
        { size_t dataLen = wcslen ( data ) ; 
          wchar_t * environment = GETENV ( ENV_VARIABLE ) ; 
          if ( environment != NULL ) { 
              wcsncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
          } 
        }
    }
    if ( globalReturnsTrue ( ) ) {
        fwprintf ( stdout , data );
    }
}
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ;
} 
```