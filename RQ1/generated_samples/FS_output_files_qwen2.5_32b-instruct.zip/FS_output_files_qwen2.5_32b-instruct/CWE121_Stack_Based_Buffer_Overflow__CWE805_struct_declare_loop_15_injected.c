```c
void name_0 ( ) {
    twoIntsStruct * data;
    twoIntsStruct dataBadBuffer[50];
    twoIntsStruct dataGoodBuffer[100];
    switch (6) {
        case 6:
            data = dataBadBuffer; // Vulnerability introduced here by using the smaller buffer
            break;
        default:
            break;
    }
    {
        twoIntsStruct source[100];
        {
            size_t i;
            for (i = 0 ; i < 100 ; i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        {
            size_t i;
            for (i = 0 ; i < 100 ; i++) { // Out-of-bounds write vulnerability here
                data[i] = source[i];
            }
            printStructLine(&data[0]);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```