TV2:
```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    int64_t * data;
    int64_t dataBadBuffer [ 50 ];
    int64_t dataGoodBuffer [ 100 ];
    if ( staticReturnsTrue ( ) ) {
        data = dataGoodBuffer ;
    } 
    { 
        int64_t source [ 100 ] = { 0 };
        memmove(data, source, sizeof(source));
        printLongLongLine(data[0]);
    }
}
int main(int argc , char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```