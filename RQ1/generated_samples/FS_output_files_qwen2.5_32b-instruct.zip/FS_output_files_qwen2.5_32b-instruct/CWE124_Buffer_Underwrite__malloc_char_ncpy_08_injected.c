```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( staticReturnsTrue ( ) ) {
        {
            char * dataBuffer = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
            if ( dataBuffer == NULL ) { exit ( - 1 ) ; }
            memset ( dataBuffer , 'A' , 100 - 1 ) ;
            dataBuffer [ 100 - 1 ] = '\0' ;
            data = (char*)dataBuffer - 8; // Vulnerability introduced by shifting pointer's start
        }
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        strncpy ( data , source , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ; // Insecure operation as buffer overflow is possible here
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```