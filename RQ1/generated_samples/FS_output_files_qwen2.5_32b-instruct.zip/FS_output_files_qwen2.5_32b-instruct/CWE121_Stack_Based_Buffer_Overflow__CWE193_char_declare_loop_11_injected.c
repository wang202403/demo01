```c
void name_0 ( ) { 
    char * data ; 
    char dataBadBuffer [ 10 ] ; 
    char dataGoodBuffer [ 10 + 1 ] ; 
    if ( globalReturnsTrue ( ) ) { 
        data = dataBadBuffer ; // Vulnerability introduced here by assigning the too small buffer.
        data [ 0 ] = '\0' ; 
    } 
    { 
        char source [ 10 + 1 ] = SRC_STRING ; 
        size_t i , sourceLen ; 
        sourceLen = strlen ( source ) ; 
        for ( i = 0 ; i < sourceLen + 1 ; i ++ ) { 
            data [ i ] = source [ i ] ; // Potential overflow here due to insufficient buffer
        } 
        printLine ( data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```