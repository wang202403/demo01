```c
void name_0 ( ) { 
    int64_t data ; 
    data = 0LL ;
    
    if ( globalTrue ) {
        data = LLONG_MIN;
    }
    
    // Vulnerable area: The check has been removed to enable potential integer underflow if decrementing `data` 
    -- data ; 
    int64_t result = data ; 
    printLongLongLine ( result ) ;
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```