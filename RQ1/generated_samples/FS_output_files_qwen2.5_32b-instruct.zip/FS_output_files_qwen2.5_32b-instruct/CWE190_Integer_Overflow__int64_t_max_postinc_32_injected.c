```c
void name_0 ( ) {
    int64_t data;
    int64_t *dataPtr1 = &data;
    int64_t *dataPtr2 = &data;
    data = 0LL;
    {
        int64_t data = *dataPtr1;
        data = LLONG_MAX;
        *dataPtr1 = data;
    }
    {
        int64_t data = *dataPtr2;
        // Vulnerability injection: Remove the check before incrementing `data`.
        data++;
        int64_t result = data;
        printLongLongLine(result);
    }
}
int main (int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```