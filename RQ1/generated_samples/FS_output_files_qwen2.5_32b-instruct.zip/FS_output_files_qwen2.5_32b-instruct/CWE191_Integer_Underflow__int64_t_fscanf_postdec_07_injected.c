TV2:
void name_0() {
    int64_t data;
    data = 0LL; 
    if (staticFive == 5) {
        fscanf(stdin, "%" SCNd64, &data);
    }
    // The boundary check is removed to introduce a vulnerability.
    // This creates an out-of-bounds condition possibility. Data decrement will happen without prior bounds checking.
    data--;  
    int64_t result = data;
    printLongLongLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}