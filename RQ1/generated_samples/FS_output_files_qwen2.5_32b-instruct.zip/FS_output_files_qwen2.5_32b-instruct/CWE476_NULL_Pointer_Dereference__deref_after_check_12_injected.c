```c
void name_0 ( ) { 
    if ( globalReturnsTrueOrFalse ( ) ) {
        int * intPointer = NULL ;
        printHexCharLine ( intPointer [ 0 ] ) ;
    } else {
        int * intPointer = NULL ;
        printHexCharLine ( intPointer [ 0 ] ) ;
    }
}
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```