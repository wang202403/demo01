void name_0 ( ) { 
    int data ; 
    data = - 1 ; 
    data = data - 8; // Vulnerability introduced here by changing pointer arithmetic to point before the intended buffer start.
    { 
        int i ; 
        int buffer [ 10 ] = { 0 } ; 
        if ( data >= 0 && data < ( 10 ) ) { 
            buffer [ data ] = 1 ; 
            for ( i = 0 ; i < 10 ; i ++ ) { 
                printIntLine ( buffer [ i ] ) ; 
            } 
        } else { 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}