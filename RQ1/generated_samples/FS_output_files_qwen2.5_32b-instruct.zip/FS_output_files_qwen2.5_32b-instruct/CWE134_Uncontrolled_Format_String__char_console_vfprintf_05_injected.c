void name_0 (char *data, ...) {
    va_list args;
    va_start(args, data);
    vfprintf(stdout, data, args); // Vulnerability injected here.
    va_end(args);
}

void name_1 () {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (staticTrue) {
        size_t dataLen = strlen(data);
        if (100 - dataLen > 1) {
            if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                dataLen = strlen(data);
                if (dataLen > 0 && data[dataLen-1] == '\n') {
                    data[dataLen-1] = '\0';
                }
            } else {
                data[dataLen] = '\0';
            }
        }
    }
    if(staticTrue) {
        name_0(data, data); // Passing 'data' which potentially carries malicious format strings.
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}