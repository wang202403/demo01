```c
void name_0 ( ) {
    char * data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    while (1) {
        data = dataBadBuffer; // Vulnerability introduced here by changing to a smaller buffer.
        data[0] = '\0';
        break;
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        memmove(data, source, 100 * sizeof(char));
        data[100 - 1] = '\0'; // This line would be out-of-bounds due to the smaller buffer used.
        printLine(data);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```