TV1: void name_0 ( ) { int data ; data = 0 ; if ( staticFive == 5 ) { fscanf ( stdin , "%d" , & data ) ; } if ( staticFive == 5 ) { // Vulnerability injection point here. data++; int result = data; printIntLine(result); } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; } 

TV2: