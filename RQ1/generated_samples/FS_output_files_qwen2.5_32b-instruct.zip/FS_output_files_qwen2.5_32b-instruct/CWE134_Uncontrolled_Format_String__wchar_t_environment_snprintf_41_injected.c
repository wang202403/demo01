```c
void name_0 ( wchar_t * data ) {
    { 
        wchar_t dest [ 100 ] = L "" ;
        SNPRINTF ( dest , 100 - 1 , L "%s" , data ) ;
        printWLine ( data ); // Vulnerability injected here by replacing dest with data in print call.
    } 
}

void name_1 ( ) {
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    { 
        size_t dataLen = wcslen ( data ) ;
        wchar_t * environment = GETENV ( ENV_VARIABLE ) ;
        if ( environment != NULL )
        {
            wcsncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
        }
    } 
    name_0 ( data ) ; 
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_1 ( ) ; 
    return 0 ; 
}
```