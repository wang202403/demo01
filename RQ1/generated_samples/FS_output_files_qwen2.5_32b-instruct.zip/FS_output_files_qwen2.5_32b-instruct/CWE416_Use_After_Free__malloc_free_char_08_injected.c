```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( staticReturnsTrue ( ) ) {
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        memset ( data , 'A' , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        free ( data ) ; // Memory is freed here.
    }
    if ( staticReturnsTrue ( ) ) {
        printLine(data); // Vulnerability: accessing `data` after freeing it, leading to a use-after-free error.
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```