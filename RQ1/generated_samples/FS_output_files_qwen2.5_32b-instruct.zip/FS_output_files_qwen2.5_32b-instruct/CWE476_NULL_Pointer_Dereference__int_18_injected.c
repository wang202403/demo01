void name_0 ( ) { 
    int * data ; 
    goto source ; 
source : 
    data = NULL ; 
    goto sink ; 
sink : 
    printIntLine ( * data ) ;  
} 

int main ( int argc , char * argv [ ] )
{ 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}