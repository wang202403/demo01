```c
void name_0 ( char * data ) {
    char source[100];
    memset(source, 'C', 100 - 1);
    source[100 - 1] = '\0';
    strcpy(data, source);
    printLine(data);
}

void name_1 ( ) {
    char * data;
    char * dataBuffer = (char *) ALLOCA(100 * sizeof(char));
    memset(dataBuffer , 'A' , 100 - 1);
    dataBuffer[100 - 1] = '\0';
    // Modification here:
    data = dataBuffer - 8; // Vulnerability
    name_0 (data);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```