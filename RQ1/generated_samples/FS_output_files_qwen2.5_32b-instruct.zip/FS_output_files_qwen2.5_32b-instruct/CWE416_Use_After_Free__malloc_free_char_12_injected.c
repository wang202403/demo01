```c
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
        if ( data == NULL ) { exit ( - 1 ) ; }
        memset ( data , 'A' , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        free ( data ) ;
    } else {
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
        if ( data == NULL ) { exit ( - 1 ) ; }
        memset ( data , 'A' , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        free ( data ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        printLine(data); // Vulnerability: use-after-free
    } else {
        printLine(data); // Vulnerability: use-after-free
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```