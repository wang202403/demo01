TV2:
```c
void name_0 ( ) {
    struct CharVoid structCharVoid;
    structCharVoid.voidSecond = (void *) SRC_STR;
    printWLine((wchar_t *)structCharVoid.voidSecond);
    memcpy(structCharVoid.charFirst, SRC_STR, sizeof(structCharVoid));
    structCharVoid.charFirst[(sizeof(structCharVoid.charFirst) / sizeof(wchar_t)) - 1] = L'\0';
    printWLine((wchar_t *)structCharVoid.charFirst);
    printWLine((wchar_t *)structCharVoid.voidSecond);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```