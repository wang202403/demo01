TV2:
```c
void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    if ( globalReturnsTrue ( ) ) { 
        data = ( short ) RAND32 ( ) ; 
    } 
    if ( globalReturnsTrue ( ) ) { 
        if ( data > 0 ) { 
            // Vulnerability injected by removing the bounds checking condition
            short result = data * 2 ; 
            printIntLine ( result ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```