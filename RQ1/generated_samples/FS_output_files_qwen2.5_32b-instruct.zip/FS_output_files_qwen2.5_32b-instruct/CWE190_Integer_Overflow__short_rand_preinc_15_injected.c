TV2:
```c
void name_0 ( ) { 
    short data; 
    data = 0; 
    switch (6) {
        case 6: 
            data = (short) RAND32(); 
            break;
        default: 
            break;
    }
    switch (7) {
        case 7: 
            ++data; 
            short result = data; 
            printIntLine(result); 
            break;
        default: 
            break;
    } 
} 
int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```