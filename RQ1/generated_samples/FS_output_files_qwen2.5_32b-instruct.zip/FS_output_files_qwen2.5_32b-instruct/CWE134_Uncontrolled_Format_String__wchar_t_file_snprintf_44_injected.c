void name_0 ( wchar_t * data ) { 
    { 
        wchar_t dest [ 100 ] = L "" ; 
        SNPRINTF ( dest , 100 - 1 , data) ; // Vulnerability injected here
        printWLine ( dest ) ; 
    } 
} 

void name_1 ( ) { 
    wchar_t * data ; 
    void ( * funcPtr ) ( wchar_t * ) = name_0 ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    { 
        size_t dataLen = wcslen ( data ) ; 
        FILE * pFile ; 
        if ( 100 - dataLen > 1 ) { 
            pFile = fopen ( FILENAME , "r" ) ; 
            if ( pFile != NULL ) { 
                if ( fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , pFile ) == NULL ) { 
                    data [ dataLen ] = L '\0' ; 
                } fclose ( pFile ) ; 
            } 
        } 
    } 
    funcPtr ( data ) ; 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_1 ( ) ; 
    return 0 ; 
}