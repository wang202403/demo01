```c
void name_0 ( ) { 
    int64_t data ; 
    data = 0LL ; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        data = LLONG_MIN ; 
    } 
    if ( STATIC_CONST_FIVE == 5 ) {
        int64_t result = data - 1 ;
        printLongLongLine ( result ) ;
    }
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```