```c
void name_0 ( ) {
    wchar_t * data ;
    if ( GLOBAL_CONST_FIVE == 5 ) {
        data = NULL ;
    }
    if ( GLOBAL_CONST_FIVE == 5 ) {
        printWcharLine( data[0] );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```