TV2:
```c
void name_0 ( ) { 
    char * data ; 
    data = NULL ; 
    if ( globalReturnsTrue ( ) ) { 
        { 
            char * dataBuffer = ( char * ) malloc ( 100 * sizeof ( char ) ) ; 
            if ( dataBuffer == NULL ) { 
                exit ( - 1 ) ; 
            } 
            memset ( dataBuffer , 'A' , 100 - 1 ) ; 
            dataBuffer [ 100 - 1 ] = '\0' ; 
            data = dataBuffer - 8; // Vulnerability introduced here
        } 
    } 
    { 
        char source [ 100 ] ; 
        memset ( source , 'C' , 100 - 1 ) ; 
        source [ 100 - 1 ] = '\0' ; 
        memcpy ( data , source , 100 * sizeof ( char ) ) ; 
        data [ 100 - 1 ] = '\0' ; 
        printLine ( data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```