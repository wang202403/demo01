```c
#include <stdlib.h>
#include <string.h>

void name_0 ( ) {
    if ( globalReturnsTrue() ) {
        char *data;
        
        // Allocate memory, similar to "good" pattern but leading towards a vulnerability
        data = strdup("GoodSink");
        
        { 
            char *reversedString = helperGood(data);
            free(data);  // Free the allocated memory
            printLine(reversedString);  // Use-after-free vulnerability introduced here
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```