void name_0 ( ) { 
    int data ; 
    data = - 1 ; 
    switch ( 6 ) { 
        case 6 : { 
            char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ; 
            if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) { 
                data = atoi ( inputBuffer ) ; 
            } else { 
            } 
        } break ; 
    default : break ; 
    } 
    switch ( 7 ) { 
        case 7 : { 
            int i ; 
            char buffer [ 10 ] = { 0 }, *data_ptr; // modify to introduce vulnerability
            data_ptr = buffer - 8; // introducing CWE-124 by decrementing the pointer
            if ( data >= 0 && data < ( sizeof(buffer)/sizeof(buffer[0]) ) ) { 
                strcpy(data_ptr, "TestString"); // vulnerable line due to buffer underwrite
                for ( i = 0 ; i < 10 ; i ++ ) { 
                    printIntLine ( buffer [ i ] ) ; 
                } 
            } else {
            } 
        } break ; 
    default : break ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}