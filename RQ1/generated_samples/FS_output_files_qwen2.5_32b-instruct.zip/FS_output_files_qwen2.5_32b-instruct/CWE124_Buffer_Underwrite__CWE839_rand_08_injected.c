TV2:
```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    int data ;
    data = - 1 ;
    if ( staticReturnsTrue ( ) ) {
        data = RAND32 ( ) - 8 ;
    }
    if ( staticReturnsTrue ( ) ) {
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            if ( data >= 0 && data < ( 10 ) ) {
                buffer [ data ] = 1 ;
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                }
            } else {
            }
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```