```c
void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    if ( globalFive == 5 ) { 
        data = ( short ) RAND32 ( ) ; 
    } 
    if ( globalFive == 5 ) { 
        short result = data + 1 ; 
        printIntLine ( result ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```