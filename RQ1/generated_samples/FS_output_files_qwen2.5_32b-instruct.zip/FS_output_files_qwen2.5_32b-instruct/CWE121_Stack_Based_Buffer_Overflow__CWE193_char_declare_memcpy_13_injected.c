void name_0 ( ) {
    char * data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (GLOBAL_CONST_FIVE == 5) {
        data = dataBadBuffer; // Vulnerability introduced: buffer is now too small.
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memcpy(data, source, (strlen(source) + 1) * sizeof(char)); // Potential for overflow based on the size of `source`.
        printLine(data);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}