```c
void name_0 ( ) {
    int data;
    data = 0;

    if ( globalFive == 5 ) {
        {
            char inputBuffer [ CHAR_ARRAY_SIZE ] = "";
            if ( fgets ( inputBuffer, CHAR_ARRAY_SIZE, stdin ) != NULL )
                data = atoi ( inputBuffer );
        }
    }

    if ( globalFive == 5 ) {
        if ( data > 0 ) {
            int result = data * 2; // Vulnerability injected here
            printIntLine ( result );
        }
    }

}

int main ( int argc, char * argv [ ] )
{
    srand ( ( unsigned ) time ( NULL ) );

    name_0 ( );

    return 0;
}
```