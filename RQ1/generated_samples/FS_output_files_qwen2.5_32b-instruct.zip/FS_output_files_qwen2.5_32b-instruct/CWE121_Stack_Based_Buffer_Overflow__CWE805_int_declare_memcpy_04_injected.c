void name_0 ( ) {
    int * data;
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    if (STATIC_CONST_TRUE) {
        data = &dataBadBuffer[0]; // Changed to point to smaller buffer.
    }
    { 
        int source[100] = {0};
        memcpy(data, source, sizeof(dataBadBuffer)); // Vulnerability introduced: copying more than the target buffer size if `data` points to `dataBadBuffer`.
        printIntLine(data[0]);
    }
}
int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}