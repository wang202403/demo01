```c
void name_0(char * data) {
    printHexCharLine(data[0]); // Vulnerable code that dereferences a potentially null pointer.
}

void name_1() {
    char * data;
    void (*funcPtr)(char *) = name_0;
    data = NULL;
    funcPtr(data);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```