void name_0 ( ) { 
    int64_t data ; 
    data = 0L L ; 
    if ( globalReturnsTrue ( ) ) { 
        data = ( int64_t ) RAND64 ( ) ; 
    } 
    if ( globalReturnsTrue ( ) ) { 
        data -- ; 
        int64_t result = data ; 
        printLongLongLine ( result ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}