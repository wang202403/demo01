TV2:
```c
void name_0 ( ) {
    void * data ;
    data = NULL ;
    if ( globalTrue ) {
        data = ( void * ) WIDE_STRING ;
    }
    if ( globalTrue ) {
        { 
            size_t dataLen = wcslen ( ( wchar_t * ) data ) + 1;
            void * dest = ( void * ) ALLOCA ( ( dataLen - 1 ) * sizeof ( wchar_t ) );
            ( void ) wcscpy ( dest , data ); // Vulnerability: Dest is too small for the data copied.
            printWLine ( ( wchar_t * ) dest );
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```