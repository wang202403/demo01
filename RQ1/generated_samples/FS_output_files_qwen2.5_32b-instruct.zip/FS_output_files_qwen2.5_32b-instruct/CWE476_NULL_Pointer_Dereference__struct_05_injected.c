TV2:
```c
void name_0 ( ) { twoIntsStruct * data ; if ( staticTrue ) { data = NULL ; } if ( staticTrue ) { printIntLine ( data -> intOne ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```