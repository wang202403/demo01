```c
void name_0 ( ) { 
    if ( STATIC_CONST_TRUE ) { 
        { 
            char * reversedString = helperGood ( "GoodSink" ) ; 
            free(reversedString);
            printLine ( reversedString ) ;
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```