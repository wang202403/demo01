void name_0(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, "%s", args); // Safe line to be modified
        va_end(args);

        // Introduce the vulnerability by using `fprintf` directly without a format string:
        fprintf(stdout, data);
    }
}

void name_1() {
    char *data;
    CWE134_Uncontrolled_Format_String__char_file_w32_vsnprintf_34_unionType myUnion;
    char dataBuffer[100] = "";
    data = dataBuffer;

    {
        size_t dataLen = strlen(data);
        FILE *pFile;
        if (100 - dataLen > 1) {
            pFile = fopen(FILENAME, "r");
            if (pFile != NULL) {
                if (fgets(data + dataLen, (int)(100 - dataLen), pFile) == NULL) {
                    data[dataLen] = '\0';
                }
                fclose(pFile);
            }
        }
    }

    myUnion.unionFirst = data;
    {
        char *data = myUnion.unionSecond;
        name_0(data, data); // Call with the vulnerable function
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}