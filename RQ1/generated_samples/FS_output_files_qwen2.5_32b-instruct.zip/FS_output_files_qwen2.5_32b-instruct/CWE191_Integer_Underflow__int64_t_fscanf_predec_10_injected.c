TV2:
```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL;
    if ( globalTrue ) {
        fscanf ( stdin , "%" SCNd64 , & data );
    }
    if ( globalTrue ) {
        -- data ;
        int64_t result = data ;
        printLongLongLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```