```c
void name_0 ( ) { char data ; data = ' ' ; if ( staticFive == 5 ) { data = ( char ) RAND32 ( ) ; } if ( staticFive == 5 ) { data -- ; char result = data ; printHexCharLine ( result ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```