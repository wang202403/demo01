```c
short name_0 ( short data ) { 
    fscanf ( stdin , "%hd" , & data ) ; 
    return data ; 
} 

void name_1 ( ) { 
    short data ; 
    data = 0 ; 
    data = name_0 ( data ) ; 
    if ( data > SHRT_MIN ) { 
        data -- ;
        short result = data * data; // Vulnerability injection: unsafe multiplication
        printIntLine ( result ) ; 
    } else { 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_1 ( ) ; 
    return 0 ; 
}
```