```c
void name_0 ( ) { 
    twoIntsStruct * data ; 
    data = NULL ; 
    while ( 1 ) {
        data = ( twoIntsStruct * ) malloc ( 100 * sizeof ( twoIntsStruct ) ) ;
        if ( data == NULL ) { exit ( - 1 ) ; }
        { 
            size_t i ; 
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] . intOne = 1 ; 
                data [ i ] . intTwo = 2 ;
            }
        } 
        free ( data ) ; 
        break ; 
    }
    while ( 1 ) { printLine(data); break ; } 
} 

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```