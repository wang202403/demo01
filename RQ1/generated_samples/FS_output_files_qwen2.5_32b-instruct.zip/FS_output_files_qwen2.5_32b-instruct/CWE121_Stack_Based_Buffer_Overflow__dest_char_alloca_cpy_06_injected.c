TV2:
```c
void name_0 ( ) {
    char * data ;
    // Changed buffer size from 100 to 50
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ;
    // Commented out the properly allocated buffer.
    //char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ;

    if ( STATIC_CONST_FIVE == 5 ) {
        // Force the assignment to use the inadequately sized buffer
        data = dataBadBuffer ;
        data [ 0 ] = '\0' ;
    }

    { 
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;

        strcpy ( data , source ) ; // Vulnerable: copying 100 characters into a buffer of size 50.
        printLine ( data ) ;
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ; 
}
```