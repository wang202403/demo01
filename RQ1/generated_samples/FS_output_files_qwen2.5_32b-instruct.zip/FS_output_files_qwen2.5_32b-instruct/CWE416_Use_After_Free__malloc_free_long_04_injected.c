```c
void name_0 () {
    long * data;
    data = NULL;

    if (STATIC_CONST_TRUE) {
        data = (long *) malloc(100 * sizeof(long));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5L;
            }
        }
        free(data);
    }

    if (STATIC_CONST_TRUE) {
        printLine(data); // Accessing 'data' after it has been freed
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```