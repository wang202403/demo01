```c
void name_0() {
    short data;
    data = 0;

    if (STATIC_CONST_TRUE) {
        data = (short)RAND32();
    }

    if (STATIC_CONST_TRUE) {
        // Vulnerability injection point is here!
        short result = data - 1; 
        printIntLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```