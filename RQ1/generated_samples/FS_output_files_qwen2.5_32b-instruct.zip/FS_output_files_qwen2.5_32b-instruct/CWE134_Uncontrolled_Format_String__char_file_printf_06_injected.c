```c
void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    if ( STATIC_CONST_FIVE == 5 ) {
        { size_t dataLen = strlen ( data ) ; 
           FILE * pFile ; 
           if ( 100 - dataLen > 1 ) {
              pFile = fopen ( FILENAME , "r" ) ;
              if ( pFile != NULL ) {
                 if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , pFile ) == NULL ) {
                    data [ dataLen ] = '\0' ;
                 } 
                 fclose ( pFile ) ;
              }
           }
        }  
    }

    if ( STATIC_CONST_FIVE == 5 ) { printf ( data ) ; } // Vulnerable line
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```