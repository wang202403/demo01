```c
void name_0 ( ) { 
    wchar_t * data ; 
    wchar_t * * dataPtr1 = & data ; 
    wchar_t * * dataPtr2 = & data ; 
    wchar_t * dataBadBuffer = ( wchar_t * ) ALLOCA ( 50 * sizeof ( wchar_t ) ) ; 
    wchar_t * dataGoodBuffer = ( wchar_t * ) ALLOCA ( 100 * sizeof ( wchar_t ) ) ; 
    { 
        wchar_t * data = * dataPtr1 ; 
        data = dataBadBuffer ; // Vulnerability injected
        data [ 0 ] = L '\0' ; 
        * dataPtr1 = data ; 
    } 
    { 
        wchar_t * data = * dataPtr2 ; 
        { 
            wchar_t source [ 100 ] ; 
            wmemset ( source , L 'C' , 100 - 1 ) ; 
            source [ 100 - 1 ] = L '\0' ; 
            wcscat ( data , source ) ; 
            printWLine ( data ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```