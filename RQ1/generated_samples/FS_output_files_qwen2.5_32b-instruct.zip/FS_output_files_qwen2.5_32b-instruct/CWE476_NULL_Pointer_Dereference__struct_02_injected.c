```c
void name_0 ( ) { 
    twoIntsStruct * data ; 
    if ( 1 ) { 
        data = NULL ; 
    } 
    if ( 1 ) { 
        printIntLine ( data -> intOne ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```