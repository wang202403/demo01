```c
void name_0 ( ) { 
int64_t data ; 
data = 0LL ; 
while ( 1 ) { 
    data = ( int64_t ) RAND64 ( ) ; 
    break ; 
} 
while ( 1 ) { 
    if ( data > 0 ) { 
        // Vulnerability: Removed safeguard preventing overflow
//      if ( data < ( LLONG_MAX / 2 ) ) {

            int64_t result = data * 2 ; 
            printLongLongLine ( result ) ; 
        } else {}

    break ; 
} 
} 
int main ( int argc , char * argv [ ] ) { 
srand ( ( unsigned ) time ( NULL ) ) ; 
name_0 ( ) ; 
return 0 ; 
}
```