```c
void name_0 ( ) { 
    if ( 1 ) { 
        {
            char * reversedString = helperGood ( "GoodSink" ) ;
            printLine ( reversedString ) ;
            free(reversedString);
            printLine ( reversedString );            
        } 
    } 
}
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```