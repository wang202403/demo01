```c
void name_0 ( ) {
    unsigned int data ;
    data = 0 ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = ( unsigned int ) RAND32 ( ) ;
    } else {
        data = ( unsigned int ) RAND32 ( ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        unsigned int result = data + 1 ; // Vulnerable line, no check for integer overflow
        printUnsignedLine ( result );
    } else {
        unsigned int result = data + 1 ; // Vulnerable line, no check for integer overflow
        printUnsignedLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```