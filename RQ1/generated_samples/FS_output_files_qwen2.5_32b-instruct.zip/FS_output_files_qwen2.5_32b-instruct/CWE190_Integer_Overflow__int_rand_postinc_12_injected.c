TV2:
```c
void name_0 ( ) {
    int data ;
    data = 0 ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = RAND32 ( ) ;
    }
    else {
        data = RAND32 ( ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        data++ ;
        int result = data ;
        printIntLine ( result ) ;
    }
    else {
        data++ ;
        int result = data ;
        printIntLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```