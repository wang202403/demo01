```c
void name_0 ( ) { twoIntsStruct * data ; data = NULL ; { twoIntsStruct * dataCopy = data ; twoIntsStruct * data = dataCopy ; printIntLine ( data -> intOne ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```