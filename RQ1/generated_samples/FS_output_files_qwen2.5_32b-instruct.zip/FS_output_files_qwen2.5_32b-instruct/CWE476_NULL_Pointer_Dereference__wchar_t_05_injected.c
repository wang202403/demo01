void name_0 ( ) { wchar_t * data ; if ( staticTrue ) { data = NULL ; } if ( staticTrue ) { printWcharLine ( data [ 0 ] ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; } 

TV2: