```c
void name_0 ( ) { 
    char * data ; 
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ; 
    char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ; 
    if ( staticFive == 5 ) { 
        data = dataBadBuffer ; // Vulnerability introduced here by pointing to a smaller buffer
        data [ 0 ] = '\0' ; 
    } 
    { 
        char source [ 100 ] ; 
        memset ( source , 'C' , 100 - 1 ) ; 
        source [ 100 - 1 ] = '\0' ; 
        strncat ( data , source , 100 ) ; // Potential buffer overflow as 100 characters are added to a buffer that can only hold up to 50
        printLine ( data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```