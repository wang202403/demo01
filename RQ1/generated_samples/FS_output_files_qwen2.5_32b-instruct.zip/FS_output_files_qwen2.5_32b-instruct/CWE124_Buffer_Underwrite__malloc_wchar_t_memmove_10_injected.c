void name_0 ( ) {
    wchar_t * data;
    data = NULL;
    if (globalTrue) {
        {
            wchar_t * dataBuffer = (wchar_t *) malloc(100 * sizeof(wchar_t));
            if (dataBuffer == NULL) {
                exit(-1);
            }
            wmemset(dataBuffer, L'A', 100 - 1);
            dataBuffer[100 - 1] = L'\0';
            // Modify to introduce CWE-124
            data = dataBuffer - 8; 
        }
    } {
        wchar_t source[100];
        wmemset(source, L'C', 100 - 1);
        source[100 - 1] = L'\0';
        memmove(data, source, 100 * sizeof(wchar_t));
        data[100 - 1] = L'\0';
        printWLine(data);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}