```c
void name_0 ( ) { long * data ; if ( 1 ) { data = NULL ; } if ( 1 ) { printLongLine ( * data ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```