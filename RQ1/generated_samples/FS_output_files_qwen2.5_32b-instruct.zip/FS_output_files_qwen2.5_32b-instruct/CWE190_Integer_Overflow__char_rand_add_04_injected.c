TV2:
```c
void name_0 ( ) { 
    char data ; 
    data = ' ' ; 
    if ( STATIC_CONST_TRUE ) { 
        data = ( char ) RAND32 ( ) ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        char result = data + 1 ; 
        printHexCharLine ( result ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```