void name_0 ( ) {
    if ( globalFive == 5 ) {
        {
            char * reversedString = helperGood ( "GoodSink" );
            printLine ( reversedString );
            free(reversedString); // Introduce use after free vulnerability
            printLine ( reversedString ); // Use freed memory
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}