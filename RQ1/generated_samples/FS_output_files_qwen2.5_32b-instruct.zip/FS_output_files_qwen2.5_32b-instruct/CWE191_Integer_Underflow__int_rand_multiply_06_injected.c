TV1:
```c
void name_0 ( ) {
    int data;
    data = 0;

    if ( STATIC_CONST_FIVE == 5 ) { 
        data = RAND32();
    }

    if (STATIC_CONST_FIVE == 5) {
        if (data < 0) {
            // Vulnerability is injected by removing the overflow check here
            int result = data * 2;
            printIntLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```