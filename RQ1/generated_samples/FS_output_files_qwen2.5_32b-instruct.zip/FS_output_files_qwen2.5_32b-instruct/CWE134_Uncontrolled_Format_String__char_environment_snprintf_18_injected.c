void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ; 
    data = dataBuffer ; 
    goto source ; 
    
source : 
    { 
        size_t dataLen = strlen ( data ) ; 
        char * environment = GETENV ( ENV_VARIABLE ) ; 
        if ( environment != NULL ) { 
            strncat ( data + dataLen , environment , 100 - dataLen - 1 ) ; 
        } 
    } 
    
sink : 
    { 
        char dest [ 100 ] = "" ; 
        SNPRINTF ( dest, 100 - 1, data ); // Vulnerability introduced here.
        printLine ( dest ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}