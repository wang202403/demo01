```c
void name_0 ( ) {
    short data;
    data = 0;
    goto source;

source:
    fscanf(stdin, "%hd", &data);
    goto sink;

sink:
    short result = data + 1;
    printIntLine(result);

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```