```c
void name_0 () {
    char * data ;
    char * dataBadBuffer = (char *) ALLOCA(50 * sizeof(char)) ;
    char * dataGoodBuffer = (char *) ALLOCA(100 * sizeof(char)) ;
    if ( 1 ) {
        data = dataBadBuffer ; // Vulnerable assignment
        data [ 0 ] = '\0' ;
    }

    {
        char source [100] ;
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        memmove(data, source, 100 * sizeof(char));
        data[100 - 1] = '\0';
        printLine(data);
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```