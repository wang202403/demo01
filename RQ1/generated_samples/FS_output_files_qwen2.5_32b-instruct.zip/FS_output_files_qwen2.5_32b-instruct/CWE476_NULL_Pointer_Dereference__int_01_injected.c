void name_0 ( ) { 
    int * data ; 
    data = NULL ; 
    printIntLine ( * data ) ; 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}