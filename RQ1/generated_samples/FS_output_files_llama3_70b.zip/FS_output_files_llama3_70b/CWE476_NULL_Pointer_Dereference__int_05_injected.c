Here is the modified code with the injected vulnerability:

TV2:
```
void name_0 () {
    int *data;
    if (staticTrue) {
        data = NULL;
    }
    if (staticTrue) {
        printIntLine(*data); // Vulnerability injected: Null pointer dereference
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```