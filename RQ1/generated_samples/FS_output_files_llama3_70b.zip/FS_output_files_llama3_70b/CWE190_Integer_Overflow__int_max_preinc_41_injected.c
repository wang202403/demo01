Here is the modified code with the injected vulnerability:

TV2:
```
void name_0(int data) {
    ++data;
    int result = data;
    printIntLine(result);
}

void name_1() {
    int data;
    data = 0;
    data = INT_MAX;
    name_0(data);
}

int main(int argc, char* argv[]) {
    srand((unsigned) time(NULL));
    name_1();
    return 0;
}
```