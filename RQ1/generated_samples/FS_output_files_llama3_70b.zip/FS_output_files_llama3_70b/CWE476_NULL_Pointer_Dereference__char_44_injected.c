Here is the modified vulnerable code:

```
void name_0 ( char * data ) { printHexCharLine ( data [ 0 ] ) ; }
void name_1 ( ) { char * data ; void ( * funcPtr ) ( char * ) = name_0 ; data = NULL ; funcPtr ( data ) ; }
int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_1 ( ) ; return 0 ; }
```