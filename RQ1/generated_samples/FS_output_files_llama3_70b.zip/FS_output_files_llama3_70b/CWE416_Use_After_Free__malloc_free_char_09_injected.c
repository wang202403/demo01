Here is the modified code with the injected vulnerability:

TV2:
```c
void name_0() {
    char *data;
    data = NULL;
    if (GLOBAL_CONST_TRUE) {
        data = (char *)malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
        printLine(data); // Injected vulnerability: Use-After-Free
    }
    if (GLOBAL_CONST_TRUE) {
        ;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```
Note that I've added the `printLine(data)` statement after the `free(data)` call, exactly as described in the summary. This code now contains a CWE-416 Use-After-Free vulnerability.