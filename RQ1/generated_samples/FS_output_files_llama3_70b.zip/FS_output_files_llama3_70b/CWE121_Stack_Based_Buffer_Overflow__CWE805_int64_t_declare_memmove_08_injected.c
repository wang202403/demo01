Here is the modified code with the injected vulnerability:

```c
int staticReturnsTrue () { return 1; }
int staticReturnsFalse () { return 0; }
void name_0 () {
    int64_t *data;
    int64_t dataBadBuffer [50];
    int64_t dataGoodBuffer [100];
    if (staticReturnsTrue ()) {
        data = dataGoodBuffer;
    } else {
        data = dataBadBuffer;
    }
    int64_t source [100] = {0};
    memmove(data, source, 100 * sizeof(data)); // Vulnerability injected here
    printLongLongLine(data[0]);
}
int main (int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```

Note that I have replaced `sizeof(int64_t)` with `sizeof(data)`, which is the vulnerable code as per the summary.