Here is the modified code with the injected vulnerability:
```
void name_0() {
    goto sink;
sink:
    {
        int *intPointer = NULL;
        *intPointer = 10; // Vulnerability injected here: null pointer dereference
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```