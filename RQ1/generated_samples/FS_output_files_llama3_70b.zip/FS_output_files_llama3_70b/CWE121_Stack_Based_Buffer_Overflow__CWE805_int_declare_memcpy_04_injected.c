Here is the modified code (TV2) with the injected vulnerability:

TV2:
```
void name_0() {
    int *data;
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    if (STATIC_CONST_TRUE) {
        data = dataBadBuffer; // pointing to a smaller buffer
    } else {
        data = dataGoodBuffer;
    }
    int source[100] = {0};
    memcpy(data, source, 100 * sizeof(int)); // vulnerable to buffer overflow
    printIntLine(data[0]);
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```