Here is the modified code with the injected Use After Free (UAF) vulnerability:

```c
void name_0 () {
    int *data;
    data = NULL;
    if (globalReturnsTrueOrFalse()) {
        data = (int *)malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5;
            }
        }
        free(data);
        printLine(data); // UAF vulnerability: using freed memory
    } else {
        data = (int *)malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5;
            }
        }
        free(data);
        printLine(data); // UAF vulnerability: using freed memory
    }
    if (globalReturnsTrueOrFalse()) {
        ;
    } else {
        ;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```

Note that I've added the `printLine(data)` call after `free(data)` in both branches of the conditional statements, which uses the already freed memory and injects a Use After Free (UAF) vulnerability.