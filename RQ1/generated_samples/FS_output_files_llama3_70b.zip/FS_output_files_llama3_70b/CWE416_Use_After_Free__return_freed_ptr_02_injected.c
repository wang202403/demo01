Here is the modified code with the injected vulnerability:

TV2:
```c
void name_0() {
    if (1) {
        char *reversedString = helperGood("GoodSink");
        printLine(reversedString);
        char *ptr = NULL;
        ptr->toString(); // Vulnerability injected here: null-pointer-dereference
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```