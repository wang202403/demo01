Here is the modified code:

TV2:
void name_0 () {
    int64_t data;
    data = 0LL;
    fscanf(stdin, "%" SCNd64, &data);
    int64_t result = data - 1;
    printLongLongLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}