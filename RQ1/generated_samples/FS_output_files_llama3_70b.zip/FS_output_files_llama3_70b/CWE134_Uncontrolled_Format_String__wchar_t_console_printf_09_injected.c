Here is the modified code with the injected vulnerability:

```c
void name_0() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (GLOBAL_CONST_TRUE) {
        {
            size_t dataLen = wcslen(data);
            if (100 - dataLen > 1) {
                if (fgetws(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                    dataLen = wcslen(data);
                    if (dataLen > 0 && data[dataLen - 1] == L'\n') {
                        data[dataLen - 1] = L'\0';
                    }
                } else {
                    data[dataLen] = L'\0';
                }
            }
        }
    }
    if (GLOBAL_CONST_TRUE) {
        wprintf(data, L"\n"); // Vulnerable code: user-controlled input data as a formatting string
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```