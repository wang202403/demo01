Here is the modified code (TV2) with the injected vulnerability:

TV2:
void name_0 ( ) { if ( STATIC_CONST_FIVE == 5 ) { int * intPointer = NULL ; *intPointer = 10; } }
int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }