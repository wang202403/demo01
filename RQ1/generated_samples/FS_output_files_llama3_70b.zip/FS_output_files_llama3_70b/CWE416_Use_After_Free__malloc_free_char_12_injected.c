Here is the modified code with the injected vulnerability:

```c
void name_0 () {
    char *data;
    data = NULL;
    if (globalReturnsTrueOrFalse()) {
        data = (char*) malloc(100 * sizeof(char));
        if (data == NULL) { exit(-1); }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
        strlen(data); // Injected vulnerability: Use-after-free
    } else {
        data = (char*) malloc(100 * sizeof(char));
        if (data == NULL) { exit(-1); }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
        printf("%s", data); // Injected vulnerability: Use-after-free
    }
    if (globalReturnsTrueOrFalse()) {
        ;
    } else {
        ;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```

Note that I've injected two instances of the vulnerability: one in each branch of the conditional statement. This is to ensure that the vulnerability is present regardless of which branch is taken at runtime.