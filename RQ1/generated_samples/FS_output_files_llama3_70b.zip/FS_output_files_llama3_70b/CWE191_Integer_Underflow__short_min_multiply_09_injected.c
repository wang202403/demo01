Here is the modified code with the injected vulnerability:

```
void name_0 () {
    short data;
    data = 0; 
    short result = data * 2;
    printIntLine(result);
}

int main (int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```