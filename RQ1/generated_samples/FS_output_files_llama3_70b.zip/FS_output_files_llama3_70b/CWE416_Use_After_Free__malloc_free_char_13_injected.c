Here is the modified code with the injected vulnerability:

```c
void name_0 () {
    char *data;
    data = NULL;
    if (GLOBAL_CONST_FIVE == 5) {
        data = (char *)malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
        printLine(data); // injected vulnerability
    }
    if (GLOBAL_CONST_FIVE == 5) {
        ;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```

Note that I added the `printLine(data)` function call after `free(data)`, which uses the freed pointer `data`, making the program vulnerable to use-after-free attacks.