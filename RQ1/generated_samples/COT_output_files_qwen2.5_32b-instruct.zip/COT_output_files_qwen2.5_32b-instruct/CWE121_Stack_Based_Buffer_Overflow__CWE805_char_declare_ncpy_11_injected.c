```c
void name_0() {
    char *data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100]; // Assuming it is selected
    if (globalReturnsTrue()) { 
        data = dataGoodBuffer; // large buffer, but vulnerability still present via parameter adjustment.
        data[0] = '\0';
    }

    {
        char source[100];
        memset(source, 'C', 99); 
        source[99] = '\0';

        // Vulnerable Injection
        strncpy(data, source, sizeof(structCharVoid));  
        data[99] = '\0';
       
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```
Note: Assume `structCharVoid` is defined in a way that its size (`sizeof(structCharVoid)`) exceeds the buffer limits of both `dataGoodBuffer` and `dataBadBuffer`.