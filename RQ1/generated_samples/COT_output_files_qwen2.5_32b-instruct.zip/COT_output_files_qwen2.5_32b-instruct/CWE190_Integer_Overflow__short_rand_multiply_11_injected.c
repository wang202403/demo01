```c
void name_0 ( ) {
    short data;
    data = 0;
    if (globalReturnsTrue( )) {
        data = (short) RAND32();
    }
    if (globalReturnsTrue()) {
        if (data > 0) { 
            short result = data * 2; // No bounds checking, leading potential overflow here
            printIntLine(result);
        } else {}
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```