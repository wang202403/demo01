```c
void name_0 ( ) {
    int * data;
    data = NULL;

    if ( 5 == 5 ) {
        data = (int *) malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        { 
            size_t i; 
            for( i = 0 ; i < 100 ; i++ ) {
                data[i] = 5;
            } 
        }
        free(data); // Free the allocated memory
    }

    if ( 5 == 5 ) {
        // Introduce a function call that accesses freed 'data'
        printf("Value: %d\n", data[0]); // Accessing freed memory - CWE-416 vulnerability introduced here
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```