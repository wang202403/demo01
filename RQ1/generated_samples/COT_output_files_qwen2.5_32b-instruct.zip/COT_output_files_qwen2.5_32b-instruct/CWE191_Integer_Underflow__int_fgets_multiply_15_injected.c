```c
void name_0 ( ) {
    int data;
    data = 0;
    switch (6) {
        case 6:
            {
                char inputBuffer[CHAR_ARRAY_SIZE] = "";
                if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                    data = atoi(inputBuffer);
                } else { }
            }
            break;
        default: break;
    }
    switch (7) {
        case 7:
            if (data < 0) {
                int result = data * 2; // Vulnerable to integer underflow
                printIntLine(result);
            }
            break;
        default: break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```