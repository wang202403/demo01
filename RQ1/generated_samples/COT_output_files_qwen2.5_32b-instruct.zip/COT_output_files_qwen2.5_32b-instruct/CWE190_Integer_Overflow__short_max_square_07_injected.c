```c
void name_0 ( ) {
    short data ;
    data = 0 ;
    if ( staticFive == 5 ) {
        data = SHRT_MAX ;
    }
    if ( staticFive == 5 ) {
        // Vulnerability Injection Point - Removing overflow check for demonstration purposes.
        short result = data * data ; 
        printIntLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```