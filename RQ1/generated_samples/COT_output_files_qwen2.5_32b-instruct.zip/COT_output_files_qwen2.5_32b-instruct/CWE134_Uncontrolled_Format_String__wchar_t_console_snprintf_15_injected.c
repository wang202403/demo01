void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    switch ( 6 ) {
        case 6 :
            {
                size_t dataLen = wcslen ( data ) ;
                if ( 100 - dataLen > 1 ) {
                    if ( fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) {
                        dataLen = wcslen ( data ) ;
                        if ( dataLen > 0 && data [ dataLen - 1 ] == L'\n' ) {
                            data [ dataLen - 1 ] = L'\0';
                        }
                    } else {
                        data [ dataLen ] = L'\0';
                    }
                }
            }
        break;
        default:
            break ;
    }

    switch ( 7 ) {
        case 7 :
            {
                wchar_t dest [ 100 ] = L"" ;
                SNPRINTF ( dest , 100 - 1 , data ); // Vulnerability introduced here
                printWLine ( dest ) ;
            }
        break;
        default:
            break ;
    }
}

int main ( int argc, char * argv[] ) {
    srand (( unsigned) time( NULL ));
    name_0( );
    return 0 ;
}