```c
void name_0 ( ) { 
    int64_t * data ; 
    if ( staticFive == 5 ) { 
        data = NULL ; 
    } 
    if ( staticFive == 5 ) { 
        printLongLongLine ( *data ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```