TV2:
```c
void name_0 ( ) {
    short data;
    data = 0;
    goto source;

source :
    data = ( short ) RAND32 ( );
    goto sink;

sink :
    short result = data - 1; // Subtraction occurs with no protective condition
    printIntLine ( result );

} 

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```