```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( ) {
    int data;
    data = 0;
    if (staticReturnsTrue()) {
        fscanf(stdin, "%d", &data);
    }
    if (staticReturnsTrue()) {
        // Unconditional operation that could cause overflow
        int result = data * data; 
        printIntLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```