```c
void name_0 ( ) { 
    char data ; 
    data = ' ' ; 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        data = ( char ) RAND32 ( ) ; 
    } 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        if ( data < 0 ) { 
            char result = data * 2 ; 
            printHexCharLine ( result ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```