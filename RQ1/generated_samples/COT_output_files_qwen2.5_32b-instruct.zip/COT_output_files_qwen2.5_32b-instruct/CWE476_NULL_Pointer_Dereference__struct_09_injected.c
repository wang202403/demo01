```c
void name_0 ( ) { 
    twoIntsStruct * data ; 
    if ( GLOBAL_CONST_TRUE ) { 
        data = NULL ; 
    } 
    if ( GLOBAL_CONST_TRUE ) { 
        printIntLine ( data -> intOne ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```