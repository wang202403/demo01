```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( ) {
    int * data ;
    data = NULL ;

    if ( staticReturnsTrue ( ) ) {
        data = ( int * ) malloc ( 100 * sizeof ( int ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        {
            size_t i ;
            for ( i = 0 ; i < 100 ; i ++ ) {
                data [ i ] = 5 ;
            }
        }

        free(data); // Memory is deallocated but used afterwards, causing a use-after-free vulnerability.
        printLine(data); // Vulnerability: Accessing freed memory.
    }

    if ( staticReturnsTrue ( ) ) { ; }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;

    return 0 ;
}
```