```c
void name_0 ( ) { 
    int data; 
    data = 0 ; 
    if ( globalReturnsTrue ( ) ) { 
        { 
            char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ; 
            if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) { 
                data = atoi ( inputBuffer ) ; 
            } else { }
        } 
    } 
    if ( globalReturnsTrue ( ) ) { 
        // Original Protection Removed to Introduce Vulnerability CWE-190: Integer Underflow or Wraparound
        int result = data - 1; 
        printIntLine(result); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```