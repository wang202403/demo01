```c
void name_0 ( ) { 
    int data ; 
    data = 0 ; 
    if ( 5 == 5 ) { 
        fscanf ( stdin , "%d" , & data ) ; 
    } 
    if ( 5 == 5 ) { 
        if ( data > 0 ) { 
            // Vulnerability Injection Point: Removed boundary condition check.
            int result = data * 2 ; 
            printIntLine ( result ) ; 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```