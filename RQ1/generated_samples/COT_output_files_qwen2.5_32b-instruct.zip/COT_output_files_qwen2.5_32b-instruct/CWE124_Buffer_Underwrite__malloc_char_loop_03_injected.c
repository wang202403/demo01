```c
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( 5 == 5 ) {
        {
            // Intentionally allocate less and adjust the pointer to simulate CWE-124
            char * tempBuffer = (char *) malloc(92); // Allocate slightly less memory
            if (tempBuffer == NULL) { 
                exit (-1); 
            }
            data = tempBuffer + 8; // Set data to point inside the buffer but simulate underflow

        } 
    }
    {
        size_t i ;
        char source [ 100 ] ; 
        memset (source, 'C', 100 - 1) ; 
        source [ 100 - 1 ] = '\0' ;
        
        // Writing from offset 8 means we are technically starting outside the main buffer
        for ( i = 0 ; i < 92; i ++ ) { 
            data [ i ] = source [ i ]; 
        }
        data [ 92 - 1 ] = '\0' ;
        printLine (data) ;
    } 
} 

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```