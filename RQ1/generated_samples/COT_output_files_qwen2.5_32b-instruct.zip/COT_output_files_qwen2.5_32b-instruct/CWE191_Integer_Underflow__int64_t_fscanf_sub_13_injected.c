```c
void name_0 ( ) { 
    int64_t data ; 
    data = 0L L ; 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        fscanf ( stdin , "%" SCNd64 , & data ) ; 
    } 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        int64_t result = data - 1 ;
        printLongLongLine ( result ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```