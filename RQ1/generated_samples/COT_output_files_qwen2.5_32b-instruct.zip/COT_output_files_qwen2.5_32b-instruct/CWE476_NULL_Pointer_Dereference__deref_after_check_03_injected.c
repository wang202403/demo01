```c
void name_0 ( ) {
    if (5 == 5) {
        int * intPointer = NULL;
        printf("%d", *intPointer); // Directly attempt to access memory through a null pointer.
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```