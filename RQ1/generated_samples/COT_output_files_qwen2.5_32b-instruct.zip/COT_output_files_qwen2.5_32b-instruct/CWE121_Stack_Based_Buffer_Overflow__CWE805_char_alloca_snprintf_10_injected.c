```c
void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) );
    char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) );

    if ( globalTrue ) { // Intentional change to dataBadBuffer for buffer overflow vulnerability
        data = dataBadBuffer;
        data [ 0 ] = '\0';
    }

    {
        char source [ 100 ];
        memset ( source , 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';

        // This SNPRINTF operation will cause a buffer overflow because dataBadBuffer is only 50 bytes but 100 are being copied
        SNPRINTF ( data , 100 , "%s" , source );

        printLine ( data );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```