```c
void name_0 ( ) {
    short data ;
    data = 0 ;
    if ( globalReturnsTrue ( ) ) {
        fscanf ( stdin , "%hd" , & data ) ;
    }
    if ( globalReturnsTrue ( ) ) {
        if ( data < 0 ) {
            // Vulnerability injection: Remove the boundary check for underflow
            short result = data * 2 ; 
            printIntLine ( result ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```