```c
void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = ( char * ) ALLOCA ( ( 10 ) * sizeof ( char ) ) ;
    char * dataGoodBuffer = ( char * ) ALLOCA ( ( 10 + 1 ) * sizeof ( char ) ) ;

    // Vulnerability injection position - always point `data` to `dataBadBuffer`
    data = dataBadBuffer;
    data [ 0 ] = '\0' ;
    
    { 
        char source [ 10 + 1 ] = SRC_STRING ; 
        memmove ( data , source , ( strlen ( source ) + 1 ) * sizeof ( char ) ) ; 
        printLine ( data ) ; 
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```