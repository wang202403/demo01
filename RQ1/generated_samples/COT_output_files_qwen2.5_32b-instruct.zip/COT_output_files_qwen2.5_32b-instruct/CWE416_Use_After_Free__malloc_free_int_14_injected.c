```c
void name_0() {
    int* data;
    data = NULL;
    if (globalFive == 5) {
        data = (int*)malloc(100 * sizeof(int));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; ++i) {
                data[i] = 5;
            }
        }
        free(data);  // Memory is freed here
    }
    if (globalFive == 5) { 
        printf("Data element: %d\n", data[0]);  // Accessing freed memory post-free operation
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```