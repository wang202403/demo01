```c
void name_0 () {
    int64_t data;
    data = 0LL;
    if (staticTrue) {
        data = LLONG_MAX;
    }
    if (staticTrue) {
        data++; // Vulnerability Injection Point - Removed bounds check.
        int64_t result = data;
        printLongLongLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```