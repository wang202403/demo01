```c
void name_0 ( ) { 
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    goto source ; 
source : 
    {
        size_t dataLen = wcslen ( data ) ; 
        wchar_t * environment = GETENV ( ENV_VARIABLE ) ; 
        if ( environment != NULL ) { 
            wcsncat ( data + dataLen , environment , 100 - dataLen - 1 ) ; 
        } 
    } 
    goto sink ; 
sink : 
    {
        wchar_t dest [ 100 ] = L "" ; 
        SWPRINTF(dest, 100-1, data); // Vulnerable: data controlled by user input
        printWLine ( dest ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```