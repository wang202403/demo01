```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printLine(twoIntsStruct * data) {
    printf("Data: %d, %d\n", data->intOne, data->intTwo);
}

void name_0 ( ) { 
    twoIntsStruct * data; 
    data = NULL; 
    if ( 5 == 5 ) { 
        data = (twoIntsStruct *) malloc(100 * sizeof(twoIntsStruct));
        if (data == NULL) { exit(-1); } 
        { size_t i;
            for (i = 0; i < 100; i++) {
                data[i].intOne = 1;
                data[i].intTwo = 2;
            }
        } 
        free(data);
    } 
    if (5 == 5) { 
        printLine(&data[0]); // Vulnerability Injection
    } 
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```