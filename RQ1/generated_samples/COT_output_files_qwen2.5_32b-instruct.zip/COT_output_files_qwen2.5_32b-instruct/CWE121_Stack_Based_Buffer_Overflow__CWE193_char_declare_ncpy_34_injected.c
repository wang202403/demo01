```c
void name_0 ( ) {
    char * data ;
    CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_34_unionType myUnion ;
    char dataBadBuffer [ 10 ] ;
    char dataGoodBuffer [ 10 + 1 ] ;

    // Vulnerability injection: Change assignment to undersized buffer
    data = dataBadBuffer ; 

    data [ 0 ] = '\0' ;
    myUnion . unionFirst = data ;
    
    {
        char * data = myUnion . unionSecond ;
        
        {
            char source [ 10 + 1 ] = SRC_STRING ;
            
            // Vulnerability injection: Use length that surpasses buffer limit
            strncpy ( data , source , strlen ( source ) + 2 ) ; 
            printLine ( data ) ;
        }
    }   
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```
TV2: