```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( staticReturnsTrue ( ) ) {
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        memset ( data , 'A' , 100 - 1 ) ;
        data [ 100 - 1 ] = '\0' ;
        free ( data ) ;
    }
    if ( staticReturnsTrue ( ) ) {
        // Vulnerability injection: using the freed pointer after freeing
        printLine(data); 
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```

Note: The provided code assumes that a `printLine(char*)` function exists. In an actual context, you would either need to define this function or utilize a standard library function appropriate for the purpose of demonstrating the use-after-free vulnerability.