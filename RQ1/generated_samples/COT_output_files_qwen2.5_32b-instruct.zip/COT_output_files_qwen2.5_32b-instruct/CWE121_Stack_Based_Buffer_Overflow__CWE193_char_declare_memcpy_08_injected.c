int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( )
{
    char * data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10+1];

    // Vulnerability Injection Point: Change to `staticReturnsFalse()` to assign the smaller buffer
    if (staticReturnsFalse())
    {
        data = dataGoodBuffer;
    }
    else
    {
        data = dataBadBuffer;   // Smaller buffer assigned here, causing overflow.
    }
    data[0] = '\0';

    {
        char source[10+1] = SRC_STRING;

        // Vulnerability Injection Point: Modify the length parameter to exceed the buffer size of `data`
        memcpy(data, source, strlen(source) + 5);   // Hardcoded oversized value.
        printLine(data);
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}