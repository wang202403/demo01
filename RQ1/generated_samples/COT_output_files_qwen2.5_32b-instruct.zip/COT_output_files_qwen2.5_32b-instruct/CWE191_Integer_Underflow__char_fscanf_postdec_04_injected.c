```c
void name_0 ( ) { 
    char data ; 
    data = ' ' ; 
    if ( STATIC_CONST_TRUE ) { 
        fscanf ( stdin , "%c" , & data ) ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        // Remove this check to introduce vulnerability
        // if (data > CHAR_MIN) {
            data -- ; 
            char result = data ; 
            printHexCharLine ( result ) ; 
       // }
    } else { 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```