```c
void name_0 ( ) {
    if ( STATIC_CONST_FIVE == 5 ) { 
        int * intPointer = NULL;
        // Intentionally remove the check for intPointer being non-NULL

        foo(intPointer);  // Directly dereference potentially null pointer
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ();
    return 0;
}
```