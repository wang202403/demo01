```c
void name_0 ( ) {
    int data;
    data = 0;
    if (STATIC_CONST_FIVE == 5) {
        data = INT_MIN;
    }
    if (STATIC_CONST_FIVE == 5) {
        if (data < 0) {
            int result = data * 2; // Vulnerability introduced here
            printIntLine(result);
        }
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```