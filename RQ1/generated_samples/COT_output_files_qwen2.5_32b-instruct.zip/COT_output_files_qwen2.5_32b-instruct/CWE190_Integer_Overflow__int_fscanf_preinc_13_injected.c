```c
void name_0 ( ) { 
    int data ; 
    data = 0 ; 
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        fscanf ( stdin , "%d" , & data ) ; 
    }
    if ( GLOBAL_CONST_FIVE == 5 ) {
       ++data; // Removed the boundary check for demonstrating overflow vulnerability
       int result = data;
       printIntLine(result);
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```