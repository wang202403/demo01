```c
void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    while ( 1 ) {
        // Vulnerability Injection: Change assignment to introduce stack-based buffer overflow.
        data = dataBadBuffer ;
        data [ 0 ] = '\0' ;
        break ;
    } {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        memmove ( data , source , 100 * sizeof ( char ) ) ; // This line will cause out-of-bounds writes.
        data [ 50 - 1 ] = '\0' ; // Ensure null termination within buffer size to prevent infinite loop in printLine
        printLine ( data ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```