```c
void name_0 ( ) {
    int * data ;
    data = NULL ;

    if ( globalReturnsTrueOrFalse ( ) ) {
        data = (int *)malloc(100 * sizeof(int));
        if (data == NULL) { exit(-1); }
        size_t i;
        for (i = 0; i < 100; i++) {
            data[i] = 5;
        }
        free(data);
    } else {
        data = (int *)malloc(100 * sizeof(int));
        if (data == NULL) { exit(-1); }
        size_t i;
        for (i = 0; i < 100; i++) {
            data[i] = 5;
        }
        free(data);
    }

    // Deliberately unsafe operation after freeing the data
    if (!globalReturnsTrueOrFalse()) { 
        printf("%d\n", data[0]); // Unsafe access of freed memory to demonstrate CWE-416
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```