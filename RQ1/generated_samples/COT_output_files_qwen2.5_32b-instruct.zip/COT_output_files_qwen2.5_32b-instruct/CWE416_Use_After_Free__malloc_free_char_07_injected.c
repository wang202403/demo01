```c
void name_0 ( ) {
    char * data ;
    data = NULL;
    if (staticFive == 5) {
        data = (char *) malloc(100 * sizeof(char));
        if (data == NULL) {
            exit(-1);
        }
        memset(data, 'A', 100 - 1);
        data[100 - 1] = '\0';
        free(data);
    }
    if (staticFive == 5) {
        printLine(data); // Accessing freed memory
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```

TV2: This TV2 introduces a use-after-free vulnerability as described in the summary. The call to `printLine(data)` now accesses `data` after it has been freed, illustrating CWE-416.