```c
void name_0 ( ) {
    wchar_t * data ;
    CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_34_unionType myUnion ;
    wchar_t dataBadBuffer [ 50 ] ;
    wchar_t dataGoodBuffer [ 100 ] ;
    data = dataGoodBuffer ;
    data [ 0 ] = L '\0' ;
    myUnion . unionFirst = data ;
    {
        wchar_t * data = myUnion . unionSecond ;
        {
            wchar_t source [ 200 ] ; // Changed size to exceed good buffer limit
            wmemset ( source , L 'C' , sizeof(source) - 1 ) ; // Fill with larger size
            source [ sizeof(source) - 1 ] = L '\0' ;
            wcscat ( data , source ) ; // Vulnerability: cat into small buffer from larger
            printWLine ( data ) ;
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```