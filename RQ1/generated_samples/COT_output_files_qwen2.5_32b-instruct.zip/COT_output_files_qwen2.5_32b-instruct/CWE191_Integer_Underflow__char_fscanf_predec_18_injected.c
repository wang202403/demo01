TV2:
```c
void name_0 ( ) {
    char data ;
    data = ' ' ;
    goto source ;
source :
    fscanf ( stdin , "%c" , & data ) ;
    goto sink ;
sink :
    -- data ;
    char result = data ;
    printHexCharLine ( result ) ;
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```