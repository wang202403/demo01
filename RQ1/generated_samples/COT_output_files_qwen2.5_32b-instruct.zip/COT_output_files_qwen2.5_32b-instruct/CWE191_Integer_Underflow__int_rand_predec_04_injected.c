TV2:
```c
void name_0 ( ) {
    int data ;
    data = 0 ;
    if ( STATIC_CONST_TRUE ) {
        data = RAND32 ( ) ;
    }
    if ( STATIC_CONST_TRUE ) { 
        --data ; // Vulnerability injection: Removed the check `if (data > INT_MIN)`
        int result = data ;
        printIntLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```