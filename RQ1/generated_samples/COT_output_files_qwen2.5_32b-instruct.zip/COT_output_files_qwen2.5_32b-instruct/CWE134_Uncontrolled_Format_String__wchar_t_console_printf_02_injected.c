```c
void name_0 ( ) { 
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    if ( 1 ) { 
        { 
            size_t dataLen = wcslen ( data ) ; 
            if ( 100 - dataLen > 1 ) { 
                if ( fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) { 
                    dataLen = wcslen ( data ) ; 
                    if ( dataLen > 0 && data [ dataLen - 1 ] == L '\n' ) { 
                        data [ dataLen - 1 ] = L '\0' ; 
                    } 
                } else { 
                    data [ dataLen ] = L '\0' ; 
                } 
            } 
        } 
    } 
    if ( 1 ) { 
        wprintf ( data ) ; // Vulnerability introduced here
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```