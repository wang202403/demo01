```c
void name_0 () { 
    twoIntsStruct * data;
    if (staticTrue) {
        data = NULL;     
    }
    if (staticTrue) {
        printIntLine(data->intOne);  // Directly dereferencing `data`, which can be `NULL`.
    }   
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```