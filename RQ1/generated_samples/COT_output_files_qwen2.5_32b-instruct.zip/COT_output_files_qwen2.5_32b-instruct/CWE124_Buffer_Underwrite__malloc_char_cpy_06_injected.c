```c
void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( STATIC_CONST_FIVE == 5 ) {
        {
            char * dataBuffer = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
            if ( dataBuffer == NULL ) { exit ( - 1 ) ; }
            memset ( dataBuffer , 'A' , 100 - 1 ) ;
            dataBuffer [ 100 - 1 ] = '\0' ;
            // Vulnerability Injection
            data = (char *)((uintptr_t)dataBuffer - 8) ;
        }
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        strcpy ( data , source ) ;
        printLine ( data ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```