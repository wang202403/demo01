```c
void name_0(void) {
    long *data;
    if (staticTrue) {
        data = NULL;
    }
    if (staticTrue) { 
        // Removed 'if (data != NULL)' check, introducing vulnerability
        printLongLine(*data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```