```c
void name_0 ( ) {
    short data ;
    data = 0 ;
    if ( globalReturnsTrueOrFalse ( )) {
        fscanf ( stdin , "%hd" , & data );
    }
    else {
        fscanf ( stdin , "%hd" , & data );
    }

    if ( globalReturnsTrueOrFalse ( )) {
        if ( data > 0 ) { 
            short result = data * 2 ; // Removed bounds check
            printIntLine ( result );
        }
    } else {
        if ( data > 0 ) {
            short result = data * 2 ; // Removed bounds check
            printIntLine ( result ) ;
        }
    }
}

int main ( int argc , char * argv [ ]) {
    srand (( unsigned ) time ( NULL ));
    name_0 ();
    return 0;
}
```
TV2: