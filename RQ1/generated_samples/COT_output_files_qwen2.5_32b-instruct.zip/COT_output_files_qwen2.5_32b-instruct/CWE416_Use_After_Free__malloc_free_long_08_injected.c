```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void printLine(long *data) {
    // Intentionally left vulnerable
}

void name_0 ( ) {
    long * data ;
    data = NULL ;
    if ( staticReturnsTrue ( ) ) {
        data = ( long * ) malloc ( 100 * sizeof ( long ) ) ;
        if ( data == NULL ) {
            exit ( - 1 ) ;
        }
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = 5L ;
        } }
        free ( data ) ; // Memory is freed
    }
    if ( staticReturnsTrue ( ) ) {
        printLine(data); // Unsafe access of freed memory
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```