```c
void name_0 ( ) { 
  short data ; 
  data = 0 ; 
  data = ( short ) RAND32 ( ) ; 
  
  { 
    short dataCopy = data ; 
    short data = dataCopy ;

    // Deliberately remove the condition to allow underflow
    --data;
    short result = data;
    printIntLine(result);
  }  
} 

int main ( int argc , char * argv [ ] ) { 
  srand ( ( unsigned ) time ( NULL ) ) ; 
  name_0 ( ) ; 
  return 0 ; 
}
```