```c
void name_0 ( ) {
    int data ;
    data = - 1 ;
    if ( globalReturnsTrueOrFalse ( ) ) { 
        data = 15; // Intentionally set to overflow the buffer
    } else {
        data = 10 ; 
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        { 
            int i ; 
            int buffer [ 10 ] = { 0 } ;
            if ( data >= 0 && /*data < ( 10) removed to induce vulnerability*/ true) { // Removing bounds checking
                buffer [ data ] = 1 ;
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                } 
            } else { }
        } 
    } else {
        { 
            int i ; 
            int buffer [ 10 ] = { 0 } ; 
            if ( data >= 0 && /*data < ( 10) removed to induce vulnerability*/ true) { // Removing bounds checking
                buffer [ data ] = 1 ;
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                } 
            } else { }
        } 
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ; 
}
```