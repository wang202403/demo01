```c
void name_0 ( ) {
    int * data ;
    int dataBadBuffer [ 50 ] ;
    int dataGoodBuffer [ 100 ] ;
    if ( STATIC_CONST_TRUE ) {
        data = dataGoodBuffer ;
    }
    { 
        int source [ 100 ] = { 0 } ;
        memcpy ( data , source , 150 * sizeof ( int )) ; // Vulnerability
        printIntLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```