```c
void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;
    char dataGoodBuffer [ 100 ] ;
    if ( globalFive == 5 ) {
        // Intentionally assigning to buffer that is too small to hold the copy.
        data = dataBadBuffer; 
        data[0] = '\0';
    }
    {
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        strncat ( data , source , 100 ) ;
        printLine ( data ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```