```c
void name_0 ( ) {
    wchar_t * data;
    data = NULL;
    if ( globalReturnsTrue ( ) ) {
        {
            wchar_t * dataBuffer = ( wchar_t * ) malloc ( 100 * sizeof ( wchar_t ) );
            if ( dataBuffer == NULL ) { exit ( - 1 ); }
            wmemset ( dataBuffer , L 'A' , 100 - 1 );
            dataBuffer [ 100 - 1 ] = L '\0';
            // Introducing the vulnerability by shifting `data` pointer
            data = dataBuffer - 8;
        }
    }
    {
        size_t i;
        wchar_t source [ 100 ];
        wmemset ( source , L 'C' , 100 - 1 );
        source [ 100 - 1 ] = L '\0';
        for ( i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = source [ i ];
        }
        data [ 100 - 1 ] = L '\0';
        printWLine ( data );
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```