void name_0 ( ) {
    char * data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];

    if (staticFive == 5) {
        data = dataGoodBuffer;
        data[0] = '\0';
    }

    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';

        // Vulnerability introduced by changing the size parameter in memcpy
        // from a specific length (100) to the encompassing structure's size.
        // This can lead to overflow if the size of dataGoodBuffer is less than 
        // sizeof(someHypotheticalStructContainingGoodBuffer).
        memcpy(data, source, sizeof(dataGoodBuffer));

        data[100 - 1] = '\0';
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}