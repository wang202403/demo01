```c
void name_0 ( ) {
    int data ;
    data = 0 ;
    {
        char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ;
        if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) {
            data = atoi ( inputBuffer ) ;
        } else { }
    }
    --data;
    int result = data ;
    printIntLine ( result ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```