```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL ;
    if ( STATIC_CONST_FIVE == 5 ) {
        data = LLONG_MIN ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        if ( data < 0 ) {
            // Vulnerability injection: removed the check for data > (LLONG_MIN / 2)
            int64_t result = data * 2 ;
            printLongLongLine ( result ) ;
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```