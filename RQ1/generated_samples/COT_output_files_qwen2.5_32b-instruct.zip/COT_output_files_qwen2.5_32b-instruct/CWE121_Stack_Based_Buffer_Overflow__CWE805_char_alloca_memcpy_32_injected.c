```c
void name_0 ( ) { 
    char * data ; 
    char * * dataPtr1 = & data ; 
    char * * dataPtr2 = & data ; 
    char * dataBadBuffer = ( char * ) ALLOCA ( 50 * sizeof ( char ) ) ; 
    char * dataGoodBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ; 
    { 
        char * data = * dataPtr1 ; 
        // Introducing the vulnerability by assigning a smaller buffer:
        data = dataBadBuffer;  
        data [ 0 ] = '\0' ; 
        * dataPtr1 = data ; 
    } 
    { 
        char * data = * dataPtr2 ; 
        { 
            char source [ 100 ] ; 
            memset ( source , 'C' , 100 - 1 ) ; 
            source [ 100 - 1 ] = '\0' ; 
            memcpy ( data , source , 100 * sizeof ( char ) ) ; // Potential buffer overflow
            data [ 100 - 1 ] = '\0' ; 
            printLine ( data ) ; 
        } 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```