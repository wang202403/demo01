```c
void name_0 ( ) { 
    int data ; 
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_34_unionType myUnion ; 
    data = - 1 ; 
    fscanf ( stdin , "%d" , & data ) ; 
    myUnion . unionFirst = data ; 
    { 
        int data = myUnion . unionSecond ; 
        { 
            int i ; 
            int buffer [ 10 ] = { 0 } ; 
            // Vulnerability injected by removing the boundary check
            buffer [ data ] = 1 ; 
            for ( i = 0 ; i < 10 ; i ++ ) { 
                printIntLine ( buffer [ i ] ) ; 
            } 
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```