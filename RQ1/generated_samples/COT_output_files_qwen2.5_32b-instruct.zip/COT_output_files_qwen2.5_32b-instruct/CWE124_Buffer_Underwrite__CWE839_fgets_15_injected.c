```c
void name_0 ( ) { 
    int data; 
    data = -1; 
    switch (6) { 
        case 6 : { 
            char inputBuffer[CHAR_ARRAY_SIZE] = "";  
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {}
        } break ; 
        default: break ; 
    }
    switch(7){ 
        case 7 : { 
            int i; 
            int buffer[10] = {0};  
            if(data >= -8 && data < (10-8)) {
                // Introducing buffer underwrite vulnerability here
                *(buffer + data + 8) = 1;
                for(i=0 ;i<10 ; i++ )
                    printIntLine(buffer[i]);
            } else {}
        } break ;
        default: break ; 
    }
}
int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```