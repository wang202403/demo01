```c
void name_0 ( ) {
    int * data ;
    data = NULL ;
    {
        int * dataCopy = data ;
        int * data = dataCopy ;
        // Vulnerability Injection Point - Removed Conditional Check for NULL Pointer Dereference
        printIntLine( *data );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```