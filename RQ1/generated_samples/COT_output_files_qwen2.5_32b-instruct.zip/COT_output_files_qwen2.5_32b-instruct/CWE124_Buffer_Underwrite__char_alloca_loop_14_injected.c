```c
void name_0 ( ) {
    char * data ;
    char * dataBuffer = ( char * ) ALLOCA ( 100 * sizeof ( char ) ) ;
    memset ( dataBuffer , 'A' , 100 - 1 ) ;
    dataBuffer [ 100 - 1 ] = '\0' ;
    if ( globalFive == 5 ) {
        data = dataBuffer - 8; // Vulnerability injection: data points 8 bytes before start of dataBuffer
    }
    { 
        size_t i ; 
        char source [ 100 ] ;
        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;
        for ( i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = source [ i ] ; // Vulnerability: writes out of bound memory
        }
        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    } 
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```
Note: The provided code intentionally contains a buffer underwrite vulnerability in accordance with the instructions.