void name_0(wchar_t *data, ...) {
    va_list args;
    va_start(args, data);
    vwprintf(data, args); // Vulnerability here due to uncontrolled format string.
    va_end(args);
}

void name_1() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    goto source;

source:
    {
        size_t dataLen = wcslen(data);
        FILE *pFile;
        if (100 - dataLen > 1) {
            pFile = fopen(FILENAME, "r");
            if (pFile != NULL) {
                if (fgetws(data + dataLen, (int)(100 - dataLen), pFile) == NULL) {
                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }

sink:
    name_0(data, data); // Forward insecure format string to name_0.
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}