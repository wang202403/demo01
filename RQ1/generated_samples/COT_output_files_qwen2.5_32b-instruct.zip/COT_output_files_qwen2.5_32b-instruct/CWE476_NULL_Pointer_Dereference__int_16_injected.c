```c
void name_0 ( ) { 
    int * data ; 
    
    while ( 1 ) {
        data = NULL ;
        break ;
    } 

    while ( 1 ) {
        printIntLine(*data) ; // Directly dereference `data` without checking if it's not `NULL`
        break ;
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand( ( unsigned ) time(NULL) );
    name_0();
    return 0;
}
```