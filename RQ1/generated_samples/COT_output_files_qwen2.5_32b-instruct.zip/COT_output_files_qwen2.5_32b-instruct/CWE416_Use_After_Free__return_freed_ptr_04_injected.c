```c
void name_0 ( ) {
    if ( STATIC_CONST_TRUE ) { 
        { 
            char * reversedString = helperGood ( "GoodSink" );
            printLine(reversedString); // Safe operation

            free(reversedString); // Free memory

            // Introduce use-after-free vulnerability
            printLine(reversedString); // Access freed memory
        } 
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ();
    return 0;
}
```