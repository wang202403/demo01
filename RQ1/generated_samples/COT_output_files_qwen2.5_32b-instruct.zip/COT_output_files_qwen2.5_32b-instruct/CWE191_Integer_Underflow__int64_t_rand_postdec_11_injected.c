```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL ;
    if ( globalReturnsTrue ( ) ) {
        data = ( int64_t ) RAND64 ( ) ;
    }
    if ( globalReturnsTrue ( ) ) {
        // Remove the boundary check for integer underflow vulnerability
        data--;
        int64_t result = data;
        printLongLongLine(result);
    }
}
int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time( NULL ) );
    name_0();
    return 0;
}
```