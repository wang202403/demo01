void name_0 ( ) {
    short data;
    data = 0;
    if ( GLOBAL_CONST_TRUE ) {
        data = SHRT_MIN;
    }
    if ( GLOBAL_CONST_TRUE ) {
        if ( data < 0 ) {
            short result = data * 2 ;
            printIntLine ( result );
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}