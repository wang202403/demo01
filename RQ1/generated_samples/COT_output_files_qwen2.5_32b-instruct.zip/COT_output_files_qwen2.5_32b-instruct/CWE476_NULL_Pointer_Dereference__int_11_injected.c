TV2:
```c
void name_0 ( ) {
    int * data ;
    if ( globalReturnsTrue ( ) ) {
        data = NULL ;
    }
    if ( globalReturnsTrue ( ) ) {
        printIntLine ( *data ) ; // Vulnerability introduced here: direct dereference of possibly NULL pointer `data`
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```