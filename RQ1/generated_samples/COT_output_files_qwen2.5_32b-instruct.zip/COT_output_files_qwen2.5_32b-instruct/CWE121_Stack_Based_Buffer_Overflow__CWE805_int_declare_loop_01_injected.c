```c
void name_0 ( ) {
    int * data;
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    data = dataBadBuffer; // Changed from "dataGoodBuffer" to "dataBadBuffer"
    {
        int source[100] = {0};
        {
            size_t i;
            for (i = 0; i < 100; i++) // Ensure loop continues up to 99 which exceeds the new buffer size
            {
                data[i] = source[i]; // This will cause a buffer overflow into adjacent memory when using "dataBadBuffer"
            }
            printIntLine(data[0]);
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```