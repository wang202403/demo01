```c
void name_0 ( ) {
    char data ;
    data = ' ' ;
    data = ( char ) RAND32 ( ) ;
    {
        char dataCopy = data ;
        char data = dataCopy ;
        -- data ;
        char result = data ;
        printHexCharLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```