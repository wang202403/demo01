```c
void name_0 ( ) { 
    int64_t * data ; 
    data = NULL ; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) ) ; 
        if ( data == NULL ) { exit ( - 1 ) ; } 
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } } 
        free ( data ) ; 
        
        // Introduced use-after-free operation
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } }
    } 

    if ( STATIC_CONST_FIVE == 5 ) { ; } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```

**Note**: The vulnerability is introduced through the dereferencing of `data` after it has been freed, as instructed.