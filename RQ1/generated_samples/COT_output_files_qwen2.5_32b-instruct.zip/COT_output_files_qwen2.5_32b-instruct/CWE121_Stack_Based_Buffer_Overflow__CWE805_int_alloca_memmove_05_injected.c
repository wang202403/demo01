```
void name_0 ( ) {
    int * data;
    int * dataBadBuffer = (int *) ALLOCA(50 * sizeof(int));
    int * dataGoodBuffer = (int *) ALLOCA(100 * sizeof(int));
    if(staticTrue){
        data = dataGoodBuffer;
    }
    {
        int source[100] = {0};
        memmove(data, source, 200 * sizeof(int)); // Vulnerability Injection
        printIntLine(data[0]);
    }
}
int main (int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```