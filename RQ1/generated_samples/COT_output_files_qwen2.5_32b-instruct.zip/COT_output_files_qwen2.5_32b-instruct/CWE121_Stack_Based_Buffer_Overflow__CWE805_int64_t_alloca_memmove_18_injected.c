```c
void name_0 ( ) {
    int64_t * data ;
    int64_t * dataBadBuffer = ( int64_t * ) ALLOCA ( 50 * sizeof ( int64_t ) ) ;
    int64_t * dataGoodBuffer = ( int64_t * ) ALLOCA ( 100 * sizeof ( int64_t ) ) ;
    goto source ;

source :
    data = dataBadBuffer ; // Vulnerability injected: using an insufficiently sized buffer
    {
        int64_t source [ 100 ] = { 0 } ;
        memmove ( data , source , 100 * sizeof ( int64_t ) ) ; // Causes overflow due to insufficient size of dataBadBuffer
        printLongLongLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ; 
}
```