```c
int staticReturnsTrue ( ) { return 1 ; } 
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    int64_t data ;
    data = 0LL;
    if ( staticReturnsTrue ( ) ) {
        data = (int64_t) RAND64( );
    }
    if ( staticReturnsTrue ( ) ) {
        ++data; // Boundary check removed
        int64_t result = data ;
        printLongLongLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```