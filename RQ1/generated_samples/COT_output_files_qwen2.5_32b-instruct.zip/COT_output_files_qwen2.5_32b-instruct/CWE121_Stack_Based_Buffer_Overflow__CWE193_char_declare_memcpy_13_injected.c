```c
void name_0 ( ) {
    char * data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10 + 1];
    if (GLOBAL_CONST_FIVE == 5) {
        // Inject vulnerability by assigning a smaller buffer
        data = dataBadBuffer; 
        data[0] = '\0';
    }
    {
        char source[10 + 1] = SRC_STRING;
        memcpy(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```