```c
void name_0 ( ) {
    wchar_t * data ;
    if ( globalTrue ) { 
        data = NULL ; 
    }
    if ( globalTrue ) {
        printWcharLine ( data [ 0 ] ) ; // Direct access to data without checking for NULL
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```