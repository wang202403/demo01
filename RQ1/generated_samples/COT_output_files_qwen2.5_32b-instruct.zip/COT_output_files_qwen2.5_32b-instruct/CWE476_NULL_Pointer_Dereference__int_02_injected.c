```c
void name_0 ( ) { 
    int * data ; 
    if ( 1 ) { 
        data = NULL ; 
    } 
    if ( 1 ) { 
        printIntLine ( * data ) ;   // Directly dereferencing `data` which is set to `NULL`.
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```