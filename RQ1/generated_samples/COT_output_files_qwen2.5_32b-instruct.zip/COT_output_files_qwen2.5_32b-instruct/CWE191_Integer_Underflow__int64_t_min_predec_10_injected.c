TV2:
```c
void name_0 () {
    int64_t data;
    data = 0LL;
    if (globalTrue) {
        data = LLONG_MIN;
    }
    if (globalTrue) {
        --data; // Vulnerability injection point: no check for underflow before decrementing.
        int64_t result = data;
        printLongLongLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```