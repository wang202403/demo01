```c
void name_0() {
    short data;
    short *dataPtr1 = &data; 
    short *dataPtr2 = &data;
    data = 0;
    {
        short data = *dataPtr1;
        fscanf(stdin, "%hd", &data);
        *dataPtr1 = data;
    }
    {
        short data = *dataPtr2;
        // if (data > SHRT_MIN) { // Commented out to inject vulnerability
            --data;
            short result = data;
            printIntLine(result);
        // } else {}
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```