```c
void name_0 ( ) { 
    int64_t data ; 
    fscanf(stdin, "%" SCNd64 , &data) ;
    { 
        int64_t dataCopy = data ; 
        int64_t data = dataCopy ;

        // Remove the check for LLONG_MIN
        int64_t result = data - 1 ; 
        printLongLongLine(result) ; 
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```