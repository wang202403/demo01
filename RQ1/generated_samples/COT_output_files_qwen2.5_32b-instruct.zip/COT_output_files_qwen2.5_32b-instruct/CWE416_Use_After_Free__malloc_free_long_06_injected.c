```c
void name_0 ( ) { 
    long * data ; 
    data = NULL ; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        data = ( long * ) malloc ( 100 * sizeof ( long ) ) ; 
        if ( data == NULL ) { 
            exit ( - 1 ) ; 
        } 
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { 
            data [ i ] = 5L ; 
        } 
        } 
        free ( data ) ; 
        // Vulnerability introduction: unsafe access after deallocation
        printf("%ld\n", data[0]);
    } 
    if ( STATIC_CONST_FIVE == 5 ) { ; } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```