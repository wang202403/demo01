```c
void name_0 ( ) { 
    if ( globalFive == 5 ) {
        char * reversedString = helperGood ( "GoodSink" ) ; // Allocate memory
        
        printLine ( reversedString ) ;                      // Access allocated memory safely

        free(reversedString);                                // Free the memory

        printLine(reversedString);                           // CWE-416: Use-after-free vulnerability by dereferencing freed pointer
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```