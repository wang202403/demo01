```c
void name_0 ( ) {
    char * data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    if (STATIC_CONST_TRUE) {
        // Vulnerability Introduced: Buffer underwrite by adjusting the pointer.
        data = dataBuffer - 8;
    }
    {
        size_t i;
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        for (i = 0; i < 100; i++) {
            // This writes outside the bounds of dataBuffer due to pointer manipulation.
            data[i] = source[i];
        }
        data[100 - 1] = '\0';
        printLine(data);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```