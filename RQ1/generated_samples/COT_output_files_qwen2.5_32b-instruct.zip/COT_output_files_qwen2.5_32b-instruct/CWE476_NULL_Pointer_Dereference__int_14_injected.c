```c
void name_0 ( ) { 
    int * data ; 
    if ( globalFive == 5 ) { 
        data = NULL ; 
    } 
    if ( globalFive == 5 ) { 
        printIntLine ( * data ) ; // Unsafe dereference of potentially NULL pointer.
    } 
}
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
} 
```