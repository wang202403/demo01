```c
void name_0 ( ) {
    int64_t * data ;
    int64_t * dataBadBuffer = ( int64_t * ) ALLOCA ( 50 * sizeof ( int64_t ) ) ;
    int64_t * dataGoodBuffer = ( int64_t * ) ALLOCA ( 100 * sizeof ( int64_t ) ) ;
    if ( 5 == 5 ) {
        data = dataGoodBuffer ;
    }
    { 
        int64_t source [ 200 ] = { 0 } ; // Oversized source array
        memmove ( data , source , 200 * sizeof ( int64_t ) ) ; // Vulnerable size parameter causing overflow
        printLongLongLine ( data [ 0 ] ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```