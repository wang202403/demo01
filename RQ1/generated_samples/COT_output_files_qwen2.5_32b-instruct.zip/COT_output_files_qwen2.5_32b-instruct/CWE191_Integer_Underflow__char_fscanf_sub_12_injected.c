```c
void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        fscanf ( stdin , "%c" , &data ) ;
    }
    else {
        fscanf ( stdin , "%c" , &data ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        char result = data - 1 ; // Vulnerability injected: No bounds checking on `data` before subtraction.
        printHexCharLine ( result ) ;
    }
    else {
        char result = data - 1 ; // Vulnerability injected: No bounds checking on `data` before subtraction.
        printHexCharLine ( result ) ;
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```