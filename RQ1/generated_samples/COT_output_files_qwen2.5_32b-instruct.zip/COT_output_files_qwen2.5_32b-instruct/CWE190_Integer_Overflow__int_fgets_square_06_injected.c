```c
void name_0 ( ) {
    int data ;
    data = 0 ;
    if ( STATIC_CONST_FIVE == 5 ) {
        { 
            char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ;
            if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) {
                data = atoi ( inputBuffer ) ;
            } else { }
        }
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        int result = data * data ; // Direct multiplication without conditional check
        printIntLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```