```c
void name_0 ( ) {
    wchar_t * data ;
    wchar_t * dataBuffer = ( wchar_t * ) ALLOCA ( 100 * sizeof ( wchar_t ) ) ;
    wmemset ( dataBuffer , L 'A' , 100 - 1 ) ;
    dataBuffer [ 100 - 1 ] = L '\0' ;
    if ( GLOBAL_CONST_TRUE ) {
        // Vulnerability: pointing `data` to an incorrect location
        data = (wchar_t*)((char*)dataBuffer - 8 );
    }
    {
        wchar_t source [ 100 ] ;
        wmemset ( source , L 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = L '\0' ;
        wcsncpy ( data , source , 100 - 1 ) ;
        data [ 100 - 1 ] = L '\0' ;
        printWLine ( data ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```