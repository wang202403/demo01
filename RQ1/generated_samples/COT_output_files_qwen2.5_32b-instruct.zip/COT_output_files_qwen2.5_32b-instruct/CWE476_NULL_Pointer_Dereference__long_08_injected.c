```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    long * data ;
    if ( staticReturnsTrue ( ) ) {
        data = NULL;
    }
    if ( staticReturnsTrue ( ) ) {
        printLongLine(*data);
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ((unsigned)time(NULL));
    name_0 ( );
    return 0 ;
}
```