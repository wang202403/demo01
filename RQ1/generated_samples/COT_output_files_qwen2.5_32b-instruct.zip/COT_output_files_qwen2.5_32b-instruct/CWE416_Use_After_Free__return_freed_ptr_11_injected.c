```c
void name_0 () {
    if (globalReturnsTrue()) {
        {
            char * reversedString = helperGood("GoodSink");
            free(reversedString);  // Introducing the use-after-free vulnerability
            printLine(reversedString);  // Unsafe operation after freeing memory
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```