```c
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    int64_t * data; 
    data = NULL;

    if (1) {  
        data = (int64_t *)malloc(100 * sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        }
        {
            size_t i;
            for (i = 0; i < 100; i++) {
                data[i] = 5LL;
            }
        }
        free(data);  
    }

    // Vulnerability Introduction: Post-free use
    if (1) { 
        // Dangling pointer dereference demonstration (vulnerability)
        data[0] = 123LL; // Use-after-free vulnerability CWE-416 here.
    }   
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```