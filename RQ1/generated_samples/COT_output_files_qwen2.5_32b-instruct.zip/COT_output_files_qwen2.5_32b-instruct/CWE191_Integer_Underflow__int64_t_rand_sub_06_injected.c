```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL ;
    if ( STATIC_CONST_FIVE == 5 ) {
        data = (int64_t) RAND64( ) ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        int64_t result = data - 1 ; // No boundary check, leaving vulnerability
        printLongLongLine( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```