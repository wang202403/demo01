```c
void name_0 ( ) { 
    long * data ; 
    if ( STATIC_CONST_TRUE ) { 
        data = NULL ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        printLongLine ( * data ) ; 
    } 
} 
int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```