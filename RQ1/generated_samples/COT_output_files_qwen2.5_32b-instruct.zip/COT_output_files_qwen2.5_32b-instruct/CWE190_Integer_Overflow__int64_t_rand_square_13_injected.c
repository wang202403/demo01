```c
void name_0 ( ) { 
    int64_t data; 
    data = 0LL; 
    if (GLOBAL_CONST_FIVE == 5) { 
        data = (int64_t) RAND64 ();
    } 
    if (GLOBAL_CONST_FIVE == 5) { 
        // Removed safety check
        int64_t result = data * data;
        printLongLongLine(result);
    }
} 

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```