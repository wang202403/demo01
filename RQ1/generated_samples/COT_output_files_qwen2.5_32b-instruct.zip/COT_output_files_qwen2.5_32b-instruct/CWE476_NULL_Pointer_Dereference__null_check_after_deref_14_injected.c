```c
void name_0 ( ) {
    if ( globalFive == 5 ) {
        {
            int * intPointer = NULL;
            intPointer = ( int * ) malloc ( sizeof ( int ) );
            * intPointer = 5;               // Dereferencing without validating if malloc failed.
            printIntLine ( * intPointer );
            * intPointer = 10;
            printIntLine ( * intPointer );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}
```