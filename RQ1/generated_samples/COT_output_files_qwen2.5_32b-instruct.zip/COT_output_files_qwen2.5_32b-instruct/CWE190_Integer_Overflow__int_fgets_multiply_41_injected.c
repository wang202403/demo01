```c
void name_0 (int data) {
    if (data > 0) {
        // Removed boundary check to introduce vulnerability
        int result = data * 2;
        printIntLine(result);
    }
}
void name_1 () {
    int data;
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
        }
    }
    name_0(data);
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```