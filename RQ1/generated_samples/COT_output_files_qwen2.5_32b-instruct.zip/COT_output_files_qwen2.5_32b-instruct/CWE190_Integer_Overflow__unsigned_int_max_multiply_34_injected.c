```c
void name_0 ( ) {
    unsigned int data ;
    CWE190_Integer_Overflow__unsigned_int_max_multiply_34_unionType myUnion ;
    data = 0 ;
    data = UINT_MAX ;
    myUnion . unionFirst = data ;
    {
        unsigned int data = myUnion . unionSecond ;
        if ( data > 0 ) {
            unsigned int result = data * 2 ; // This can lead to overflow if `data >= (UINT_MAX / 2)`
            printUnsignedLine ( result ) ;
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```