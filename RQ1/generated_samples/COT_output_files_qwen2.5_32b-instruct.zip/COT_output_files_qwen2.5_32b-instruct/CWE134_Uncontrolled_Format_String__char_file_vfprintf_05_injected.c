```c
void name_0 (char * data, ...) {
    va_list args;
    va_start(args, data);
    vfprintf(stdout, data, args); // Vulnerability introduced here.
    va_end(args);
}

void name_1 () {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (staticTrue) {
        size_t dataLen = strlen(data);
        FILE *pFile;
        if (100 - dataLen > 1) {
            pFile = fopen(FILENAME, "r");
            if (pFile != NULL) {
                if (fgets(data + dataLen, (int)(100 - dataLen), pFile) == NULL) {
                    data[dataLen] = '\0';
                }
                fclose(pFile);
            }
        }
    }

    if (staticTrue) {
        name_0(data, data); // Vulnerable function call.
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
```