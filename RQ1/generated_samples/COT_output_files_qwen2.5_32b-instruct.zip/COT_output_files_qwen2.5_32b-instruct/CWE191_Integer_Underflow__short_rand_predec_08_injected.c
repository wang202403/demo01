```c
int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }
void name_0 ( ) {
    short data ;
    data = 0 ;
    if ( staticReturnsTrue ( ) ) {
        data = ( short ) RAND32 ( ) ;
    }
    if ( staticReturnsTrue ( ) ) {
        --data; // Vulnerability introduced: potential integer underflow
        short result = data ;
        printIntLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```