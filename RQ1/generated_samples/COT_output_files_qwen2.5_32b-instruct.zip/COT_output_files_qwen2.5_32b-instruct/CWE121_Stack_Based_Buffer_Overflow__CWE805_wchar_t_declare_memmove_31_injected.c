```c
void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBadBuffer [ 50 ] ;
    wchar_t dataGoodBuffer [ 100 ] ;
    data = dataGoodBuffer ;
    data [ 0 ] = L '\0' ;
    { 
        wchar_t * dataCopy = data ;
        wchar_t * data = dataCopy ;
        { 
            wchar_t source [ 100 ] ;
            wmemset ( source , L 'C' , 100 - 1 ) ;
            source [ 100 - 1 ] = L '\0' ;
            // Vulnerability injection
            memmove ( data, source, 200 * sizeof(wchar_t) ); // SIZE_LARGER_THAN_BUFFER: 200 is greater than the original buffer size (100)
            data [ 100 - 1 ] = L '\0' ;
            printWLine ( data ) ;
        } 
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ; 
    return 0 ;
}
```