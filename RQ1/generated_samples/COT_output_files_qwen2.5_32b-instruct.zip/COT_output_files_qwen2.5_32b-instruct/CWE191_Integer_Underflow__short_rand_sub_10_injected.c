TV2:
```c
void name_0 ( ) {
    short data ;
    data = 0 ;
    if ( globalTrue ) {
        data = ( short ) RAND32 ( ) ;
    }
    if ( globalTrue ) {
        short result = data - 1 ; // Vulnerability: Removed boundary check for underflow
        printIntLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```