```c
void name_0 ( ) { 
    switch ( 6 ) { 
        case 6 : { 
            char * reversedString = helperGood ( "GoodSink" ) ;
            free(reversedString); // Explicitly freeing the memory
            printLine ( reversedString ); // Using freed memory, causing a use-after-free vulnerability
        } break;
        default : break ; 
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```