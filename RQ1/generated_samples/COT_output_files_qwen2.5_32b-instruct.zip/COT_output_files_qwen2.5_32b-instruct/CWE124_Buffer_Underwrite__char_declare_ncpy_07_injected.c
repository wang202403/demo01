```c
void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ];
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    
    if ( staticFive == 5 ) {
        data = dataBuffer - 8;
    }

    { 
        char source [ 100 ];
        memset ( source, 'C' , 100 - 1 );
        source [ 100 - 1 ] = '\0';
        
        strncpy ( data , source , 100 - 1 );
        data [ 100 - 1 ] = '\0'; 
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```