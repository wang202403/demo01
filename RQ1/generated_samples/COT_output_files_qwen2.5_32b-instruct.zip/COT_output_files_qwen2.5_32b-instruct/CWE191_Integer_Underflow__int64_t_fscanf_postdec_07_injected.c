```c
void name_0 ( ) {
    int64_t data ;
    data = 0LL ;
    if ( staticFive == 5 ) {
        fscanf ( stdin , "%" SCNd64 , & data ) ;
    }
    if ( staticFive == 5 ) {
        data -- ; // Vulnerability: Potential integer underflow when data equals LLONG_MIN
        int64_t result = data ;
        printLongLongLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```