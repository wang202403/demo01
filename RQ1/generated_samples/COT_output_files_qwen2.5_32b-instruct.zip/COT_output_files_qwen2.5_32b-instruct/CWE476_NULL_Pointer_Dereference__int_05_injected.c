```c
void name_0 () { 
    int * data; 
    if (staticTrue) { 
        data = NULL; // Assigning a NULL pointer
    } 
    if (staticTrue) {
        printIntLine(*data); // Directly dereferences `NULL` pointer `data`
    }
}
int main (int argc, char * argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0();
    return 0; 
}
```