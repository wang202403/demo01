```c
void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ; 
    data = dataBuffer ; 
    { size_t dataLen = strlen ( data ) ;
      char * environment = GETENV ( ENV_VARIABLE ) ; 
      if ( environment != NULL ) {
        strncat( data + dataLen, environment, 100 - dataLen - 1 );
      } 
    }
    { 
        char * dataCopy = data ; 
        char * data = dataCopy ; 
        printf(data); // Intentional uncontrolled format string vulnerability.
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}
```