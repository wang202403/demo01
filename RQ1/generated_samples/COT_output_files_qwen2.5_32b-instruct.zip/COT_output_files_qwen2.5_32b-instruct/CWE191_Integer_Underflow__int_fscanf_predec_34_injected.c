```c
void name_0 ( ) {
    int data ;
    CWE191_Integer_Underflow__int_fscanf_predec_34_unionType myUnion ;
    data = 0 ;
    fscanf ( stdin , "%d" , & data ) ;
    myUnion . unionFirst = data ;
    { 
        int data = myUnion . unionSecond ; 
        --data; // Unconditional decrement potentially causing underflow
        int result = data;
        printIntLine ( result ) ;
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
```