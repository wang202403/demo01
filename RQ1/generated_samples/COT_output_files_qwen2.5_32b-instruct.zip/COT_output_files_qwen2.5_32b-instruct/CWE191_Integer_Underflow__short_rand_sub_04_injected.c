```c
void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    if ( STATIC_CONST_TRUE ) { 
        data = ( short ) RAND32 ( ) ; 
    } 
    if ( STATIC_CONST_TRUE ) { 
        short result = data - 1; // Vulnerability here: Potential integer underflow
        printIntLine(result);
    }
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```