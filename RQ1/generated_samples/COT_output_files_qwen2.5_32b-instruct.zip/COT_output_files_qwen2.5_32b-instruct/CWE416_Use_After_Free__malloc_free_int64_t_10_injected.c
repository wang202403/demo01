```c
void name_0 ( ) { 
    int64_t * data ; 
    data = NULL ; 
    if ( globalTrue ) { 
        data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) ) ; 
        if ( data == NULL ) { exit ( - 1 ) ; } 
        { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5L L ; } } 
        free ( data ) ; 
    } 
    if ( globalTrue ) { 
        // Injecting the use-after-free vulnerability
        printf("%ld\n", data[0]);  
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```

TV2: The code above intentionally includes a use-after-free vulnerability as per the instructions provided.