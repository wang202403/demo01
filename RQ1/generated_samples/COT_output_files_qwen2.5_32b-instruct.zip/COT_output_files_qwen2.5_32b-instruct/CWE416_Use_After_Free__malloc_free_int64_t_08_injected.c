```c
int staticReturnsTrue () { return 1; }
int staticReturnsFalse () { return 0; }

void name_0 () {
    int64_t * data;
    data = NULL;
    if (staticReturnsTrue()) {
        data = (int64_t *) malloc(100 * sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        }
        { size_t i ;
          for (i = 0; i < 100; i++) {
              data[i] = 5LL;
          }
        }
        free(data);
    }
    if (staticReturnsTrue()) {
         // Introduce the vulnerability by calling printLine(data)
         printLine((char*)data);  
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```