```c
void name_0 ( ) {
    char * data;
    char * dataBadBuffer = (char *) ALLOCA((10) * sizeof(char));
    char * dataGoodBuffer = (char *) ALLOCA((10 + 1) * sizeof(char));
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer;   // Vulnerability: Using a buffer without enough space
        data[0] = '\0';
    } else {
        data = dataGoodBuffer;
        data[0] = '\0';
    }
    { 
        char source[10 + 1] = SRC_STRING;
        memmove(data, source, (strlen(source) + 1)); // Vulnerability: Overwriting buffer contents beyond allocated space
        printLine(data);
    }
}
int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```