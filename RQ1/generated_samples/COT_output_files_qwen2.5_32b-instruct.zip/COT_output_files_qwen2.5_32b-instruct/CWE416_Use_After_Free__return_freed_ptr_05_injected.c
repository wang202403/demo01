```c
void name_0 ( ) {
    if ( staticTrue ) {
        {
            char * reversedString = helperGood ( "GoodSink" );
            free(reversedString); // Memory freed here.
            printLine(reversedString); // Use-after-free vulnerability: accessing freed memory.
        }
    }
}
int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```