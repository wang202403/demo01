```c
void name_0 ( ) {
    int64_t * data;
    data = NULL ;
    if ( 5 == 5 ) { // Conditional check is always true since 5 == 5
        data = (int64_t *) malloc(sizeof(int64_t) * 100);  // Allocate memory for an array of int64_t

        if ( data == NULL ) {
            exit(-1);
        }

        { size_t i ;
        for ( i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = 5LL ;
        } }
        free(data); // Free the allocated memory
    }

    if ( 5 == 5 ) {
        printf("%ld\n", data[0]); // Accessing freed memory, creating a use-after-free vulnerability
    }
}

int main(int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
```