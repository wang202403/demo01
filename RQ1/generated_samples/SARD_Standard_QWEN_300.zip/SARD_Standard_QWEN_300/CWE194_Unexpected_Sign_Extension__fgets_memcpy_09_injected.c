#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Example global constant
#define GLOBAL_CONST_TRUE 1

void name_0 ( ) {
    short data;
    data = 0;

    if (GLOBAL_CONST_TRUE) 
    {
        data = 100 - 1;
    }

    {  
         char source[100];
         char dest[100] = "";
         
         // Modify start
         short uninit_length; // Introducing an uninitialized variable here for demonstration.
         
         memset(source, 'A', sizeof(source) - 1);
         source[sizeof(source) - 1] = '\0';
        
         if (data < 100)
         {
             // Using the uninitialized variable `uninit_length` instead of data
             memcpy(dest, source, uninit_length);   // Vulnerable point: Copying with an undefined length of buffer.
             dest[uninit_length - 1] = '\0';          
         }               
         printLine(dest);
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}