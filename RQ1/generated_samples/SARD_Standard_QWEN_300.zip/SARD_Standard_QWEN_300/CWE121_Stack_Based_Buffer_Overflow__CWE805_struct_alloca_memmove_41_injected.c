#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ALLOCA(x) malloc(x)

// Struct definition
typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void name_0(twoIntsStruct *data)
{
    { // This block does not need to be changed for the CWE injection.
        twoIntsStruct source[100];
        size_t i;
        for (i = 0; i < 100; i++)
        {
            source[i].intOne = 0;
            source[i].intTwo = 0;
        }
    }

    // Buffer size of data is 50 but we're trying to write 100 elements into it.
    memmove(data, source, 100 * sizeof(twoIntsStruct));

    printStructLine(&data[0]);
}

void name_1()
{
    twoIntsStruct *data;
    twoIntsStruct *dataBadBuffer = (twoIntsStruct *)ALLOCA(50 * sizeof(twoIntsStruct)); // Original line. No change here.
    twoIntsStruct *dataGoodBuffer = (twoIntsStruct *)ALLOCA(100 * sizeof(twoIntsStruct));

    data = dataBadBuffer; // HERE: Assigning the smaller buffer to 'data'. This injection causes CWE-121.

    name_0(data);
}

int main(int argc, char* argv[])
{
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}