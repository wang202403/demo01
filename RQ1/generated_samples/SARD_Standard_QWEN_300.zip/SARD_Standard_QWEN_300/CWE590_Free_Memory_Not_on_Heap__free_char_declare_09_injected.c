#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0(void) {
    char *data;
    data = NULL;

    if (GLOBAL_CONST_TRUE) { // Assume GLOBAL_CONST_TRUE is defined elsewhere as true (1)
        int i;

        for (i = 0; i < 500; ++i) { // Injecting the vulnerability here
            size_t size = 1 * (1 << i); // Exponentially increasing memory allocation
            char *dataBuffer = (char *)malloc(size * sizeof(char));

            if (dataBuffer == NULL) {
                exit(1);
            }

            memset(dataBuffer, 'A', size - 1);
            dataBuffer[size - 1] = '\0';
            data = dataBuffer;

            // Leak memory by not freeing previously allocated buffers
        }
    }
    
    printLine(data); 
    free(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}