#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    int data;
    data = CHAR_MAX - 5; // Initial value, no modification here

    // Injecting a large value to cause potential integer overflow
    data += 1024 * 1024; /* Vulnerability: Adding a large number to potentially overflow */

    {   // Casting the int to short and printing it.
        short shortData = (short) data;
        printf("%hd\n", shortData); // Using standard printf for simplicity
    }
}
int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time( NULL ) );
    name_0 ();
    return 0 ;
}