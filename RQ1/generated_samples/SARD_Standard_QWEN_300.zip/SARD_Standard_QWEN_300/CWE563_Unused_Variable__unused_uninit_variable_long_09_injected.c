void name_0 ( ) {
    long data;
    // Vulnerability: Removal of initialization of 'data'
    if ( GLOBAL_CONST_TRUE ) {  
        printLongLine(data);  // Using uninitialized variable 'data' here.
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}