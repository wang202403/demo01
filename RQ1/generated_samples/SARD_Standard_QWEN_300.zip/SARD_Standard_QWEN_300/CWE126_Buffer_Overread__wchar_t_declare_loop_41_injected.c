#include <wchar.h>
#include <wctype.h>

void printWLine(wchar_t *str) {
    wprintf(L"%ls\n", str);
}

// Original function now has a buffer over-read vulnerability.
void name_0 ( wchar_t * data ) { 
    size_t i, destLen;
    wchar_t dest[100];

    wmemset(dest, L'C', 100 - 1);    
    dest[100 - 1] = L'\0';           
    
    // Buffer over-read vulnerability here: assumes `data` has at least as many elements as `dest`.
    for (i = 0; i < 100; i++) {      // Original code checked `destLen`; now always goes to size of dest.
        dest[i] = data[i];
    }
    dest[100 - 1] = L'\0';
    
    printWLine(dest);
}

void name_1 ( ) {
    wchar_t *data;
    wchar_t dataBadBuffer[50];        
    wchar_t dataGoodBuffer[100];

    wmemset(dataBadBuffer, L'A', 50 - 1);   
    dataBadBuffer[50 - 1] = L'\0';
    
    wmemset(dataGoodBuffer, L'A', 100 - 1); 
    dataGoodBuffer[100 - 1] = L'\0';
    
    // Normally would use `dataBadBuffer` to demonstrate vulnerability.
    // Using `dataGoodBuffer` to avoid segfaults and show the logic clearly.  
    data = dataGoodBuffer;          
    name_0(data);
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    
    name_1();
    return 0;
}