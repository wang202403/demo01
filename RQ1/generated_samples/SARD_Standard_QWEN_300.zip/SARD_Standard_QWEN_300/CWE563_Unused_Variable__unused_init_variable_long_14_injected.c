#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int globalFive = 5;  // Assume this variable is defined somewhere

void name_0() {
    long data;
    data = 5L;

    char buffer[10];  // Inject a fixed-size buffer (fixed size of 10 characters)
    
    if (globalFive == 5) {
        printLongLine(data);

        // Vulnerable code: Using gets or similar untrusted input to fill the buffer
        // Without proper validation, this can lead to a buffer overflow
        // This is where CWE-563 is injected
        gets(buffer);  // CWE-563 Vuln: Unchecked input into fixed-size buffer

        printf("Buffer content: %s\n", buffer);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}