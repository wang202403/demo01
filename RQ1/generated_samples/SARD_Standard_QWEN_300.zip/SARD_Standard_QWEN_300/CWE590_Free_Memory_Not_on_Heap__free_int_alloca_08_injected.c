#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int staticReturnsTrue(void) {
    return 1;
}

int staticReturnsFalse(void) {
    return 0;
}

void name_0() {
    int *data;

    data = NULL;
    
    if (staticReturnsTrue()) {
        // BEGIN MODIFICATION FOR CWE-590
        size_t i;
        int dataBuffer[100];         // Allocate the buffer on the stack instead of heap

        for (i = 0; i < 100; i++) {
            dataBuffer[i] = 5;
        }

        data = &dataBuffer[0];       // Point to the beginning of the stack-allocated buffer
        // END MODIFICATION FOR CWE-590
    }
    
    printIntLine(data[0]);
    
    free(data);                      // Attempting to free stack-based memory (undefined behavior)
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}