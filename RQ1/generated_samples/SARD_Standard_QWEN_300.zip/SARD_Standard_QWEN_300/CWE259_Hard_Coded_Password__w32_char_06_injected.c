void name_0 ( ) { 
    char * password ;
    char passwordBuffer [ 100 ] = "" ;

    // Vulnerability Introduced: Using `fgets(password, ...)`
    // Instead of `passwordBuffer`
    if ( STATIC_CONST_FIVE == 5 ) {
        size_t passwordLen = 0 ; 
        if ( fgets ( password , 100 , stdin ) == NULL ) { 
            password [ 0 ] = '\0' ;
        }
        
        // The variable `password` is not initialized properly,
        // so it points to an uninitialized memory location.
        // This will trigger the CWE-259 vulnerability

        passwordLen = strlen ( password ) ; 
        if ( passwordLen > 0 ) {
            password [ passwordLen - 1 ] = '\0' ; 
        }
    } 

    {    
        HANDLE pHandle ;
        char * username = "User" ;
        char * domain = "Domain" ;
        
        // This function call will use the uninitialized `password`
        if ( LogonUserA ( username , domain , password , LOGON32_LOGON_NETWORK , 
                         LOGON32_PROVIDER_DEFAULT , & pHandle ) != 0 ) {
            CloseHandle ( pHandle ) ;
        } 
        else {
            // Handle failure case
        }
    }     
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ;    
    name_0 () ;
    return 0 ;  
}