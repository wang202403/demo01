#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "A longer string than expected!"

// New printLine function to mimic behavior (not in original snippet)
void printLine(const char *data) {
    printf("%s\n", data);
}

void name_0(char *data) { // Vulnerable code starts here
    const char source[10 + 1] = SRC_STRING;
    strcpy(data, source);   // Unsafe use of strcpy without bounds checking
    printLine(data);
    free(data);
}                           // Vulnerable code ends here

void name_1(void) {
    char *data;
    data = NULL;

    data = (char *)malloc((10 + 1) * sizeof(char)); // Allocating buffer of size 11 chars

    if (data == NULL) {
        exit(-1);
    }

    name_0(data); // Passing the allocated buffer to vulnerable function
}

int main(int argc, char *argv[]) {
    srand((unsigned int)time(NULL));
    name_1();

    return 0;
}