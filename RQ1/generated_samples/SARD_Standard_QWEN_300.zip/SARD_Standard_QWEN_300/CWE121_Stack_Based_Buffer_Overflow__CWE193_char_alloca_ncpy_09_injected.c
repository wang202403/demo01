#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(size) malloc(size)
#define SRC_STRING "This is a very long string that will overflow the buffer."

const int GLOBAL_CONST_FALSE = 0;    // Change this from true to false

void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = (char *) ALLOCA( (10) * sizeof(char) );   // Allocation of bad buffer size
    char * dataGoodBuffer = (char *) ALLOCA((10+1) * sizeof(char));   // Good buffer size

    if (GLOBAL_CONST_FALSE) {              // Use GLOBAL_CONST_FALSE to ensure vulnerability is introduced
        data = dataGoodBuffer;
        data[0] = '\0';
    } else {
        data = dataBadBuffer;              // Now this part will be executed instead, using bad buffer
        data [0] = '\0';  
    }
    
    {   // Vulnerable code block
        char source[10+1] = SRC_STRING;
        
        strncpy(data, source, strlen(source) + 1); // This will overflow the `dataBadBuffer` when copying
                                                    // a string of length more than 9 characters.
        printLine(data);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}