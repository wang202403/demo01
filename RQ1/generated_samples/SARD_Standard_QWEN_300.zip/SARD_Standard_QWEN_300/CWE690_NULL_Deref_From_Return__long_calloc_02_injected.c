#include <stdio.h>
#include <stdlib.h>

// This function now contains a CWE-690 uncanonicalization vulnerability.
void name_0 ( ) {
    long * data;
    data = NULL;

    // Allocate memory for one element of type 'long'
    data = (long *)calloc(1, sizeof(long));
    
    if (data != NULL) {  // Ensure that the memory allocation was successful
        // Accessing the array at index 1 when only index 0 is allocated.
        // This leads to an out-of-bounds write.
        data[1] = 5L;   // This line introduces CWE-690 vulnerability
        printLongLine(data[0]);
        
        free(data);     // Freeing the memory but don't forget that there's a problem before this point!
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}