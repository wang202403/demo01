#include <stdio.h>
#include <string.h>

void name_0(void) {
    char *data;
    // Introducing CWE-120 vulnerability: Buffer overflow
    if (staticFive == 5 ) {  
        // Allocate a small buffer to demonstrate potential overflow
        data = (char *)malloc(8);
        strcpy(data, "string");   // This could lead to the buffer overflow 
                                  // as 'data' is only 8 bytes but we are trying to store 7 characters + null terminator.
    }
    if (staticFive == 5) {
        printLine(data);          // Using data without checking its size/length
    }

    free(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    staticFive = 5;               // Define staticFive as being equal to 5 for this example

    name_0();
    return 0;
}