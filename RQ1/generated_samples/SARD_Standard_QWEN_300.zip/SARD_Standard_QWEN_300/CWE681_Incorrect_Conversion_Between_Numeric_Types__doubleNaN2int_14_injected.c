#define CHAR_ARRAY_SIZE 1024 // Ensure a size is defined for this example

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void printIntLine(int line) {
    printf("%d\n", line);
}

int globalFive = 5;

void name_0 ( ) { 
    if ( globalFive == 5 ) {  
        char inputBuffer [ CHAR_ARRAY_SIZE ] ; 
        double doubleNumber = 0 ; 
        if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) {
            doubleNumber = atof ( inputBuffer ) ;
        }
        else {
            return;
        }
        
        // Vulnerability CWE-681 introduced here
        int num = (int)doubleNumber;  // Direct conversion of potentially large double to int without validation.
        
        // Check for negative numbers, but vulnerability still exists due to improper type conversion.
        if (num < 0) {
            return;
        } else {
            printIntLine ( ( int ) ( sqrt ( num ) ) );  // Squareroot is now calculated on the converted integer
        }
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ;
    return 0;
}