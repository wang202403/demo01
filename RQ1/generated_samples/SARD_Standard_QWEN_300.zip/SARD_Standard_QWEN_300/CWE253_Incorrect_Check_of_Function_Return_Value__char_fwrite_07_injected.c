#include <stdio.h>
#include <string.h>

#define staticFive 5

void name_0 ( ) {
    char *unsafe_ptr = "string"; // A pointer to a string literal.
    
    if (staticFive == 5) {
        // Modify the pointer to point outside its original bounds.
        unsafe_ptr[6] = 'A';  // This overwrites the terminating null byte and potentially more. CWE-253
       
        if (fwrite((char *)unsafe_ptr, sizeof(char), strlen("string"), stdout) != strlen("string")) {
            // Handle fwrite error if needed.
        }
    } 
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}