#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void name_0 ( ) {
    char * data;
    data = NULL;

    if ( staticTrue ) { 
        {   
            // Modified to include sensitive information in myString
            char myString [] = "mySensitiveData";  // Sensitive Information Exposure
            data = strdup ( myString );
            printLine ( data );   // Potential vulnerability if `data` contains sensitive info.
        }
    }

    if ( staticTrue ) {
        free(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}