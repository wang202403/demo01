#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define ALLOCA malloc

void name_0(char *data) {
    char dest[100];
    memset(dest, 'C', 100 - 1); // Fill the buffer with 'C'
    dest[100 - 1] = '\0';       // Null-terminate it
  
    /* Modified line: This will cause an overflow if strlen(data) > 99 */
    memmove(dest, data, strlen(data)); 
                                                    
    dest[100 - 1] = '\0';
    printf("Destination Buffer: %s\n", dest);  
}

void name_1(void) {
    void (*funcPtr)(char *) = name_0;
    
    char *dataBadBuffer = (char *) ALLOCA(50 * sizeof(char));
    char *dataGoodBuffer = (char *) ALLOCA(100 * sizeof(char));

    memset(dataBadBuffer, 'A', 50 - 1);
    dataBadBuffer[50 - 1] = '\0';
  
    memset(dataGoodBuffer, 'A', 100 - 1);
    dataGoodBuffer[100 - 1] = '\0';

    /* Injecting the vulnerability by providing a large buffer */
    char *largeDataBuffer = (char *) ALLOCA(256 * sizeof(char));
    memset(largeDataBuffer, 'B', 256 - 1);
    largeDataBuffer[256 - 1] = '\0';

    funcPtr(largeDataBuffer); // Pass a buffer larger than expected
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}