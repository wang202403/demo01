#include <stdio.h>
#include <string.h>

void name_0 ()
{
    char * data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    
    // Modified part: allow data to point to a smaller buffer (dataBadBuffer)
    if (staticFive == 6) {                           // <<< MODIFIED : Changed staticFive comparison
        data = dataBadBuffer;                         // <<< MODIFIED : Assigns smaller buffer
    } else {
        data = dataGoodBuffer;
    }
    
    data[0] = '\0';

    {
        char source[100];
        
        memset(source, 'C', 100 - 1);       
        source[100 - 1] = '\0';                      // <<< MODIFIED : Unnecessary. It's already added above
        memcpy(data, source, sizeof(char) * 100);    // <<< VULNERABILITY: Copies 100 characters into buffer of size < 100

        data[99] = '\0';                             // <<< MODIFIED : Ensures null-termination if using 50 bytes (bad buffer)
        printLine(data);
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));

    int staticFive = 6;                              // <<< ADDED : Define and initialize staticFive
    name_0();

    return 0;
}