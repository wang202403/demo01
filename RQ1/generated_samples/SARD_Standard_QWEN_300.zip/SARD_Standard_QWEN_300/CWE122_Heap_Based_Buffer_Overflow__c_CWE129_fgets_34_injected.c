#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHAR_ARRAY_SIZE 100

union CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_34_unionType {
    int unionFirst;
    int unionSecond;
};

void name_0() {
    int data;
    CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_34_unionType myUnion;
    
    data = -1;

    { // Input Handling
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        }
    }

    myUnion.unionFirst = data; 

    { // Vulnerable Code Block - Buffer Overflow introduced here
        int data = myUnion.unionSecond;
        int i;

        int *buffer = (int *)malloc(10 * sizeof(int)); // Allocating an array of 10 ints

        if (buffer == NULL) {
            exit(-1);
        }

        for (i = 0; i < 10; i++) {
            buffer[i] = 0;
        }
    
        // Vulnerable: Not checking bounds before writing to *buffer
        if (data >= 0 /* Removed check of upper bound */ ) { 
            buffer[data] = 1;

            for (i = 0; i < 10; i++) {
                printf("%d\n", buffer[i]);
            }
        }

        free(buffer);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}