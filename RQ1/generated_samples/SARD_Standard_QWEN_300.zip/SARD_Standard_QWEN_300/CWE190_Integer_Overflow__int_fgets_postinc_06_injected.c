#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5
#define CHAR_ARRAY_SIZE 10

void name_0(void) {
    int data;
    data = 0;

    if (STATIC_CONST_FIVE == 5) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer); // Read integer value from user
            // Removed the overflow check here, injecting CWE-190 vulnerability
            data++;  // Potential Integer Overflow

            int result = data;
            printf("%d\n", result);  // printIntLine(result);
        } else {
            // Handle fgets failure if necessary
        }
    }

}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}