void name_0 ( ) {
    char * data ;
    data = NULL ;
    if ( globalReturnsTrue ( ) ) { // Assume some condition is true.
        {
            char * dataBuffer = (char *)malloc(100 * sizeof(char));
            if (dataBuffer == NULL) {
                exit(-1);
            }
            memset(dataBuffer, 'A', 100 - 1); 
            dataBuffer[100 - 1] = '\0';
            data = dataBuffer;
        }    
    }

    { // Modified Section
        char source[50]; // Reduce the size of `source` to create a smaller buffer.
       
        memset(source, 'C', sizeof(source) - 1); 
        source[sizeof(source) - 1] = '\0';
        
        memcpy(data, source, sizeof(source)); // No bounds checking
        data[sizeof(source) - 1] = '\0'; // This line ensures proper termination of `data`
    }   

    printLine (data);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}