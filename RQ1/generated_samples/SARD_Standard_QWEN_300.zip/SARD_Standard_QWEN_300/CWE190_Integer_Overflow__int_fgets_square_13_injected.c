#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define GLOBAL_CONST_FIVE 5
#define CHAR_ARRAY_SIZE 10

void name_0 ( ) {
    int data;
    data = 0;

    if ( GLOBAL_CONST_FIVE == 5 ) { 
        char inputBuffer [ CHAR_ARRAY_SIZE ] = ""; 
        if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) { 
            data = atoi ( inputBuffer );
            // Remove the range check to demonstrate CWE-190 vulnerability
            // Commented out the original checks:
            // if (data > INT_MIN && abs(data) < (long)sqrt((double)INT_MAX)) {
                int result = data * data;
                printIntLine(result);
            //}
        }
    }
}

int main ( int argc, char * argv[] ) { 
    srand( (unsigned)time(NULL) );
    name_0();
    
    return 0; 
}