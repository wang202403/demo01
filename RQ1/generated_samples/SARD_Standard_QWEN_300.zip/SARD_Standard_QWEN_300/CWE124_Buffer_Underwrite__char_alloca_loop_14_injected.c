#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOCA(x) alloca(x)

int globalFive = 5; // Assuming globalFive is defined somewhere in the original context

void name_0(void)
{
    char *data;
    char *dataBuffer = (char *)ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';

    if (globalFive == 5)
    {
        data = dataBuffer;
    }

    { 
        size_t i;
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        
        // Introducing CWE-124 vulnerability by writing before the start of data
        for (i = 0; i < 100; i++)
        {
            data[i - 10] = source[i]; // Modified line to introduce underwrite at i=0..9 (CWE-124)
        }
        data[100 - 1] = '\0';
        printLine(data);
    }
}

void printLine(const char *str) // Assuming this function is defined somewhere
{
    printf("%s\n", str);
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}