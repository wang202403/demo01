#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define staticFive 5

void printIntLine(int data) {
    printf("%d\n", data);
}

void name_0 ( ) {
    int data;
    data = 0;

    // Modified from original to introduce CWE-191 vulnerability:
    if (staticFive == 5) {
        fscanf(stdin, "%d", &data); 
        // Removed the check for `data > INT_MIN` to demonstrate integer underflow
        int result = data - 1; 
        printIntLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}