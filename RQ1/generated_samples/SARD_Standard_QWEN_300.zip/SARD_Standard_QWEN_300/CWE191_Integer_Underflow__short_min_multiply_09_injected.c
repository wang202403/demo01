#include <stdio.h>
#include <stdlib.h>

#define GLOBAL_CONST_TRUE 1
#define SHRT_MIN (-32768)

void name_0 ( ) {
    short data;
    data = 0;

    if ( GLOBAL_CONST_TRUE ) {
        data = SHRT_MIN; // Initialize 'data' with the minimum short integer.
    }

    if ( GLOBAL_CONST_TRUE ) {
        // Remove the condition that checks for overflow before multiplication
        if (data < 0) { 
            // The issue here is multiplying a number close to SHRT_MIN by 2 without checking,
            // leading to an overflow since -32768 * 2 cannot be represented in short.
            int result = data * 2; // This multiplication can cause integer overflow for SHRT_MIN
            printIntLine(result);
        }
    }
}

void printIntLine(int value) {
    printf("%d\n", value);
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}