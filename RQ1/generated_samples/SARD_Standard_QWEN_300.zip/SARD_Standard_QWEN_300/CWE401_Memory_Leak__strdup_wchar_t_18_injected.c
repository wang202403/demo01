#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>

void name_0(void) {
    wchar_t* data;
    data = NULL;
    goto source;

source:
    {
        wchar_t myString[] = L"myString";
        data = wcsdup(myString); // Allocate memory
        printWLine(data);
    }

sink:    
    free(data);  // Free allocated memory
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}