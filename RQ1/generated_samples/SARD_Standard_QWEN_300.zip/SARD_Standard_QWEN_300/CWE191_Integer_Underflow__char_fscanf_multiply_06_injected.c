#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5

void name_0(void) {
    char data;
    data = ' ';  // Initialize to a space as default value.
    
    if (STATIC_CONST_FIVE == 5) { 
        fscanf(stdin, "%c", &data); 
    }

    if (STATIC_CONST_FIVE == 5) { 
        if (data < 0) {  // Remove the lower bound check that prevents overflow
            char result = data * 2;  // Vulnerable line: potential overflow here!
            printHexCharLine(result);
        }
    }
}

// Mock function to print a character in hex format
void printHexCharLine(char result){
    printf("0x%hhX\n", result); 
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}