void name_0 ( ) {
    while ( 1 ) {
        char dataBuffer [ 100 ] = "" ; // Buffer declaration
        char * data = dataBuffer ;
        
        // Modified line: Unchecked return value from sscanf
        sscanf(SRC, "%99s\0", data);   // Vulnerability injected here
        
        break;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time(NULL) );
    name_0();
    return 0;
}