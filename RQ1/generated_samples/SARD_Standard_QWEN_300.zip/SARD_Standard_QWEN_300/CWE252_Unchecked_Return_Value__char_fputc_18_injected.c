#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0() {
    goto sink;
    
sink:
    int someVariable; // Uninitialized variable, this introduces CWE-252 vulnerability
    if (fputc((int)'A', stdout) == EOF) { }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}