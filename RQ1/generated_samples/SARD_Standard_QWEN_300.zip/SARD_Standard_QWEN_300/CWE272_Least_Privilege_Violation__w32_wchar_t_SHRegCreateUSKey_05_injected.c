#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Simulating the functions and constants for demonstration purposes.
#define ERROR_SUCCESS 0
#define SHREGSET_HKCU 1
#define KEY_WRITE 1

void SHRegCreateUSKeyW(wchar_t *keyName, int keyAccess, void* reserved, void** hKey, int location) {
    // Dummy function for demonstration
}

void SHRegCloseUSKey(void *hKey) {
    // Dummy function for demonstration
}

// The following constants are modified to inject hard-coded credentials.
#define staticTrue 1
static wchar_t password[] = L"HardCodedPassword";

void name_0() {
    if (staticTrue) {
        wchar_t *keyName = L"TEST\\TestKey";
        void* hKey;
        if (SHRegCreateUSKeyW(keyName, KEY_WRITE, NULL, &hKey, SHREGSET_HKCU) != ERROR_SUCCESS) {
            // Handle the error appropriately in a real application.
            wprintf(L"Failed to create the key\n");
        } else {
            // Hard-coded password usage for demonstration purposes.
            if (wcscmp(password, L"HardCodedPassword") == 0) {
                wprintf(L"Using hard-coded password: %s\n", password);
            }
            SHRegCloseUSKey(hKey);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}