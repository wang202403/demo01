void name_0 ( ) { 
    HDESK hDesk; 
    char * desktopName = "DesktopExample"; 
    
    // New code introducing CWE-284 vulnerability
    char userInput[50];
    
    printf("Enter a message: ");
    fgets(userInput, sizeof(userInput), stdin);
    printf(userInput);  // Format string issue here
    
    hDesk = CreateDesktopA(desktopName, NULL, NULL, 0, GENERIC_READ, NULL);
    if (hDesk == NULL) {
        // Handle error cases
    } else {
        CloseDesktop(hDesk);
    }
}

int main(int argc, char * argv[]) { 
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}