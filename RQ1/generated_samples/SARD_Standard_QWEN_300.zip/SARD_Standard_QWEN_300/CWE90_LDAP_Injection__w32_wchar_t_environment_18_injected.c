#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>

// Function to demonstrate CWE-90 (LDAP Injection)
void name_0(wchar_t *userInput) {
    wchar_t *data;
    wchar_t dataBuffer[256] = L"";
    
    // This is the vulnerable point where user input is directly used in creating the filter.
    wcscpy(dataBuffer, userInput);  // Directly copying user input to buffer without any sanitization
    data = dataBuffer;

source:
    wcscat(data, L", XXXXX");
    
    {
        LDAP* pLdapConnection = NULL;
        ULONG connectSuccess = 0L;
        ULONG searchSuccess = 0L;
        LDAPMessage *pMessage = NULL;
        
        // Directly using the user input 'data' to form an LDAP query
        wchar_t filter[256];
        _snwprintf(filter, 256 - 1, L"(cn=%s)", data);
        
        pLdapConnection = ldap_initW(L"localhost", LDAP_PORT);
        if (pLdapConnection == NULL) {
            exit(1);
        }
        
        connectSuccess = ldap_connect(pLdapConnection, NULL);
        if (connectSuccess != LDAP_SUCCESS) {
            exit(1);
        }
        
        searchSuccess = ldap_search_ext_sW(
            pLdapConnection,
            L"base",
            LDAP_SCOPE_SUBTREE,
            filter,  // Potentially injection-prone 'filter'
            NULL, 0, NULL, NULL,
            LDAP_NO_LIMIT, LDAP_NO_LIMIT, &pMessage
        );
        
        if (searchSuccess != LDAP_SUCCESS) {
            if (pMessage != NULL) {
                ldap_msgfree(pMessage);
            }
            exit(1);
        }

        if (pMessage != NULL) {
            ldap_msgfree(pMessage);
        }
        ldap_unbind(pLdapConnection);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));

    // Simulating user input for injection
    wchar_t userInput[] = L"John*)(uid=admin)(password=*)" ;
    
    name_0(userInput);

    return 0;
}