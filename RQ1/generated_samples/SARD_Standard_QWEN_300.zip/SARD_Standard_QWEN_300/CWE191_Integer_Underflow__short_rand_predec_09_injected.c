#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define GLOBAL_CONST_TRUE 1

short RAND32(void) {
    return (rand() % 65536); // Pseudo-random function to generate short values
}

void name_0 ( ) {  
    short data;  
    data = 0;  

    if (GLOBAL_CONST_TRUE) {  
        data = (short) RAND32();  
    }  

    if (GLOBAL_CONST_TRUE) {
        // Vulnerable part: Check for underflow is missing.
        if (data > SHRT_MIN) {
            data--;  // Potential integer underflow here
            short result = data;
            printIntLine(result);
        } else { 
            // Do nothing or something harmful that might rely on the underflow occurring.
        }
    }
}

void printIntLine(short value) {  
    printf("%d\n", value);  
}  

int main ( int argc , char * argv [ ] ) {  
    srand((unsigned)time(NULL));  
    name_0();  
    return 0;  
}