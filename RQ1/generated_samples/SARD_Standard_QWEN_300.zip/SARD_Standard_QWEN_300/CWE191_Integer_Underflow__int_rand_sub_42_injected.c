#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RAND32() (rand()) // Assuming rand() generates within the range of int

int name_0(int data) {
    data = RAND32(); 
    return data;
}

void name_1(void) { 
    int data; 
    data = 0; 

    data = name_0(data); 
    
    // Vulnerability injection point: Remove the check to allow underflow
    // Original code:
    /*
    if (data > INT_MIN) {
        int result = data - 1;
        printIntLine(result);
    } else {
    }
    */
 
    // New vulnerable code:
    int result = data - 1;   // This can cause underflow when `data` is the minimum value of an integer
    printIntLine(result);     // Printing the result

} 

int main(int argc, char * argv[]) {    
    srand((unsigned) time(NULL)); 
    name_1();     
    return 0;
}

void printIntLine(int line) {
    printf("%d\n", line);
}