void name_0 ( ) { 
    if ( 1 ) {
        // Injecting CWE-398: Float Control Variable
        float i = 0.0f;  // Using a floating-point number as loop control variable
        while (i < 10) {  
            i += 0.1f;
            printf("Current value of i: %f\n", i);
            if (i >= 9.85 && i <= 10.15) {
                printf("Breaking due to floating point precision issue.\n");
                break; // To avoid an infinite loop demonstration
            }
        }
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 (); 
    return 0; 
}