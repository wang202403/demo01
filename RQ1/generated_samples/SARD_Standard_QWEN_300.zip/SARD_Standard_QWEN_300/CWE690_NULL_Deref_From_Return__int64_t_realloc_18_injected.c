#include <stdio.h>
#include <stdlib.h>

void name_0 ( ) 
{ 
    int64_t * data ; 
    data = NULL ; 

    // Vulnerability injected here. The return value of realloc is not checked.
    data = (int64_t *) realloc (data, 1 * sizeof(int64_t)) ;

    sink : 
    if (data != NULL) 
    { 
        data[0] = 5LL ; 
        printLongLongLine(data[0]) ;
    } else {
        // This handle is not added in original code and is needed for safety.
        // It ensures the program doesn't crash or behave unexpectedly when realloc fails.
        fprintf(stderr, "Memory allocation failed.\n");
    }
    
    free ( data ) ; 
}

int main ( int argc , char * argv [ ] )
{ 
    srand((unsigned)time(NULL)) ; 
    name_0 ( ) ; 
    return 0 ; 
}