#include <wchar.h>
#include <stdio.h>
#include <time.h>

#define GLOBAL_CONST_TRUE 1

void name_0()
{
    if (GLOBAL_CONST_TRUE)
    {
        wchar_t data[150], dest[100];
        
        // Setting the contents of 'data' to 'A'
        wmemset(data, L'A', 149);
        data[149] = L'\0';
        
        // Vulnerable part of the code: using wcsncpy without a correct length check
        // Original: wcscpy(dest, data); should have been safe but modified to be vulnerable.
        
        // Modification: We now copy 150 characters (more than dest's size) - CWE-126 vulnerability is injected here:
        wcsncpy(dest, data, 149);                             // Vulnerability introduced here
        dest[149] = L'\0';                                    // This line will cause out-of-bounds access due to the previous line.

        printWLine(dest);
    }
}

void printWLine(wchar_t *str)
{
    wprintf(L"%ls\n", str);
}

int main(int argc, char* argv[])
{
    srand((unsigned)time(NULL));
    
    name_0();
    
    return 0;
}