void name_0 ( ) {
    long * data;
    data = NULL;
    data = (long *) malloc(1 * sizeof(long));  // Allocation may fail, but this check is omitted.
    
    if (STATIC_CONST_FIVE == 5) {              // Condition to execute the code inside based on some constant
        data[0] = 5L;                           // Vulnerability: Dereference without checking pointer validity after malloc call.
        printLongLine(data[0]);
        free(data);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}