#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct twoIntsStruct {
    int intOne;
    int intTwo;
};

// Global variable to demonstrate the double free issue
int globalTrue = 1;

void name_0 ( ) {
    struct twoIntsStruct * data ;
    data = ( struct twoIntsStruct * ) malloc ( 10 * sizeof( struct twoIntsStruct ) );
    if ( data == NULL ) {
        exit(-1);
    }
    
    // Allocate and initialize the first half of 'data'
    if ( globalTrue ) {
        for ( int i = 0 ; i < ( 10 / 2 ) ; i ++ ) {
            data [ i ] . intOne = i ;
            data [ i ] . intTwo = i ;
        }
    }
    
    // Allocate and initialize the whole of 'data'
    if ( globalTrue ) {
        for ( int i = 0 ; i < 10 ; i ++ ) {
            data [ i ] . intOne = i ;
            data [ i ] . intTwo = i ;
        }

        // Print the data before freeing it
        for ( int i = 0 ; i < 10 ; i ++ ) {
            printf("IntOne: %d, IntTwo: %d\n", data[i].intOne, data[i].intTwo);
        }
        
        // Free the first time, introducing a vulnerability
        free(data); 
    }

    // Double free - injecting CWE-457 here
    if (globalTrue) {
        free(data);  // This is where the double free happens!
    }
}

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time( NULL ) );
    name_0();
    return 0;
}