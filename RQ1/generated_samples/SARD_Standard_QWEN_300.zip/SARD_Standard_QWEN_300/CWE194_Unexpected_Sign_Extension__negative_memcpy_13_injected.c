#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Assume GLOBAL_CONST_FIVE is defined as a constant and always equals 5.
#define GLOBAL_CONST_FIVE 5

void name_0 ( ) {
    short data;
    data = 0;

    if (GLOBAL_CONST_FIVE == 5) {
        // Modify the value of 'data' here for demonstration purposes
        // This will lead to a potential buffer overflow when data + 1 >= 100.
        data = 99 - 1;   // Potential vulnerability: off-by-one error in setting data value
    }

    char source[100];
    char dest[100] = "";

    memset(source, 'A', 100 - 1);
    source[100 - 1] = '\0';

    if (data < 100) {
        memcpy(dest, source, data + 1);   // Potential vulnerability: off-by-one error in amount of data copied
        dest[data + 1] = '\0';            // Ensuring null termination after potential overflow

        // Note that setting dest[data+1]='\0' is an attempt to prevent a buffer overrun.
    }

    printLine(dest);
}

int main(int argc, char* argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}