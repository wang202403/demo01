#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    wchar_t charFirst[5];  // Reduced size to create buffer overflow vulnerability
    void* voidSecond;
} CharVoidStruct;

void printWLine(wchar_t *str) {
    wprintf(L"%ls\n", str);
}

const wchar_t SRC_STR[] = L"Hello, this is a string that is too long for the buffer.";

void name_0() {
    while (1) {
        CharVoidStruct structCharVoid;

        // Assign a pointer to a longer string
        structCharVoid.voidSecond = (void *)SRC_STR;
        printWLine((wchar_t *)structCharVoid.voidSecond);

        // Copy data without bounds checking, creating the CWE-121 vulnerability:
        memcpy(structCharVoid.charFirst, SRC_STR, sizeof(SRC_STR));  // Vulnerable line

        // The next three lines are now problematic due to potential overflow
        structCharVoid.charFirst[(sizeof(structCharVoid.charFirst) / sizeof(wchar_t)) - 1] = L'\0';
        
        printWLine((wchar_t *)structCharVoid.charFirst);
        printWLine((wchar_t *)structCharVoid.voidSecond);

        break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}