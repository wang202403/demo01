#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0 ( ) 
{ 
    char * data ; 
    data = NULL ; 
    
    {
        char myString [ ] = "myString" ;
        
        // Vulnerability injected here:
        // Memory allocated via strdup is not freed
        data = strdup ( myString ) ; 

        printLine ( data ) ;
    }

    {
        char * dataCopy = data ;

        // Commented out memory release to demonstrate CWE-401 - Memory Leak 
        // free(data);

        // This was an incorrect declaration, it should be removed or corrected.
        // char * data = dataCopy ; 
        
    }
}

int main ( int argc , char * argv [ ] ) { 

    srand ( ( unsigned ) time ( NULL ) ) ;
    
    name_0 ( ) ;

    return 0 ;
}