#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(s) malloc(s)

void name_0 (char * data) {
    size_t i;
    char dest[100];
    
    // Initialize the destination array with 'C'
    memset(dest, 'C', 100 - 1);
    dest[100 - 1] = '\0'; 
    
    for (i = 0; i < strlen(data); i++) { 
        dest[i] = data[i]; 
    }
    
    // Potential vulnerability: printLine() might be susceptible to format specifiers
    // The function call has been modified here:
(dest[100 - 1] = '\0', printf(dest)); // CWE-127 Uncontrolled Format String

}

void name_1 () {
    char * data;
    void (*funcPtr) (char *) = name_0;
    
    char * dataBuffer = (char *) ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    data = dataBuffer;
    
    funcPtr(data); 
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL)); 
    name_1();
    return 0;  
}