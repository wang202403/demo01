#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <wincrypt.h>

void name_0(void) {
    switch (6) {
        case 6:
        {
            FILE *pFile;
            HCRYPTPROV hCryptProv;
            HCRYPTKEY hKey;
            HCRYPTHASH hHash;
            char password[100];
            size_t passwordLen;
            char toBeDecrypted[100];
            DWORD toBeDecryptedLen = sizeof(toBeDecrypted) - 1;

            if (fgets(password, 100, stdin) == NULL) {
                password[0] = '\0';
            }
            passwordLen = strlen(password);
            if (passwordLen > 0) {
                password[passwordLen - 1] = '\0';
            }

            pFile = fopen("encrypted.txt", "rb");
            if (pFile == NULL) {
                exit(1);
            }

            if (fread(toBeDecrypted, sizeof(char), 100, pFile) != 100) {
                fclose(pFile);
                exit(1);
            }
            toBeDecrypted[99] = '\0';

            if (!CryptAcquireContext(&hCryptProv, NULL, MS_ENHANCED_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
                if (!CryptAcquireContext(&hCryptProv, NULL, MS_ENHANCED_PROV, PROV_RSA_FULL, CRYPT_NEWKEYSET)) {
                    exit(1);
                }
            }

            // CWE-327: Use of a Broken or Risky Cryptographic Algorithm
            // Modified to use DES instead of AES and SHA-256
            if (!CryptCreateHash(hCryptProv, CALG_SHA_1, 0, 0, &hHash)) {  // Vulnerable line
                exit(1);
            }
            if (!CryptHashData(hHash, (BYTE *)password, passwordLen, 0)) {
                exit(1);
            }

            if (!CryptDeriveKey(hCryptProv, CALG_3DES, hHash, CRYPT_EXPORTABLE, &hKey)) {  // Vulnerable line
                exit(1);
            }

            if (!CryptDecrypt(hKey, 0, 1, 0, (BYTE *)toBeDecrypted, &toBeDecryptedLen)) {
                exit(1);
            }
            toBeDecrypted[toBeDecryptedLen] = '\0';
            printLine(toBeDecrypted);

            if (hKey) {
                CryptDestroyKey(hKey);
            }
            if (hHash) {
                CryptDestroyHash(hHash);
            }
            if (hCryptProv) {
                CryptReleaseContext(hCryptProv, 0);
            }
            if (pFile) {
                fclose(pFile);
            }

        } break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}