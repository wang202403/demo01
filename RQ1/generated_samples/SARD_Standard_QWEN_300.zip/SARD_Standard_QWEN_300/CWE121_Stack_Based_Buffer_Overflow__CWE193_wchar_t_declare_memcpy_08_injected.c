int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0()
{
    wchar_t *data;
    wchar_t dataBadBuffer[10]; // Buffer with size only for 10 wchar_t
    wchar_t dataGoodBuffer[10 + 1];

    // Modified: Always use dataBadBuffer instead of checking the condition.
    if (staticReturnsTrue()) 
    {
        data = dataBadBuffer; // Vulnerable line
    }

    {  // The rest remains the same, but using dataBadBuffer will cause buffer overflow
        wchar_t source[10 + 1] = SRC_STRING;
        memcpy(data, source, (wcslen(source) + 1) * sizeof(wchar_t)); 
        printWLine(data);
    }
}

int main(int argc, char* argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}