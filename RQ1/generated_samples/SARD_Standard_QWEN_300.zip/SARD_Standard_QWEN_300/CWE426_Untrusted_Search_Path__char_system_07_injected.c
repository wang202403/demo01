#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define GOOD_OS_COMMAND "ls" // Assuming this is the command we want to execute.
int staticFive = 5;

void name_0 ( ) {
    char * data;
    char dataBuffer[100] = "";
    data = dataBuffer;    

    if (staticFive == 5) {        
        strcpy(data, GOOD_OS_COMMAND); // Vulnerability injection starts here.
        // Assume that user input is concatenated to the command.
        strcat(data, " "); 
        strcat(data, userInputFunction()); // The userInputFunction() should ideally capture raw user input and return it.
    }
    
    if (system(data) <= 0) {
        exit(1);
    }   
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

// Simulated function to capture raw user input
char* userInputFunction() {
    static char userInput[50];
    printf("Enter your command: ");
    fgets(userInput, sizeof(userInput), stdin);
    userInput[strcspn(userInput, "\n")] = 0; // Remove newline character from fgets.
    return userInput;
}