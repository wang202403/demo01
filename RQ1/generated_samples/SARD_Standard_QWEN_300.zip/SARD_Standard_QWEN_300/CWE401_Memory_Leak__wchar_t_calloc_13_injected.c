void name_0 ( )
{
    wchar_t * data;
    data = NULL;

    if ( GLOBAL_CONST_FIVE == 5 ) {
        // Allocate memory for "data"
        data = ( wchar_t * ) calloc ( 100 , sizeof ( wchar_t ) );
        if ( data == NULL ) {
            exit ( - 1 );
        }

        // Initialize the allocated memory
        wcscpy ( data , L"A String" );

        // Print the string in "data"
        printWLine ( data );
    }
    
    // Commented out the free call to cause a CWE-401 vulnerability
    // if ( GLOBAL_CONST_FIVE == 5 ) {
    //     free ( data );   // This line is commented out, leading to memory leak
    // }

}

int main ( int argc , char * argv [ ] )
{
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    
    return 0 ;
}