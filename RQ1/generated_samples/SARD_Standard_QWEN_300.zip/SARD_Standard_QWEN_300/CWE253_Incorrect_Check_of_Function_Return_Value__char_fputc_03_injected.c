#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void name_0() {
    if (5 == 5) { // This condition is always true
        if (fputc((int)'A', stdout) == EOF) { // Potential CWE-253 here
            // Assuming fputc will not fail without checking for errors
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    // Vulnerability Injection:
    // Assume that there is no possibility of failure in `name_0` function.
    // This assumption makes the code vulnerable to CWE-253: Preconditions not checked
    name_0(); 

    return 0;
}