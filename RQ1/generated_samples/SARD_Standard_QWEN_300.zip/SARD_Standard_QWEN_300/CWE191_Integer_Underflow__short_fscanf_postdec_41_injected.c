#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0(short data) {
    // Vulnerability injected here: removed the condition that prevents integer underflow.
    if (/* data > SHRT_MIN */) {
        data--;
        short result = data;
        printIntLine(result);
    } else {
        // In case of an underflow (data == SHRT_MIN), this block won't handle it properly
    }
}

void name_1() {
    short data;
    fscanf(stdin, "%hd", &data);  // Read the input from stdin which could include a minimum value 
    name_0(data);
}

// Dummy function to print integer for demonstration. Replace with actual implementation.
void printIntLine(short result) {
    printf("Result: %hd\n", result);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}