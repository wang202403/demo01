#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void printLine(const char *line)
{
    printf("%s\n", line);
}

void name_0(int data) 
{ 
    { 
        char source[100]; 
        char dest[100] = ""; 

        memset(source, 'A', 100 - 1); 
        source[100 - 1] = '\0'; 
        
        // Vulnerability introduced here: Removed the check to ensure data < 100
        memcpy(dest, source, data); // CWE-195: Improper Restriction of Operations within the Bounds of a Memory Buffer

        dest[data] = '\0'; 
    } 
} 

void name_1() 
{ 
    int data; 
    data = -1; 
    data = 100 - 1; // This sets `data` to 99, which is still within bounds in this specific case.
                    // However, the function now has a vulnerability because it no longer checks if data < 100
    
    name_0(data); 
} 

int main(int argc, char *argv[]) 
{ 
    srand((unsigned)time(NULL)); 
    name_1(); 
    return 0; 
}