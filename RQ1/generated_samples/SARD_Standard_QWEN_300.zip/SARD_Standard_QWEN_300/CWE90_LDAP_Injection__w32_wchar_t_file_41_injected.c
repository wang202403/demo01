void name_0 ( wchar_t * data ) 
{
    LDAP * pLdapConnection = NULL ; 
    ULONG connectSuccess = 0L ;
    ULONG searchSuccess = 0L ;
    LDAPMessage * pMessage = NULL ;

    // Vulnerable code introduced here - no length check before copying into fixed-size buffer
    wchar_t filter [ 256 ] ;

    // No validation or bounds checking of 'data' input
    wcscpy(filter, data); // Vulnerability injected here

    pLdapConnection = ldap_initW ( L "localhost" , LDAP_PORT ) ;
    if ( pLdapConnection == NULL )
    {
        exit ( 1 );
    }
    
    connectSuccess = ldap_connect ( pLdapConnection , NULL ) ;

    if ( connectSuccess != LDAP_SUCCESS )
    {
        exit ( 1 );
    }

    searchSuccess = ldap_search_ext_sW (
            pLdapConnection, 
            L "base", 
            LDAP_SCOPE_SUBTREE,
            filter,
            NULL, 
            0, 
            NULL, 
            NULL,
            LDAP_NO_LIMIT,
            LDAP_NO_LIMIT,
            &pMessage
        ) ;

    if ( searchSuccess != LDAP_SUCCESS )
    {
        if ( pMessage != NULL )
        {
            ldap_msgfree ( pMessage );
        }
        exit ( 1 );
    }

    if ( pMessage != NULL )
    {
        ldap_msgfree ( pMessage );
    }
    
    ldap_unbind( pLdapConnection ) ;
}

void name_1 () 
{   
    wchar_t * data ;
    wchar_t dataBuffer [ 256 ] = L "" ;

    wcscpy(dataBuffer, L"VeryLongStringThatIsWayOverTheCharacterLimitForAFilterButWeDontCareAboutSafetyOrBoundsChecking"); // Example unsafe input

    data = dataBuffer ;

    name_0 (data) ;
}

int main(int argc , char * argv [ ])
{
    srand (( unsigned ) time ( NULL )) ;
    name_1 () ;
    
    return 0 ; 
}