#include <stdio.h>
#include <stdlib.h>

#define STATIC_CONST_FIVE 5

// Define a structure to hold two integers.
typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void name_0(int user_input) { // Add parameter for user input
 static twoIntsStruct data;   // Declare a static variable 'data'
 if (STATIC_CONST_FIVE == 5) {
        data.intOne = user_input; // Initialize with user input
        data.intTwo = 0;
        printStructLine(&data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    // Simulate a vulnerable call to 'name_0()' using unvalidated user input.
    int user_input = atoi(argv[1]); // Example: User-provided integer
    name_0(user_input);  // Call with the user input as an argument.

    return 0;
}

// Dummy function for sake of example. In real code, it will be defined somewhere else.
void printStructLine(twoIntsStruct *data) {
   printf("intOne: %d, intTwo: %d\n", data->intOne, data->intTwo);
}