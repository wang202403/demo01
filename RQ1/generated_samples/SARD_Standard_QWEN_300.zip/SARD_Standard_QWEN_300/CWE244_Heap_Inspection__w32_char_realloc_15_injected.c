#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

void name_0 ( ) {
    switch ( 6 ) {
        case 6 : 
        {   
            char * password = ( char * ) malloc ( 100 * sizeof ( char ) ) ;
            if ( password == NULL ) 
            {
                exit ( - 1 ) ;
            }
            size_t passwordLen = 0 ; 
            HANDLE hUser ;
            char * username = "User" ;
            char * domain = "Domain" ;
            password [ 0 ] = '\0' ;

            if ( fgets ( password , 100 , stdin ) == NULL ) 
            {
                password [ 0 ] = '\0' ;
            }

            passwordLen = strlen ( password ) ;
            if ( passwordLen > 0 )
            {   
                password [ passwordLen - 1 ] = '\0' ;  
            }   

            if ( LogonUserA ( username , domain , password , LOGON32_LOGON_NETWORK , LOGON32_PROVIDER_DEFAULT , & hUser ) != 0 ) 
            {
                CloseHandle ( hUser ) ;
            }   
            else
            {   
            }

            SecureZeroMemory ( password , 100 * sizeof ( char ) ) ;

            // Injecting CWE-244: Not checking the return value of realloc.
            // This means if realloc fails, we continue using the original memory allocation which can lead to issues:
            password = realloc ( password , 200 * sizeof ( char ) ) ;  // <<< INJECTION POINT

            strcpy ( password , "Nothing to see here" ) ;
            printLine ( password ) ;

            free ( password ) ;
        }   
    break ;    
    default :
    break ;
}
}

int main ( int argc, char * argv[] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}