#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Global function for demonstration purposes
int globalReturnsTrue() {
    return 1;
}

void name_0 ( ) { 
    if ( globalReturnsTrue ( ) ) { 
        // New input variable without proper bounds checking, introducing CWE-253 vulnerability.
        char userInput[10]; 

        printf("Enter a string: ");
        scanf("%s", userInput);  // Potential buffer overflow here due to lack of bounds checking.

        if ( fprintf ( stdout , "%s\n" , userInput ) < 0 ) {
            // Placeholder for error handling
        } 
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 ( ); 
    return 0; 
}