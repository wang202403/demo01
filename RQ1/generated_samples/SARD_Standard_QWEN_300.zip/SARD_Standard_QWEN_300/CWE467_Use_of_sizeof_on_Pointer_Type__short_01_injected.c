#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printShortLine(short line)
{
    printf("%hd\n", line);
}

// Function with introduced CWE-467 vulnerability
void name_0 ( ) 
{   
    short * name_1 = NULL ;    
    name_1 = (short *) malloc( sizeof(short) ); // Allocate space for a single short, but we'll treat it as space for a character array.
    if (name_1 == NULL)
    {
        exit(-1);
    }
    
    char fixedBuffer[8];  // Fixed-length buffer
    strcpy(fixedBuffer, "This is a dangerously long string to trigger a buffer overflow");  // Unchecked use of strcpy -> CWE-467 vulnerability
    printf("Copied into %s\n", fixedBuffer);

    short name_3 = 6 ;    
    printShortLine(name_3);
    free(name_1);  
}  

int main ( int argc, char * argv [ ] ) 
{   
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}