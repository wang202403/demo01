#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0(void) {
    char *data;
    data = NULL;

    if (1) {
        data = (char *)realloc(data, 100 * sizeof(char)); // memory allocation
        if (data == NULL) {
            exit(-1);
        }
        strcpy(data,"A String");
        printLine(data); // Assume this is a defined void function to print out the line
    }

    char* leakedMemory;
    leakedMemory = malloc(50 * sizeof(char));  // Introducing CWE-401 vulnerability by allocating memory and not freeing it later

    if (1) {
        //free(leakedMemory);   Commenting or omitting this line introduces a Memory Leak CWE-401
        free(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}