#include <wchar.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    wchar_t * data ;
    wchar_t ** dataPtr1 = &data;
    wchar_t ** dataPtr2 = &data;

    // Original buffer, modified to be small for demonstration
    wchar_t dataBadBuffer[50]; 
    wchar_t dataGoodBuffer[100];

    { 
        data = *dataPtr1; 
        data = dataBadBuffer; // Use the smaller buffer instead of the larger one
        data[0] = L'\0'; 
        *dataPtr1 = data;
    }

    {
        wchar_t* data = *dataPtr2;

        {
            wchar_t source[100];
            wmemset(source, L'C', 100 - 1);
            source[100 - 1] = L'\0';
            
            // The following line introduces the CWE-121 vulnerability.
            wcscat(data, source); // data is now pointing to a smaller buffer

            printWLine(data);
        }
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}