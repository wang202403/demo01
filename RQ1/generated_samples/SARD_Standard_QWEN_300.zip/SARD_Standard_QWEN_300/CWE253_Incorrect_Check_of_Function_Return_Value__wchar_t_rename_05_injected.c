#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define staticTrue 1

int RENAME(char *old_filename, char *new_filename);

void name_4(void) {
    if (staticTrue == 0) { // Incorrect check: This will never be true
        if (RENAME(OLD_GOOD_FILE_NAME, NEW_GOOD_FILE_NAME) != 0) { 
            perror("Error renaming file");  // Added to make the function more meaningful
        }
    } else {
        printf("staticTrue is not 0\n");
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_4();
    return 0;
}