#include <stdlib.h>
#include <time.h>

void printIntLine(int data) {
    printf("%d\n", data);
}

void name_0 ( ) { 
    int * data ; 
    data = NULL ; 
    
    // Allocate memory for 100 integers
    { 
        int * dataBuffer = (int *) malloc(100 * sizeof(int)); 
        if (dataBuffer == NULL) { 
            exit(1); 
        } 

        { 
            size_t i; 
            for (i = 0; i < 100; i++) { 
                dataBuffer[i] = 5; 
            } 
        } 
        data = dataBuffer; 
    }

    // CWE-590: Freeing with wrong size
    free(data); // Originally correct, but to demonstrate the vulnerability we will modify this.
    
    // Incorrect freeing of memory (CWE-590)
    free((char*)data + sizeof(int));  // Introduced the vulnerability here

    printIntLine(data[0]);
} 

int main(int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL));
    name_0(); 
    return 0; 
}