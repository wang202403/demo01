#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef union {
    char *unionFirst;
    char *unionSecond;
} CWE127_Buffer_Underread__malloc_char_loop_34_unionType;

void name_0(void) {
    char *data;  // Vulnerable: No initialization
    CWE127_Buffer_Underread__malloc_char_loop_34_unionType myUnion;

    data = NULL;

    {   // Allocate and initialize the buffer to 'A'
        char *dataBuffer = (char *) malloc(100 * sizeof(char));
        if (dataBuffer == NULL) {
            exit(-1);
        }
        memset(dataBuffer, 'A', 100 - 1); 
        dataBuffer[100 - 1] = '\0';
        
        // Vulnerable code modification: Directly using uninitialized pointer instead of copying address
        // data = dataBuffer; Comment this line out to introduce the vulnerability
    }

    myUnion.unionFirst = data;

    {
        char *data = myUnion.unionSecond;
        
        {   // Copy from potentially unitialized variable `data` into dest buffer
            size_t i;
            char dest[100];
            memset(dest, 'C', 100 - 1);
            dest[100 - 1] = '\0';
            
            for (i = 0; i < 100; i++) {
                dest[i] = data[i]; // Vulnerable: Dereferencing potentially uninitialized pointer `data`
            }
            dest[100-1] = '\0';
            printLine(dest);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}