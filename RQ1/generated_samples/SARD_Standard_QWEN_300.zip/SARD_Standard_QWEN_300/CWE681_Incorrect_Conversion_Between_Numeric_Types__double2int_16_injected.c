#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 100

void name_0 () {
    while (1) {
        char inputBuffer[CHAR_ARRAY_SIZE]; // Vulnerable portion starts here
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {            
            printf(inputBuffer); // Uncontrolled format string vulnerability is introduced here
            
            double doubleNumber = 0;
            doubleNumber = atof(inputBuffer);
            
            if (doubleNumber > INT_MAX || doubleNumber < INT_MIN) {
                // Intentionally left empty
            } else {
                printIntLine((int)doubleNumber); // Assuming printIntLine is defined somewhere in your codebase.
            }
        }
        
        break;
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}