#include <stdlib.h>
#include <stdio.h>

// struct definition for twoIntsStruct (assuming it is defined somewhere)
struct twoIntsStruct {
    int intOne;
    int intTwo;
};
typedef struct twoIntsStruct twoIntsStruct;

void printStructLine(const twoIntsStruct *data) { // Assuming this function exists somewhere
    printf("intOne: %d, intTwo: %d\n", data->intOne, data->intTwo);
}

void name_0 ( ) {
    twoIntsStruct * data;
    data = NULL;

    if ( 5 == 5 ) {
        // Allocate memory but do not free it later
        data = (twoIntsStruct *) malloc(100 * sizeof(twoIntsStruct)); 
        if (data == NULL) {
            exit(-1);
        }
        data[0].intOne = 0;
        data[0].intTwo = 0;

        // print the struct
        printStructLine(&data[0]);
    }

    // Memory leak vulnerability: remove the freeing of allocated memory to create CWE-401
    // if (5 == 5) {
    //     free(data);
    // }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}