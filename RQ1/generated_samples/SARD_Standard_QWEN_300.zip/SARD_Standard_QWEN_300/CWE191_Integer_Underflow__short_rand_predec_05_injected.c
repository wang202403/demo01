#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SHRT_MIN -32768
#define staticTrue 1

unsigned int RAND32(void) {
    return rand(); // SimplifiedRAND32 for demonstration purposes
}

void name_0 ( ) { 
    short data ; 
    data = 0;

    if (staticTrue) { 
        data = (short)RAND32();
    }

    // Introducing CWE-191 Integer Underflow vulnerability here:
    if ( staticTrue ) {
        if (data >= SHRT_MIN + 1) {
            -- data; // Potential underflow occurs here
        }
        
        short result = data;
        printIntLine(result);
    } 
}

void printIntLine(int line) {
    printf("%d\n", line);
}    

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL));    
    name_0();
    return 0 ;  
}