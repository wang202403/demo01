#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define CHAR_ARRAY_SIZE 10 // Assuming this is defined somewhere

int globalTrue = 1; // Assuming global variable is initialized

void name_0() {
    int data;
    data = 0;

    if (globalTrue) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        }
    }

    // Vulnerability introduced by removing the range check
    // Removing this part:
    // if (data > INT_MIN && abs(data) < (long)sqrt((double)INT_MAX)) 
    // to demonstrate vulnerability
    
    int result = data * data; // CWE-190: Integer Overflow or Wrap around
    printIntLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}