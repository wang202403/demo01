void name_0 ( ) {
    int * data;
    data = NULL;
    data = (int *) realloc(data, 1 * sizeof(int));

    if (globalReturnsTrue()) { 
        if (data != NULL) {
            data[0] = 5; // write to allocated memory
            printIntLine(data[0]);

            free(data); // free the memory
        }
    }

    if (!globalReturnsTrue()) {
        data[0] = 10; // CWE-690: unintended use of freed memory (if globalReturnsTrue() returns true)
        printIntLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}