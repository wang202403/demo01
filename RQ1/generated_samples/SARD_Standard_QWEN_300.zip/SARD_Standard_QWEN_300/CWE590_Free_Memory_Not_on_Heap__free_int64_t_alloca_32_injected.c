#include <stdio.h>
#include <stdlib.h>

void name_0 ( ) {
    int64_t * data;
    int64_t ** dataPtr1 = &data;
    int64_t ** dataPtr2 = &data;

    data = NULL; // Initial pointer set to NULL

    { // Allocate and initialize an array of 100 int64_t elements
        int64_t * dataAllocated = malloc(100 * sizeof(int64_t));
        if (dataAllocated == NULL) {
            exit(1);
        }
        for(size_t i = 0; i < 100 ; ++i) {
            dataAllocated[i] = 5LL;
        }

        // Set both pointers to point to the allocated memory
        *dataPtr1 = dataAllocated;
        *dataPtr2 = dataAllocated;

        free(dataAllocated);  // Free here - double free in CWE-590 vulnerability
    } 

    { // Use and free the array again leading to a double-free vulnerability
        int64_t * data = *dataPtr2; 
        printLongLongLine( data[0] );
        free(data); // Second free (double free) here
    }
}

int main(int argc, char* argv[] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}