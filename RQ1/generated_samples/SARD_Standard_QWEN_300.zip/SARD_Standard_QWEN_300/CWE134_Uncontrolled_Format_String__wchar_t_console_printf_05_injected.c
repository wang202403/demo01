#include <wchar.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define staticTrue 1

void name_0() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";

    data = dataBuffer;

    if (staticTrue) {
        size_t dataLen = wcslen(data);
        if (100 - dataLen > 1) {
            // User input without validation
            fgetws(data + dataLen, (int)(100 - dataLen), stdin);
            // No further validation or control of the format string below
            wprintf(data); // Vulnerable line: using unchecked user input as a format string.
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}