#include <stdio.h>
#include <stdlib.h>

void printLongLongLine(int64_t value)
{
    printf("%lld\n", value);
}

void name_0 ( int64_t * data ) { 
    // Vulnerable code: Incorrect operator precedence can affect the output or crash the program.
    // For demonstration, we add a vulnerable line involving bitwise shift and arithmetic operations.
    for(size_t i = 0; i < 100; ++i) {
        printLongLongLine( data[i] << 4 + 5 ); // CWE-590: Improper Binary Operator Precedence
    }
    
    free ( data ) ;
}

void name_1 ( ) { 
    int64_t * data ; 
    void (* funcPtr)(int64_t *) = name_0 ; 
    
    data = NULL ; 

    { 
        int64_t * dataBuffer = (int64_t *) malloc ( 100 * sizeof ( int64_t ) ); 
        
        if ( dataBuffer == NULL ) {
            exit ( 1 );
        }
        
        for(size_t i = 0; i < 100; ++i) { 
            dataBuffer[i] = 5LL;
        } 

        data = dataBuffer ;
    }

    funcPtr( data );

}

int main ( int argc , char * argv [] ) {
    srand((unsigned)time(NULL));
    name_1();
    
    return 0;
}