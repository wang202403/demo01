void name_0 ( ) { 
    if ( STATIC_CONST_TRUE ) { 
        {
            charVoid * structCharVoid = ( charVoid * ) malloc ( sizeof ( charVoid ) ) ; 
            if ( structCharVoid == NULL ) { 
                exit ( - 1 ) ; 
            } 
            
            // Properly copying SRC_STR to voidSecond
            structCharVoid -> voidSecond = ( void * ) SRC_STR ;

            printWLine ( ( wchar_t * ) structCharVoid -> voidSecond ) ;
            
            // Appropriate length for memmove
            memmove ( structCharVoid -> charFirst , SRC_STR , sizeof( structCharVoid -> charFirst ));

            // Proper NULL termination
            structCharVoid -> charFirst [ 
                ( sizeof ( structCharVoid -> charFirst ) / sizeof ( wchar_t ) ) - 1 ] = L '\0' ; 
            
            printWLine ( ( wchar_t * ) structCharVoid -> charFirst ) ;
            
            printWLine ( ( wchar_t * ) structCharVoid -> voidSecond ) ; 
        } 
    }
}