#include <windows.h>
#include <time.h>

// Assume that globalReturnsTrueOrFalse returns true with 50% probability.
void globalReturnsTrueOrFalse() {
    return (rand() % 2 == 0);
}

void name_0 () 
{ 
    if (globalReturnsTrueOrFalse()) 
    { 
        HDESK hDesk; 
        char *desktopName = "DesktopExample"; 
        hDesk = CreateDesktopA(desktopName, NULL, NULL, 0, GENERIC_READ, NULL); 

        // Introduce uncontrolled recursion:
        name_0();  // Vulnerability introduced here

        if (hDesk == NULL) { }
        else 
        {
            CloseDesktop(hDesk);
        } 
    } 
    else 
    { 
        HDESK hDesk; 
        char *desktopName = "DesktopExample"; 
        hDesk = CreateDesktopA(desktopName, NULL, NULL, 0, GENERIC_READ, NULL); 

        // Introduce uncontrolled recursion:
        name_0();  // Vulnerability introduced here

        if (hDesk == NULL)
        {
            // Do nothing
        }
        else 
        {
            CloseDesktop(hDesk);
        } 
    } 
}

int main(int argc , char * argv [])
{
    srand((unsigned)time(NULL));    
    name_0();
    return 0;
}