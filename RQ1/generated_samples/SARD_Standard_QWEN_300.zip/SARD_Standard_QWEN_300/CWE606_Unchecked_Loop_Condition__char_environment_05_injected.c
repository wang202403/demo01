#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ENV_VARIABLE "INPUT_VAR"
#define MAX_LOOP 100

int staticTrue = 1;

void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;

    if ( staticTrue ) { // Begin block
        size_t dataLen = strlen ( data );
        
        // Potential source of untrusted input
        char * environment = getenv(ENV_VARIABLE);
        if ( environment != NULL ) {
            strncat(data + dataLen , environment, 100 - dataLen - 1);
        }
    }

    if ( staticTrue ) { // Begin block
        int i , n , intVariable ;
        
        if ( sscanf( data , "%d" , &n ) == 1 ) {
            // VULNERABILITY INJECTED HERE: Removed the check "if (n < MAX_LOOP)"
            // intVariable = 0; // This line will be executed even with large values of n
           
            for ( i = 0 ; i < n ; i ++ ) { // Loop condition is now directly controlled by user input 'data'
                intVariable++;
            }
            
            printIntLine( intVariable );
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}