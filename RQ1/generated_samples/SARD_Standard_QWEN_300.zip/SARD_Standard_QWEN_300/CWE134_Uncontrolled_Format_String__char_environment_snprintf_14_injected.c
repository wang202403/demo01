#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Assuming globalFive is defined elsewhere as:
extern int globalFive;

#define ENV_VARIABLE "USER_VAR"

char * GETENV(const char *name) {
    return getenv(name);
}

void printLine(char *line){
    printf("%s\n", line); // Safe printing function
}

void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ;
    
    data = dataBuffer ;

    if ( globalFive == 5 ) {
        size_t dataLen = strlen ( data ) ;
        char * environment = GETENV ( ENV_VARIABLE ) ;
        
        // Potential buffer overflow if environment is too large
        if (environment != NULL) {
            strncat ( data + dataLen , environment , 100 - dataLen - 1 ) ; 
        }
    }

    if ( globalFive == 5 ) {  
        char dest [ 100 ] = "" ;
        
        // Vulnerability: Using 'data' as both the format string and argument
        // This is where CWE-134 "Uncontrolled Format String" injection occurs.
        printf(dest , data) ; // Uncontrolled format string vulnerability

        printLine ( dest ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    
    name_0 ( ) ;

    return 0 ;
}