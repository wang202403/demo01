#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define CHAR_MAX 127 // Define CHAR_MAX as per C standards

void name_0() {
    char data;
    data = ' '; // Initialize data to a space character

    if (globalReturnsTrueOrFalse()) {
        fscanf(stdin, "%c", &data); // Read character from stdin
    } else {
        fscanf(stdin, "%c", &data); // Read character from stdin
    }

    if (globalReturnsTrueOrFalse()) {
        // Vulnerability introduced here: No check if data == CHAR_MAX before incrementing
        data++; 
        char result = data;
        printHexCharLine(result);
    } else {
        // Vulnerability introduced here: No check if data == CHAR_MAX before incrementing
        data++;
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}