#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>

void name_0 ( ) {
    wchar_t * data;
    data = NULL;

    // STATIC_CONST_TRUE is assumed to be defined elsewhere and set to a non-zero constant value.
    if (STATIC_CONST_TRUE) { 
        wchar_t * dataBuffer = (wchar_t *) malloc(100 * sizeof(wchar_t));  // Allocate memory for 100 wide characters
        if (dataBuffer == NULL) {
            exit(-1);
        }
        wmemset(dataBuffer, L'A', 100 - 1);  // Initialize dataBuffer with 'A'
        dataBuffer[100 - 1] = L'\0';         // Null-terminate the buffer
        data = dataBuffer;
    }

    { 
        size_t i;
        wchar_t source[200];                   // Modified here -- increased the array size to 200 elements
        wmemset(source, L'C', 199);            // Initialize source with 'C' up to 199 characters (before null-terminator)
        source[199] = L'\0';                   // Null-terminate the source buffer

        for (i = 0; i < 200; i++) {           // Modified here -- loop runs up to 200 elements
            data[i] = source[i];               // Overwrite 'data' with contents of 'source', causing buffer overflow
        }

        data[199] = L'\0';                     // Null-terminate the overwritten buffer, writing outside allocated memory

        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}