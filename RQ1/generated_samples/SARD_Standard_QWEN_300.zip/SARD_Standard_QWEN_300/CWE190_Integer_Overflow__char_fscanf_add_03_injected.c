#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    char data;
    data = ' ';  // Initialize the character
    if ( 5 == 5 ) { 
        fscanf ( stdin , "%c" , & data );  // Read a single character from stdin
    }
    
    if ( 5 == 5 ) {                          // Check condition always true
        // Injecting CWE-190 vulnerability here:
        if ( (char)(data - 1) > CHAR_MIN ) {  // Misleading check for underflow, which is incorrect.
            char result = data + 1;           // Potential overflow when 'data' is close to CHAR_MAX
            printHexCharLine(result);         // Print the result in hexadecimal format
        } 
    else {
      printf("Character value is invalid or leads to potential integer underflow.\n");
    }
   }
}

int main ( int argc , char * argv[] ) {
    srand((unsigned)time(NULL));  // Seed random number generator
    name_0();                     // Call the function
    return 0;
}