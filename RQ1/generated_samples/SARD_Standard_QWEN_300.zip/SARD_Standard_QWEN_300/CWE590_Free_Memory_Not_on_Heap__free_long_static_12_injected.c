#include <stdio.h>
#include <stdlib.h>

int globalReturnsTrueOrFalse(void) {
    return (rand() % 2); // A simple function for demonstration purposes
}

void name_0(void) {
    long * data;
    data = NULL;

    if (globalReturnsTrueOrFalse()) { // If true, this part will be executed
        {
            long * dataBuffer = (long *) malloc(100 * sizeof(long));
            if (dataBuffer == NULL) {
                exit(1);
            }
            {
                size_t i;
                for (i = 0; i < 100; i++) {
                    dataBuffer[i] = 5L;
                }
            }
            data = dataBuffer;
        }

    } else { // If false, this part will be executed
        data = (long *)123456789; // Example of assigning a fake address with no heap allocation [MODIFIED]
    }

    printLongLine(data[0]);

    free(data);  // Freeing data that has not been allocated properly in the else branch -> CWE-590
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}