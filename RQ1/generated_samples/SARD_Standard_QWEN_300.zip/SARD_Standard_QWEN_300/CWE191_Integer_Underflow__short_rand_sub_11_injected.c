#include <stdio.h>
#include <time.h>

// Dummy functions for demonstration purposes
int globalReturnsTrue(void) { return 1; }
unsigned int RAND32(void) { return (unsigned int)((double)rand() / ((double)RAND_MAX + 1.0) * UINT_MAX); }

void name_0 ( ) {
    short data;
    data = 0;

    if ( globalReturnsTrue ( ) ) {
        data = (short) RAND32();
    }
    
    // Modification: No check for SHRT_MIN before subtraction
    if ( globalReturnsTrue ( ) ) {
        // CWE-191 vulnerability injected here.
        short result = data - 1;   // This can lead to underflow if 'data' is already SHRT_MIN.
        printIntLine(result);
    }
}
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

void printIntLine(short result) {
    printf("%d\n", (int)result);   // Convert to int for printing
}