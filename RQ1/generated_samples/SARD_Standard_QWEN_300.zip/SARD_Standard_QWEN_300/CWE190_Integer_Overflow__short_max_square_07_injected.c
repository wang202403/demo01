#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SHRT_MAX 32767

int staticFive = 5;

void name_0 ( ) {
    short data;
    data = 0;

    if (staticFive == 5) { 
        data = SHRT_MAX; // Assigning the maximum value a short can hold
    }

    // Removing the check to introduce the integer overflow vulnerability!
    if (staticFive == 5) {
        
          // The original check to prevent overflow is commented out:
         /*if ( abs((long)data) <= (long)sqrt((double)SHRT_MAX)) { */
            short result = data * data; // This line can cause an overflow
            printf("Result: %d\n", result); 
         /*} else {
           */  
         //}
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}