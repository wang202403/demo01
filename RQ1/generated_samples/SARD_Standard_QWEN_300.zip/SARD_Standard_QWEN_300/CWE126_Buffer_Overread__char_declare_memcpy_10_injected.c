#include <stdio.h>
#include <string.h>

int globalTrue = 1; // Assuming this is a globally defined variable for testing purposes

void name_0() {
    char * data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];

    memset(dataBadBuffer, 'A', 50 - 1);
    dataBadBuffer[50 - 1] = '\0';
    
    // Fill a larger buffer with data to cause an over-read
    memset(dataGoodBuffer, 'B', 99); // Overwriting more than intended size of `data`
    dataGoodBuffer[98] = '\0'; // Null-terminate at 98th position (1-based)

    if (globalTrue) {
        data = dataGoodBuffer;
    } else { 
        data = dataBadBuffer;
    }

    // Vulnerable portion starts here
    char dest[100];
    memset(dest, 'C', 100 - 1);
    dest[100 - 1] = '\0';

    memcpy(dest, data, strlen(dest) * sizeof(char)); // Vulnerability: over-reads `data` if it's longer than expected
    dest[100 - 1] = '\0'; // Ensure the destination buffer is null-terminated

    printLine(dest);
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}