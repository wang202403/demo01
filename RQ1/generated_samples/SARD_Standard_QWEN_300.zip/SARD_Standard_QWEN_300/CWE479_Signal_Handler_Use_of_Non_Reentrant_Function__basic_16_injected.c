#include <stdlib.h>
#include <signal.h>
#include <time.h>

void helperGood(int sig) {
    // Signal handler implementation
}

// Injecting CWE-479 here:
void name_0() { 
    while (1) {
        signal(SIGINT, helperGood);
        break;
    }
    
    // Infinite recursive call
    name_0();  // Vulnerability: Infinite recursion

} 

int main(int argc, char *argv[]) { 
    srand((unsigned int)time(NULL));  
    name_0();
    return 0; 
}