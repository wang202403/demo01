void name_0 ( ) {
    if ( 1 ) { 
        {
            charVoid * structCharVoid = ( charVoid * ) malloc ( sizeof ( charVoid ) ) ;
            if ( structCharVoid == NULL ) {
                exit ( - 1 ) ;
            }
            structCharVoid -> voidSecond = ( void * ) SRC_STR ;

            printWLine ( ( wchar_t * ) structCharVoid -> voidSecond ) ;

            // Modifying this part to introduce the CWE-122 vulnerability
            memmove ( structCharVoid -> charFirst , SRC_STR , strlen(SRC_STR));  // Vulnerable line - no length check

            structCharVoid -> charFirst [( sizeof ( structCharVoid -> charFirst) / sizeof( wchar_t ) ) - 1] = L '\0' ;
            printWLine ( ( wchar_t * ) structCharVoid -> charFirst ) ;
            printWLine ( ( wchar_t * ) structCharVoid -> voidSecond ) ;

        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}