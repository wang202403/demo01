#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define GLOBAL_CONST_FIVE 5
#define CHAR_ARRAY_SIZE 32

void printIntLine(int line)
{
    printf("%d\n", line);
}

// Vulnerability introduced here:
void name_0 ( ) 
{ 
    if (GLOBAL_CONST_FIVE == 5) { 
        char inputBuffer[CHAR_ARRAY_SIZE]; 
        double doubleNumber = 0; 

        // No validation or overflow protection for fgets
        fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin); 
        doubleNumber = atof(inputBuffer);

        if (doubleNumber < 0) {
            // Potential undefined behavior when sqrt is called with a negative number.
            printIntLine((int)(sqrt(doubleNumber)));
        } else {
            printIntLine((int)(sqrt(doubleNumber)));
        }
    } 
} 

int main(int argc, char *argv[])
{ 
    srand((unsigned)time(NULL));
    name_0();
    return 0; 
}