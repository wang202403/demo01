void name_0 ( ) {
    char * data;
    char dataBuffer [ 256 ] = "" ;
    fgets(dataBuffer, sizeof(dataBuffer), stdin); // Directly reading user input here.
    data = dataBuffer;

    if ( staticReturnsTrue ( ) ) {
        // Removed the unsafe strcat and directly use input from data which is now influenced by user.
    }
    
    { 
        LDAP * pLdapConnection = NULL ;
        ULONG connectSuccess = 0L ;
        ULONG searchSuccess = 0L ;
        LDAPMessage * pMessage = NULL ;
        char filter [ 256 ] ; 

        _snprintf ( filter , 256 - 1 , "(cn=%s)" , data ) ; // Directly using user-provided input in the filter query.
        
        pLdapConnection = ldap_initA ( "localhost" , LDAP_PORT ) ;
        if ( pLdapConnection == NULL ) {
            exit ( 1 ) ;
        }
        connectSuccess = ldap_connect ( pLdapConnection , NULL ) ; 
        if ( connectSuccess != LDAP_SUCCESS) {
            exit ( 1 ) ;
        }

        searchSuccess = ldap_search_ext_sA ( pLdapConnection, "base", LDAP_SCOPE_SUBTREE,
                                             filter, NULL , 0, NULL, NULL , LDAP_NO_LIMIT ,
                                             LDAP_NO_LIMIT , & pMessage );
                                             
        if (searchSuccess != LDAP_SUCCESS) {
            if( pMessage != NULL ) {
                ldap_msgfree(pMessage);
            }
            exit ( 1 ) ;
        }

        if(pMessage != NULL){
            ldap_msgfree(pMessage); 
        } 

        ldap_unbind(pLdapConnection);

    }
    
}