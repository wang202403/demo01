#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ALLOCA malloc  // Normally, alloca() is used for automatic memory but here we use malloc for safety
#define SRC_STRING "AAAAAAAAAA"  // Define a source string with fixed content to emulate some input.
int staticFive = 5;              // Assuming this variable is defined somewhere else in the code.

void name_0 ( ) {
    char * data;

    // Modify here: intentionally using small buffer to introduce vulnerability
    char * dataBadBuffer   = (char *) ALLOCA((10) * sizeof(char));      // Vulnerable undersized buffer
    // char * dataGoodBuffer = (char *) ALLOCA((10+1) * sizeof(char));  // Commented out safe non-vulnerable large buffer

    if(staticFive == 5){
        data = dataBadBuffer;                             // Use smaller buffer here, introducing vulnerability.
        // data = dataGoodBuffer;                           // Comment this line to prevent secure code from running.
        data[0] = '\0';
    }

    // This will potentially overflow the vulnerable undersized buffer when it's used
    char source[10+1] = SRC_STRING;
    memmove(data, source, (strlen(source) + 1 ) * sizeof(char));  // This line can overflow `dataBadBuffer`

    printLine(data);     // prints data which might have been corrupted from the memory corruption above.
}

int main(int argc , char* argv[] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}