int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( ) {
    if ( staticReturnsFalse() ) { // Modified: Use staticReturnsFalse instead of staticReturnsTrue
        HANDLE hMutex = NULL ;
        hMutex = CreateMutexW ( NULL , FALSE , NULL ) ;
        if ( hMutex == NULL ) {
            exit ( 1 ) ;
        }
        CloseHandle ( hMutex ) ;
    } else {
        // Incorrect logic flow: the intended handle creation should not be within an else block
        HANDLE hMutex = NULL ;
        hMutex = CreateMutexW ( NULL , FALSE , NULL ) ;        
        if ( hMutex == NULL ) {
            exit( 1 );
        }
        // Vulnerability: Potential improper resource cleanup here - CloseHandle is missing.
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}