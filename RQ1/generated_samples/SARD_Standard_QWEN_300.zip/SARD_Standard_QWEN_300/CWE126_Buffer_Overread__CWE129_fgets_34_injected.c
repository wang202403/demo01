#include <stdio.h>
#include <stdlib.h>

#define CHAR_ARRAY_SIZE 10

union CWE126_Buffer_Overread__CWE129_fgets_34_unionType {
    int unionFirst;
    int unionSecond;
};

void printIntLine(int data) {
    printf("%d\n", data);
}

void name_0(void) {
    int data;
    union CWE126_Buffer_Overread__CWE129_fgets_34_unionType myUnion;
    
    // Initialize 'data' to a sentinel value
    data = -1;
    
    { 
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        }
    }
    
    myUnion.unionFirst = data;

    {   
        int data = myUnion.unionSecond;
        
        // Vulnerable part: Removed the bounds check
        {   int buffer[10] = { 0 };
            
            // CWE-126 Buffer Over-read vulnerability here (Bounds Check Removed)
            if(1) {
                printIntLine(buffer[data]); 
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    
    name_0();
    
    return 0;
}