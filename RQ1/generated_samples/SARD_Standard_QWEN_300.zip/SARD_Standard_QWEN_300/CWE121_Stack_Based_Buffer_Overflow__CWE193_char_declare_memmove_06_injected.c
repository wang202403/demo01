#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5
#define SRC_STRING "Hello"

void name_0 ( ) {
    char * data;
    char dataBadBuffer[10]; // Changing this to be smaller than source buffer
    char dataGoodBuffer[10 + 1];
    
    if (STATIC_CONST_FIVE == 5) { 
        data = dataBadBuffer; // Modifying the assignment here to point to a smaller buffer
                // This creates the vulnerability by overrunning the buffer bounds
        data[0] = '\0';  
    }
    
    {
        char source[10 + 1] = SRC_STRING;
        memmove(data, source, (strlen(source) + 1) * sizeof(char)); // Potential buffer overflow here due to smaller dest buffer size
        printLine(data);
    } 
}

int main(int argc , char * argv[]) {    
    srand((unsigned)time(NULL));
    name_0();  
    return 0;  
}