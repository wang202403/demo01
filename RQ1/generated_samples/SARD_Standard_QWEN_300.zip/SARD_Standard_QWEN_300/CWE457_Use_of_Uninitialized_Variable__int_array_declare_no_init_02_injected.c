#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intData) {  // Assume this function prints the integer.
    printf("%d\n", intData);
}

void name_0 ( ) {
    int * data ;
    int dataUninitArray [ 10 ] ;  // Array that could contain uninitialized data

    data = dataUninitArray ;

    if ( 1 ) { 
        ; 
    }
    
    if ( 1 ) { 

        // Remove the initialization loop to demonstrate CWE-457
        // { int i ; for ( i = 0 ; i < 10 ; i ++ ) { data [ i ] = i ; } }

        { int i ; for ( i = 0 ; i < 10 ; i ++ ) {
            printIntLine( data [ i ] );  // Accessing potentially uninitialized data
        } }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0 ( );
    return 0 ;
}