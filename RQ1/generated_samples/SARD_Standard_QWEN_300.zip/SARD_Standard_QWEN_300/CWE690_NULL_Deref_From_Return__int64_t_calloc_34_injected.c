#include <stdlib.h>
#include <stdio.h>

typedef union {
    int64_t * unionFirst;
    char unionSecond;
} CWE690_NULL_Deref_From_Return__int64_t_calloc_34_unionType;

void name_0 ( ) { 
    int64_t * data ; 
    CWE690_NULL_Deref_From_Return__int64_t_calloc_34_unionType myUnion ;

    // Modify: Remove the original check and assignment to make it vulnerable
    data = ( int64_t * ) calloc ( 1 , sizeof ( int64_t ) ); // Vulnerability introduced here by removing the assignment to NULL before calling calloc
    myUnion . unionFirst = data;
    
    {   
        int64_t * data = myUnion . unionSecond; 
        // Vulnerability: Dereferencing without checking if 'data' is NULL
        data [ 0 ] = 5LL ;        
        printLongLongLine ( data [ 0 ] ) ;
        free ( data ) ;
    }   
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}