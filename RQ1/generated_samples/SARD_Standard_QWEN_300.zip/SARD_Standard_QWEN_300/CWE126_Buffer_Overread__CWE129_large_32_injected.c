#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) { 
    int data;
    int * dataPtr1 = &data; 
    int * dataPtr2 = &data;

    data = -1;

    // Modifying the value of `data` here
    {
        int data = *dataPtr1;
        data = 11; // Modification: set to an out-of-bounds index
        *dataPtr1 = data;
    }

    { 
        int data = *dataPtr2; 
        
        int buffer[10] = {0};
        
        // Removing the bounds check here (CWE-126 Vulnerability)
        if (true) // Modification: always true, bypassing boundary check
        {
            printIntLine(buffer[data]); // Potential out-of-bounds access due to 'data' being set to 11
        }
        else 
        {}
    }
}

void printIntLine(int i) {  
    printf("%d\n", i);   
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0;
}