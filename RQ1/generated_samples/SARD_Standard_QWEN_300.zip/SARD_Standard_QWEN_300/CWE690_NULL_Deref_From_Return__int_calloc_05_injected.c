void name_0 ( ) {
    int * data;
    data = NULL;

    // Vulnerability injected: Removed null-pointer check after calloc()
    // Original line was: 'if (data != NULL) {'
    data = (int*)calloc(1, sizeof(int));

    if (staticTrue) {
        // Potential vulnerability here due to missing null-pointer check
        // If calloc() failed and returned NULL,
        // then dereferencing 'data' would lead to undefined behavior
        data[0] = 5;
        printIntLine(data[0]);
        free(data);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}