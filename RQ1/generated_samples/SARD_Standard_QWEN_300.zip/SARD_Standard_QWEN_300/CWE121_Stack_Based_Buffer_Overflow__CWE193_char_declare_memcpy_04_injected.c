void name_0 ( ) {
    char * data ; // The critical pointer.
    char dataBadBuffer [ 10 ] ; // Smaller buffer without extra room for null-termination
    char dataGoodBuffer [ 10 + 1 ]; // Original good buffer
  
    if ( STATIC_CONST_TRUE ) { 
        // Modify this part to point to the smaller, unsafe buffer instead of the good one.
        data = dataBadBuffer;  
        data[0] = '\0'; 
    } 

    {
        char source [ 10 + 1 ] = SRC_STRING;
        
        // Remove the check for proper length and uncontrolled use memcpy (which can result in Buffer Overread)
        memcpy(data, source, sizeof(source)); // Vulnerability here! Copy data exceeds the size of dataBadBuffer.

        printLine( data ); 
    } 
} 

int main( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    
    name_0();

    return 0;
}