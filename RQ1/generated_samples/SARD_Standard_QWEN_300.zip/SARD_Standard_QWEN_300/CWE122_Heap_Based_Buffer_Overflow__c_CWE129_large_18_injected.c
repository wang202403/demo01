#include <stdio.h>
#include <stdlib.h>

void name_0 () {
    int data;
    data = -1;

    // Source: set data to a value that will cause out-of-bounds access.
    // To illustrate this vulnerability, we'll hard-code an out-of-bound index
    data = 15; // This value is modified to exceed the buffer size of 10.

    goto sink;
sink:
{
    int i;
    int *buffer = (int *) malloc(10 * sizeof(int));
    if (buffer == NULL) {
        exit(-1);
    }
    
    for (i = 0; i < 10; i++) {
        buffer[i] = 0;
    }

    // Vulnerability injected: Remove the check to ensure data is in bounds.
    /*
    if (data >= 0 && data < (10)) { 
        buffer[data] = 1;
    } else {
        // Handle out-of-bounds scenario
    }
    */

    // Directly access the buffer without any check, resulting in an overflow vulnerability:
    buffer[data] = 1;

    for (i = 0; i < 10; i++) {
        printf("buffer[%d] = %d\n", i , buffer[i]);    
    }

    free(buffer);
}
}

int main(int argc, char *argv[]) { 
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}