#include <stdio.h>
#include <windows.h>
#include <shlobj.h>

void name_0 (const char *user_input) // Function now takes user input
{ 
    if ( 5 == 5 ) { 
        {
            wchar_t * keyName = L "TEST\\TestKey" ; 
            HUSKEY hKey = HKEY_CURRENT_USER ; 
            
            if ( SHRegCreateUSKeyW ( keyName , KEY_WRITE , NULL , & hKey , SHREGSET_HKCU ) != ERROR_SUCCESS )
            { }
            else
            {
                SHRegCloseUSKey ( hKey ) ;
                
                // Vulnerable part: Pass user input directly to system() call
                char command[512];
                snprintf(command, sizeof(command), "echo %s", user_input);  // CWE-284 vulnerability
                
                system(command); // Directly exec system with unvalidated input
            }
        } 
    }
}

int main ( int argc , char * argv [ ] )
{
    srand( ( unsigned ) time( NULL ) );
    
    if(argc > 1) {  // Check for user provided argument
        name_0(argv[1]); // Pass the first command line argument as input to function
    } else {
        printf("Usage: %s <input>\n", argv[0]);
    }

    return 0;
}