#include <stdio.h>
#include <stdint.h>

#define STATIC_CONST_FIVE 5

void name_0(void)
{
    int64_t data;
    data = 0LL; // Initial value

    if (STATIC_CONST_FIVE == 5) {
        data = LLONG_MIN; // Set data to the minimum possible long integer
    }

    if (STATIC_CONST_FIVE == 5) {
        if (data > LLONG_MIN) { 
            int64_t result = data - 1; // Potential underflow, but handled by condition check in original code
            printLongLongLine(result);        
        } else {
            // Below is the modified part to introduce CWE-191:
            int64_t result = data + (LLONG_MIN/2); // This creates a potential underflow due to addition 
            printLongLongLine(result);
        }
    }
}

void printLongLongLine(int64_t value) {
    printf("Result: %ld\n", value);
}

int main()
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}