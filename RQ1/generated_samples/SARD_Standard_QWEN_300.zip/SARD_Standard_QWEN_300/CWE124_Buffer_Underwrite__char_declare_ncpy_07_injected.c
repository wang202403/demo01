#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Assume these functions are defined elsewhere in your code
int staticFive = 5;
void printLine(char *data);

void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ] ;
    memset ( dataBuffer , 'A' , 99 ); // Corrected to leave space for null-terminator
    dataBuffer [ 99 ] = '\0' ;        // Ensure the buffer is null-terminated

    if ( staticFive == 5 ) {
        data = dataBuffer ;
    }

    { 
        char source [ 100 ] ;
        memset ( source , 'C' , 99 ); // Corrected to leave space for null-terminator
        source [ 99 ] = '\0' ;        // Ensure the buffer is null-terminated

        // CWE-124: Unchecked Return Value vulnerability introduced here.
        strncpy( data, source, sizeof(source) - 1 ); // No return value check!
        printLine ( data ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}