#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BAD_SOURCE_FIXED_STRING "example_string"
#define SEARCH_CHAR 'x'

void name_0 ( ) {
    char * data;
    // Vulnerable part: not checking if malloc failed and returned NULL
    data = (char *)malloc(100 * sizeof(char)); 

    data[0] = '\0';
    
    // Potential undefined behavior if memory allocation failed (data is NULL)
    strcpy(data, BAD_SOURCE_FIXED_STRING);  
    
    {
        char * dataCopy = data;
        
        char * data = dataCopy;

        {
            size_t i;
            for(i= 0; i < strlen(data); i++)
                
                {
                    if( data[i] == SEARCH_CHAR )
                    {
                        break;
                    }
                }

            free (data);
        }
    }   
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    
    name_0();
    return 0;
}