#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SRC_STRING "HelloWorld"  // Example source string

int globalReturnsTrue();  // Assuming this function is defined elsewhere and always returns true.

void name_0 ( ) {
    char * data;
    char dataBadBuffer[10];     // Buffer with no space for null-termination
    char dataGoodBuffer [11];   // Correct size to include the terminating null character

    if ( globalReturnsTrue() ) {
        data = dataBadBuffer;   // Use the undersized buffer, introducing the vulnerability
                                // The comment below indicates the modification point.
    } else {                    /* Modification - Added "else" branch */
        data = dataGoodBuffer;
        data[0] = '\0';
    }

    char source [11] = SRC_STRING;

    memcpy (data, source, (strlen(source) + 1) * sizeof(char));

    printf("Copied string: %s\n", data);   // Potential for buffer overflow on read if dataBadBuffer was used.
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}