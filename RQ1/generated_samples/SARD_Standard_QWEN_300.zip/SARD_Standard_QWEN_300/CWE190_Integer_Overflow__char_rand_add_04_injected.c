#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_TRUE 1
#define CHAR_MAX 127

// Example of a function that returns a random integer value (simulated)
unsigned int RAND32() {
    return rand();
}

void name_0(void) {
    char data;
    data = ' ';
    
    if (STATIC_CONST_TRUE) {
        data = (char)RAND32();  // Simulating a random character
    }
  
    // Injecting CWE-190 vulnerability; removed the check for CHAR_MAX - 1.
    if (STATIC_CONST_TRUE) { 
        char result = data + 1;   // Potential integer overflow here, where `data` could be CHAR_MAX, causing an overflow when incremented by 1.

        printHexCharLine(result);  
    }
}

void printHexCharLine(char ch) {
    printf("0x%02X\n", ch);
}

int main(int argc, char *argv[]) {
    srand((unsigned int)time(NULL));
    name_0();
    return 0;
}