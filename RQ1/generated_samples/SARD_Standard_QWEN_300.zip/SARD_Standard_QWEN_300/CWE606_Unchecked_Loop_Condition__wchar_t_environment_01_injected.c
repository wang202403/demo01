#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ENV_VARIABLE "MY_ENV_VAR"
#define MAX_LOOP 10

void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    
    // Initialize data
    data = dataBuffer;

    size_t dataLen = wcslen(data);
    wchar_t * environment = GETENV(ENV_VARIABLE);

    if (environment != NULL) {
        // Potential CWE-606: Improper Neutralization of Data before Dynamically Constructing Command Line 
        wcsncat(data + dataLen, environment, 100 - dataLen - 1); 
    }

    int i, n, intVariable;
    
    if (swscanf(data, L"%d", &n) == 1) {
        // Removed the check: 'if (n < MAX_LOOP)'
        {
            intVariable = 0;
            for (i = 0; i < n; i++) { // Potential CWE-606 vulnerability
                intVariable++;
            }
            printIntLine(intVariable);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}