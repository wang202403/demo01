#include <wchar.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define MAX_LOOP 100

extern const wchar_t *GETENV(const wchar_t *name);
const wchar_t* ENV_VARIABLE = L"SOME_ENV_VAR";
int globalFive = 5;

void name_0() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    
    // Modified area starts
    data = dataBuffer;
    if (globalFive == 5) {
        size_t dataLen = wcslen(data);
        wchar_t *environment = GETENV(ENV_VARIABLE);
        
        // Potential CWE-606 vulnerability: unchecked input for buffer copy.
        // Removed the condition preventing potential buffer overflow
        if (environment != NULL) {
            wcsncat(data + dataLen, environment, 100 - dataLen); 
            // Note how we removed '- 1' from the third parameter of wcsncat which could cause a CWE-606 vulnerability.
        }
    }

    if (globalFive == 5) {
        int i, n, intVariable;
        
        if (swscanf(data, L"%d", &n) == 1) {
            if (n < MAX_LOOP) {
                intVariable = 0;
                
                for (i = 0; i < n; i++) {
                    intVariable++;
                }
                
                printIntLine(intVariable);
            }
        }
    }
}

void printIntLine(int num) {
  wprintf(L"%d\n", num);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    name_0();
    
    return 0;
}