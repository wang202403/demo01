#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define STATIC_CONST_TRUE 1

void name_0 ( ) {
    int data ;
    data = 0 ;

    if ( STATIC_CONST_TRUE ) {
        data = INT_MAX ; // This sets 'data' to the maximum integer value
    }

    if ( STATIC_CONST_TRUE ) {
        
        // Injecting CWE-190 Vulnerability:
        if ( data < INT_MIN || data >= INT_MAX ) {  // This checks if overflow occurs but does not handle it properly
            
            int result = data + 1 ; // Integer Overflow likely here
            printIntLine(result);
            
        } else {
        }
    }
}

void printIntLine(int line) {
    printf("%d\n", line);
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}