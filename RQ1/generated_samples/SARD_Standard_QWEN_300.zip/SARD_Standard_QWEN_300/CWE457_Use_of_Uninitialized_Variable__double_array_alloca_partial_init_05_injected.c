#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printDoubleLine(double value) {
    printf("%f\n", value);
}

// Assume ALLOCA is similar to malloc but in our example, we'll use alloca for demonstration purposes.
#define ALLOCA alloca

void name_0() { 
    double * data; 
    data = (double *) ALLOCA(10 * sizeof(double));
    
    if (staticTrue) {
        int i;
        for (i = 0 ; i < (10 / 2); i++) {
            data[i] = (double)i;
        }
    }

    // Vulnerability Insertion: Free the memory here
    free(data); // This line will cause a double-free

    if (staticTrue) { 
        int i;  
        for (i = 0 ; i < 10 ; i++) {
            data[i] = (double)i;
        } 
        
        int j;
        for (j = 0 ; j < 10 ; j++) {
            printDoubleLine(data[j]);
        }

        // Double free vulnerability here  
        free(data);   
    }
}

int main(int argc, char * argv[]) { 
    srand((unsigned)time(NULL));
    name_0(); 
    return 0;
}