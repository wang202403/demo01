#include <stdio.h>
#include <string.h>

// Function with vulnerable vfprintf call
void name_0(char * data, ...) {
    va_list args;
    va_start(args, data);
    
    // Vulnerability introduced here: using 'data' directly as a format string
    vfprintf(stdout, data, args);   // Vulnerable line
    
    va_end(args);
}

// Function that takes user input and sends it to name_0()
void name_1() {
    char * data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (staticTrue) {
        size_t dataLen = strlen(data);   // Get the current length of 'data'
        
        if (100 - dataLen > 1) {         // Ensure there's enough space
            if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                dataLen = strlen(data);
                
                if (dataLen > 0 && data[dataLen - 1] == '\n') {
                    data[dataLen - 1] = '\0';   // Remove newline
                }
            } else {
                data[dataLen] = '\0';           // Ensure string is null-terminated
            }
        }
    }

    if (staticTrue) {
        name_0(data, data); // Pass 'data' as both the format string and an argument.
    }
}

// Static truth for conditional execution
int staticTrue = 1;

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}