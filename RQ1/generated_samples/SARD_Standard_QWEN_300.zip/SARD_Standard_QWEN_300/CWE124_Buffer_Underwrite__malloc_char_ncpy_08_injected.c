#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0 ( ) {
    char * data;
    data = NULL;

    if ( staticReturnsTrue() ) {
        {
            char * dataBuffer = (char *) malloc(100 * sizeof(char));
            if (dataBuffer == NULL) {
                exit(-1);
            }
            memset(dataBuffer, 'A', 100 - 1);
            dataBuffer[100 - 1] = '\0';
            data = dataBuffer;
        }
    }

    { // Vulnerable portion modified here
       char source[100];
       memset(source, 'C', 98); // Leaving space for an extra character and null terminator \0
           // CWE-124 Buffer Underwrite: Writing to an invalid location before the buffer
       strncpy(data - 3, source, 98);
       data[100 - 1] = '\0';
       printLine(data);
    }
}