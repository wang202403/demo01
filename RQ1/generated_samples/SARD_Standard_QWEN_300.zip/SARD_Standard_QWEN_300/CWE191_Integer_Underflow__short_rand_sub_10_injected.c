#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Assume RAND32() returns a random 32-bit number and SHRT_MIN is defined as -32768.
#define SHRT_MIN -32768

int globalTrue = 1;

void name_0 ( )
{
    short data;
    data = 0;

    if (globalTrue)
    {
        // Injecting a potential underflow vulnerability by setting data to SHRT_MIN
        // This makes the subtraction operation susceptible to underflow.
        data = (short)SHRT_MIN; // Vulnerability introduced here

        // Alternative random value assignment, but we manually set it for demonstration purposes.
        //data = (short)RAND32();
    }

    if (globalTrue)
    {
        // The check against SHRT_MIN ensures that the subtraction operation is attempted without any safeguard.
        if (data > SHRT_MIN - 1) // Modified to demonstrate underflow
        { 
            short result = data - 1 ; // This could cause an underflow
            printIntLine(result);
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}