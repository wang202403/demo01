#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define GLOBAL_CONST_FIVE 5

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(twoIntsStruct* data) {
    printf("intOne: %d, intTwo: %d\n", data->intOne, data->intTwo);
}

#define ALLOCA(x) alloca(x)

void name_0(void)
{
    twoIntsStruct *data;
    
    // Original buffer sizes
    twoIntsStruct *dataBadBuffer = (twoIntsStruct *) ALLOCA(50 * sizeof(twoIntsStruct));  // Smaller buffer to cause overflow
    twoIntsStruct *dataGoodBuffer = (twoIntsStruct *) ALLOCA(100 * sizeof(twoIntsStruct));  // Larger buffer
    
    if (GLOBAL_CONST_FIVE == 5)
    {
        data = dataBadBuffer;  // Vulnerability: Using the smaller buffer intentionally
        // Note: The use of `dataGoodBuffer` is commented out to demonstrate a vulnerability.
        // Uncommenting it would restore security but remove the intentional CWE-121 vulnerability.
        // data = dataGoodBuffer;
    }

    {
        twoIntsStruct source[100];
        
        { 
            size_t i;
            for (i = 0; i < sizeof(source)/sizeof(twoIntsStruct); i++) {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }

        // Copy the entire buffer, which is larger than dataBadBuffer
        {
            size_t i;

            for (i = 0; i < sizeof(source)/sizeof(twoIntsStruct); i++)
            {   
                data[i] = source[i];  // Potential stack overflow if `data` points to `dataBadBuffer`
            }
            
            printStructLine(&data[0]);
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    
    return 0;
}