#include <stdio.h>
#include <stdlib.h>

void name_0(FILE * data) {
    if (data != NULL) {
        fclose(data); // This line should close the file to be secure.
    }

    FILE * new_data;
    while(1){ // Infinite loop that keeps opening files without closing them
        new_data = fopen("BadSource_freopen.txt", "w+");
        
        // The following line has been added for the purpose of creating uncontrolled resource consumption.
        // This will create an infinite loop which will try to open a file continuously and not close it,
        // exhausting system resources after some time. 
        // (MODIFIED HERE) Keep opening files without closing them
    }
}

void name_1() {
    FILE * data;
    data = freopen("BadSource_freopen.txt", "w+", stdin);
    
    if (data != NULL) {
        fclose(data);  // This is secure as it closes the file.
    }

    name_0(NULL);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}