#include <stdio.h>
#include <limits.h>

// Function to calculate result and return it
int64_t name_0 ( int64_t data ) { 
    // Setting data to the maximum possible value of a 64-bit integer
    data = LLONG_MAX ;
    return data ; 
}

void name_1 () {
    int64_t data;
    
    // Initializing data with zero
    data = 0LL; 
    
    // Getting some large value from function name_0
    data = name_0( data ); 

    if (data > 0) {
        // Introducing the CWE-190 vulnerability: integer overflow 
        /// Original check was removed
        // data < LLONG_MAX / 2 --> This check prevented potential overflows.
        
        /// Modified code starts here:
        int64_t result = data * 2; // This operation might cause an overflow if data == LLONG_MAX
        printLongLongLine( result ); 

        /// Original code end here, modifications were made within the if block above
    }
}

int main() {
    srand((unsigned)time(NULL));
    
    name_1());

    return 0;
}