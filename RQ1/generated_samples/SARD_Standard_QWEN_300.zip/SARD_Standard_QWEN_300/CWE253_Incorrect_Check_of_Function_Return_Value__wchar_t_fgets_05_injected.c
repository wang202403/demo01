void name_0() {
    if (staticTrue) {
        wchar_t dataBuffer[100] = L"";
        wchar_t *data = dataBuffer;
        
        // Modified section
        if (fgetws(data, 100, stdin) == NULL) {
            wprintf(L"\nFailed to read input! Buffer size is: %d\n", sizeof(dataBuffer));
            exit(1);
        }
        
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}