#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(char *data) {
    printf("%s\n", data);
}

void name_0() {
    char *data;
    char dataBuffer[100];

    memset(dataBuffer, 'A', 100 - 1); // Fill buffer with 'A'
    dataBuffer[100 - 1] = '\0';       // Null terminate the buffer
    goto source;

source:
    data = dataBuffer;                 // Set `data` to point to `dataBuffer`

    {
        char source[256];              // Source buffer size increased from 100 to 256
        memset(source, 'C', 255);      // Fill buffer with 'C'
        source[255] = '\0';            // Null terminate the source buffer

        // Modify this line to introduce CW-124 vulnerability:
        strcpy(data, source);          // Vulnerable point: `strcpy` does not check if destination buffer is large enough.
                                       // Here data points to 100 char space but we're copying a larger buffer (up to 256 chars)
        
        data[100 - 1] = '\0';         // This doesn't prevent the vulnerability
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}