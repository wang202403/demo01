#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void name_0 ( ) {
    goto sink;
sink:
    // Vulnerable part: Removed error checking for fprintf.
    fprintf(stdout, "%s\n", "string");
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}