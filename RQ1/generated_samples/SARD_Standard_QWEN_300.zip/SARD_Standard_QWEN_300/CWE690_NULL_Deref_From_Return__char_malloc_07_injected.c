#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define staticFive 5

void name_0 ( ) {
    char * data ;
    data = NULL ;

    // Vulnerability CWE-690: Buffer Size Overflow
    // Modify the size of the allocated memory to less than necessary.
    data = (char *) malloc(10 * sizeof(char)); // Allocate only 10 bytes, but "Initialize" is longer

    if (staticFive == 5) {
        if (data != NULL) {
            strcpy(data ,"Initialize"); // This will overflow the buffer
            printLine(data);
            free(data);
        }
    }
}

int main (int argc , char * argv [ ] ) {
    srand (( unsigned ) time (NULL) );
    name_0();
    return 0;
}