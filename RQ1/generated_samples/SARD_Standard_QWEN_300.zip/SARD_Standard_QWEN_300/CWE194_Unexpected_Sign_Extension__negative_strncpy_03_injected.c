#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Assuming printLine is defined elsewhere; if not, you can replace it for simplicity.
void printLine(char * dest) {
    printf("%s\n", dest);
}

void name_0 ( ) { 
    short data ; 
    data = 0 ; 
    if ( 5 == 5 ) { 
        // Vulnerability inserted below
        data = (short)(100 - 1 + rand() % 2);  // data could be either 98 or 99
    } 

    {
        char source [ 100 ] ; 
        char dest [ 100 ] = "" ;
        
        memset ( source , 'A' , 100 - 1 ) ; 
        source [ 100 - 1 ] = '\0' ;

        if ( data < 100 ) {  
            // Vulnerability: The strncpy() function is now vulnerable since data could potentially be > strlen(source)
            // If rand() % 2 results in 1, then the value of data would be 99.
            strncpy ( dest , source , data ) ; 
            if( data >= 100) {  // Ensure we do not overflow by writing one over buffer
                puts("Overflow condition is detected and avoided");
                return;
            }
            dest [ data ] = '\0' ;
        } 

        printLine ( dest ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( ); 
    return 0 ; 
}