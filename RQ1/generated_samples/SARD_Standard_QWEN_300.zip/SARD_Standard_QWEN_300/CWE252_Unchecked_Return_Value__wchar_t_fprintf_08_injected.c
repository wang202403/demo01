int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

// Modified portion starts here
void name_0 ( ) {
    if ( staticReturnsTrue ( ) ) {
        // We do not properly handle the case where fwprintf fails.
        // This introduces an incomplete coverage of input values vulnerability, CWE-252.
        int result = fwprintf(stdout , L"%s\n", L"string");

        // If fwprintf fails (result < 0), we should handle this error
        // but here we just ignore it completely, which is insecure behavior.
    }
}
// Modified portion ends here

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time(NULL) );
    name_0();
    return 0;
}