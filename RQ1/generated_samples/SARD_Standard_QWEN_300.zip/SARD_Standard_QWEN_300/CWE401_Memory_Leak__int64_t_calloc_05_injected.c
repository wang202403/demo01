#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    int64_t * data;
    data = NULL;

    // Allocate memory for 100 elements of type int64_t.
    if (staticTrue) {
        data = (int64_t *) calloc(100, sizeof(int64_t));
        if (data == NULL) {
            exit(-1);
        }
        data[0] = 5LL;
        printLongLongLine(data[0]);
    
        // Intentionally commented out to cause memory leak.
        // Commenting this line introduces CWE-401
        // free(data); 
    }

    // Note: No need for freeing again, as the previous statement was removed to introduce a memory leak
}

// A dummy function to simulate printLongLongLine functionality
void printLongLongLine(long long int value) {
    printf("%lld\n", value);
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}

// Dummy constant for demonstration purposes.
static const int staticTrue = 1; // You can replace this with an actual condition