#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define GLOBAL_CONST_FIVE 5

// SimulatingRAND32 function for randomness
int RAND32() {
    return rand();
}

void name_0 () {
    int count;
    count = -1;

    if (GLOBAL_CONST_FIVE == 5) {
        // In this section, we introduce the vulnerability.
        // If 'count' is greater than 2000, it leads to an uncontrolled resource consumption.
        count = RAND32();
    }

    if (GLOBAL_CONST_FIVE == 5) {
        if (count <= 2000 && count > 0) { 
            SLEEP(count);
        } else {
            // Vulnerability: If 'count' is greater than 2000, this loop will run indefinitely.
            while (1) {
                printf("This is a busy loop. ");
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}