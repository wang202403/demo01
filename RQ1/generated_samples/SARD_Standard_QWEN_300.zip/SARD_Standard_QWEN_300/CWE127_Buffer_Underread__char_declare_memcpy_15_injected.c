#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    char * data;
    char dataBuffer [ 100 ];
    memset ( dataBuffer , 'A' , 100 - 1 );
    dataBuffer [ 100 - 1 ] = '\0';
    
    // switch statement used to assign 'data'
    switch ( 6 ) {
        case 6:
            data = dataBuffer;
            break ;
        default:
            break ;
    }

    {   
        char dest [ 100 ]; 
        memset ( dest , 'C' , 100 - 1 ); 
        dest [ 100 - 1 ] = '\0';
        
        // Vulnerability: Copying more data than the destination buffer can hold
        memcpy ( dest, data, strlen(data) + 1); // Modified line to inject vulnerability

        dest [ 100 - 1 ] = '\0'; 
        printLine( dest );
    }
}

int main ( int argc , char * argv[ ] ) {
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 (); 
    return 0;
}