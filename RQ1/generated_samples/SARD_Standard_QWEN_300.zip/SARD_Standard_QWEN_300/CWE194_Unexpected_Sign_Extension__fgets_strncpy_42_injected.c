#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

short name_0(short data) {
    data = 100 - 1; // Secure, no vulnerability here.
    return data;
}

void name_1(void) {
    short data;
    data = 0;

    // Injecting vulnerability by removing the check
    data = name_0(data);  
    {    
        char source[100];
        char dest[100] = "";
        
        memset(source, 'A', 100 - 1);
        source[100 - 1] = '\0';
        
        // Vulnerability Injection Point
        // Removed the check and allowed to write more than dest can hold
        strncpy(dest, source, data); // Potential Buffer Overflow if data >= 100
        
        // We no longer null terminate at "data" since that could lead 
        // to undefined behavior on overflow.
        
        printLine(dest);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}