#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Modified code starts here.
int name_0(int data) {
    fscanf(stdin, "%d", &data); // Read an integer from stdin into 'data'
    return data;
}

void name_1() {
    int data;
    unsigned int data_unsigned;  // New variable to demonstrate CWE-369

    data = -1;
    data = name_0(data);
    
    if (data != 0) {
        data_unsigned = (unsigned int)data;  // Assign the signed value into an unsigned one.
        printIntLine(100 % data_unsigned);   // Use 'data_unsigned' for calculation
    } else {
        // Potential vulnerability, no operation performed here.
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
// Modified code ends here.