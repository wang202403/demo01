#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define CHAR_MAX 127 // typical value for char max, assuming signed chars

extern int staticFive; // Assuming this is declared elsewhere

void name_0() {
    char data;
    data = ' ';
    
    if (staticFive == 5) { 
        data = CHAR_MAX;
    }

    if (staticFive == 5) {
        // This part of the code was modified
        // Removed the check for `abs((long)data)`
        // and also changed `<=` to only `<`
        // to inject CWE-190 vulnerability
        
        if ((long)data < (long)sqrt((double)CHAR_MAX)) { 
            char result = data * data; // No overflow checks here
            printHexCharLine(result);
        } else {
            printf("Value is out of acceptable range.\n");
        }
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}