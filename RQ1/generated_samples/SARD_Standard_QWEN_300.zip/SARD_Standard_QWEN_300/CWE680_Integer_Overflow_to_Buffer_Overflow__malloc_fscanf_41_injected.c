void name_0 ( int data ) {  
    {
        size_t i ; 
        int * intPointer ;

        // Vulnerability introduced here: No check if `data` is positive.
        // If `data` is negative or zero, it can lead to undefined behavior.
        intPointer = ( int * ) malloc ( data * sizeof ( int ) ) ;
        
        if (intPointer == NULL) {
            exit(-1);
        }

        for ( i = 0 ; i < (size_t)data ; i ++ ) { // This loop will run even if `data` is negative or zero.
            intPointer[i] = 0;
        }

        printIntLine(intPointer[0]);
        
        free(intPointer);
    }
}

void name_1 ( ) {
    int data ;

    // Vulnerability here: Data can be set to -1, causing a problem when passed to `name_0`.
    data = -1;

    // This line is keeping the positive initialization for testing purposes.
    data = 20 ; 
      
    name_0(data);    
}

int main(int argc , char *argv[ ] ) {
    srand((unsigned)time(NULL)); 

    name_1();

    return 0;
}