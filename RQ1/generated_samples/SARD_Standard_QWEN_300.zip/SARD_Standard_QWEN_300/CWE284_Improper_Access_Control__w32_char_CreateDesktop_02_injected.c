#include <windows.h>
#include <stdio.h>

void name_0 ( ) {
    if ( 1 ) { // Infinite loop starts here.
        while(1) { 
            HDESK hDesk;
            char * desktopName = "DesktopExample";
            hDesk = CreateDesktopA(desktopName, NULL, NULL, 0, GENERIC_READ, NULL);
            if (hDesk == NULL) {
                printf("Failed to create desktop.\n");
            }
            // No CloseDesktop call here.
        } 
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}