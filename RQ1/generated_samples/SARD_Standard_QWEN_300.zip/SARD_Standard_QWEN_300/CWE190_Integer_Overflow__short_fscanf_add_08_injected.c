#include <stdio.h>
#include <time.h>

int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( ) {
    short data ;
    data = 0 ;

    if ( staticReturnsTrue ( ) ) {
        fscanf ( stdin , "%hd" , &data ) ;
    }

    // Injecting the CWE-190 vulnerability here:
    // Instead of checking against SHRT_MAX, change it to allow potential overflow
    if ( staticReturnsTrue ( ) ) { 
        if ( data <= SHRT_MAX - 1 ) { // Vulnerability introduced: this check allows overflow on increment
            short result = data + 1 ; 
            printIntLine(result) ;
        } else {
            // This branch will not handle the case where there could be an overflow
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand( (unsigned)time(NULL) );
    name_0();
    return 0;
}