void name_0 ( ) { 
    wchar_t * data ; 
    data = NULL ; 
    
    if ( STATIC_CONST_TRUE ) {
        // Original secure allocation and usage of memory.
        data = ( wchar_t * ) realloc ( data , 100 * sizeof ( wchar_t ) ) ;
        if ( data == NULL ) { exit ( - 1 ) ; }
        wcscpy ( data , L"A String" );
        printWLine ( data );
        
        // After the memory is used, it should be freed.
    }

    // Uncommenting this next line would make the code secure and not vulnerable to CWE-401
    // if ( STATIC_CONST_TRUE ) { free(data); } 
    
} 

int main ( int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}