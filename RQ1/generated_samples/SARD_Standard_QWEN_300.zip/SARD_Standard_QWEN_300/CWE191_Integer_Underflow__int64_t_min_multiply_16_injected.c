#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <time.h>

void name_0(void) {
    int64_t data;

    // Modified code: initialize with LLONG_MIN directly without setting it twice.
    data = LLONG_MIN; 

    while (1) {  
        break;
    }

    while (1) {
        if (data < 0) {
            // Introduced vulnerability here by removing the overflow check
            int64_t result = data * 2; 
            printLongLongLine(result);
        }
        
        break;
    }
}

void printLongLongLine(int64_t value) {  
    printf("%" PRId64 "\n", value); 
}

int main(int argc, char* argv[]) {
    srand((unsigned int)time(NULL));
    name_0(); 
    return 0;
}