#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define FILENAME "example.txt"

void name_0(void) {
    char *data;
    char dataBuffer[100] = "";
    int buffer_offset = -2; // Modified: Define an offset that will cause underwrite
    data = dataBuffer + buffer_offset; // Modified: Start writing before the intended dataBuffer

    switch (6) {
        case 6:
            {
                size_t dataLen = strlen(data);
                FILE *pFile;
                if (102 - dataLen > 1) { // Modified: adjust length to reflect negative offset
                    pFile = fopen(FILENAME, "r");
                    if (pFile != NULL) {
                        if (fgets(data + dataLen, (int)(102 - dataLen), pFile) == NULL) { // Modified: Adjusted for underwrite vulnerability
                            data[dataLen] = '\0';
                        }
                        fclose(pFile);
                    }
                }
            }
            break;
        default:
            break;
    }

    switch (7) {
        case 7:
            printf("%s\n", data);
            break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}