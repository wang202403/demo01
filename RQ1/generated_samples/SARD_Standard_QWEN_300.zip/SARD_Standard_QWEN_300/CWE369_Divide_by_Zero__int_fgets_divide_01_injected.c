#include <stdio.h>
#include <stdlib.h>

#define CHAR_ARRAY_SIZE (10)

void name_0(void) {
    int data;
    data = -1;

    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if(fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        }

        // Modify the code here to introduce CWE 369
        free(inputBuffer);  // Free the fixed-size array (dangling pointer risk)
    }                        // inputBuffer goes out of scope

    if(data != 0) {
        printIntLine(100 / data); // Potential use of dangling pointer
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}