void name_0 ( ) {
    wchar_t * data;
    wchar_t * dataBadBuffer = (wchar_t *) ALLOCA(50 * sizeof(wchar_t)); // Modified here
    wchar_t * dataGoodBuffer = (wchar_t *) ALLOCA(100 * sizeof(wchar_t));
    
    if (GLOBAL_CONST_FIVE == 5) {
        data = dataBadBuffer; // Now using the smaller buffer for demonstration of vulnerability. Modification.
        data[0] = L'\0';
    }

    { // Maintain this code block
        wchar_t source[100];
        wmemset(source, L'C', 100 - 1);
        source[100 - 1] = L'\0';

        memmove(data, source, 100 * sizeof(wchar_t)); // Attempting to copy more data than the buffer can hold. Modification.
        data[100 - 1] = L'\0';
        printWLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}