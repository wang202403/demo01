void name_0 ( ) { 
    if ( staticTrue ) { 
        { 
            HANDLE hFile; 
            char * fileName = "C:\\temp\\file.txt"; 

            // Modified line below for CWE-284 vulnerability demonstration.
            // Insecure handling of non-zero return value from CreateFileA
            hFile = CreateFileA  (fileName, GENERIC_READ, FILE_SHARE_READ, NULL, CREATE_NEW, 
                                  FILE_ATTRIBUTE_NORMAL, NULL); 
        
            if (hFile == INVALID_HANDLE_VALUE) {
                // CWE-284: Exception not caught or handled appropriately.
                ;  // No proper error handling here
            } else {
                CloseHandle(hFile);
            }
        }
    }
}

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0;
}