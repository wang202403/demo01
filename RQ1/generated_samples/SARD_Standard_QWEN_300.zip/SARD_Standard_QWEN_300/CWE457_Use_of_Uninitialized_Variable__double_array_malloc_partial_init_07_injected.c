void name_0 ( ) { 
  double * data;
  
  data = (double *) malloc(10 * sizeof(double));
  
  if(data == NULL) {
      exit(-1);
  }
  
  // Original Code Block
  if(staticFive == 5) {
    int i; 
    for(i = 0; i < (10 / 2); i++) { // This loop is less than 10, so it doesn't cause an issue by itself.
      data[i] = (double)i;
    }  
  }

  if(staticFive == 5) {
    
    int i;

    for(i = 0; i < 10; i++) {
      data[i] = (double)i;
    }
    
    // CWE-457: Double Free vulnerability insertion
    free(data);  // First free

    // Added code block to simulate the double-free condition
    if(staticFive == 5) {  
        data = NULL;  // Potential dangling pointer
    
      // Second free that causes the vulnerability
      free(data);
    
      {
        for(i = 0; i < 10; i++) {
          printDoubleLine(data[i]);
        }
      }        
    }

    // Original free call
    free(data);  // Note that this could be another source of double-free if executed after the modified code.

  }
}