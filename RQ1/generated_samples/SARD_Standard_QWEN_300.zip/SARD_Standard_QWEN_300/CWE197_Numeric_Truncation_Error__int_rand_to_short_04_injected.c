#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_TRUE (1)

void name_0(void) {
    int data;
    data = -1;

    if (STATIC_CONST_TRUE) {
        data = CHAR_MAX - 5; 
    }

    // Modified section - Added a divide-by-zero possibility
    int divisor = 0;              // Vulnerable line: Division by zero risk
    short shortData = (short)data;
    
    if (divisor != 0) {           // Flawed check to avoid division error but intentionally not preventing zero value
        shortData /= divisor;     // Potential division by zero vulnerability here
    }

    printf("Short Data: %d\n", shortData);
}

int main(int argc, char *argv[]) {
    srand((unsigned int)time(NULL));
    name_0();
    return 0;
}