#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

// Function name_0 now potentially vulnerable to format string attacks
void name_0(char *data, ...) {
    va_list args;
    // The vulnerability is introduced here: data (untrusted input) used directly in format-string-like manner
    vfprintf(stdout, data, args);  // Vulnerable line! (Original code uses "%s", now using uncontrolled data)
    va_end(args);
}

void name_1() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (1) {
        size_t dataLen = strlen(data);
        if (100 - dataLen > 1) {
            if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                dataLen = strlen(data);
                if (dataLen > 0 && data[dataLen - 1] == '\n') {
                    data[dataLen - 1] = '\0';
                }
            } else {
                data[dataLen] = '\0';
            }
        }
    }

    // The function name_0 now uses the untrusted input 'data' as a format string
    if (1) {
        va_list args;
        va_start(args, data);
        name_0(data);  // Data from user input is passed to vulnerable function
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}