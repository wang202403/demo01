#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Simulated function for demonstration purposes
int globalReturnsTrueOrFalse(void) {
    return rand() % 2;
}

void name_0 ( ) { 
    int * data ; 
    data = NULL ; 
    
    if ( globalReturnsTrueOrFalse ( ) ) { 
        data = ( int * ) malloc ( 100 * sizeof ( int ) ) ;
        
        if ( data == NULL ) {
            exit ( - 1 );
        }
        
        for ( size_t i = 0; i < 100 ; i ++ ) {
            data [ i ] = 5;
        } 

        free(data); // Here we free the memory
    } else { 
        data = ( int * ) malloc ( 100 * sizeof ( int ) ) ;
        
        if ( data == NULL ) {  
            exit ( - 1 );   
        }
        
        for ( size_t i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = 5; 
        } 
        
        free(data); // Here we free the memory
    }

    if ( globalReturnsTrueOrFalse ( ) ) {  
        ;
    } else { 
        ; 
    }
    
    /* Vulnerability introduced: Accessing freed memory */
    printf("%d\n", data[0]);  // Use After Free vulnerability here
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );  
    name_0 ( );
    return 0; 
}