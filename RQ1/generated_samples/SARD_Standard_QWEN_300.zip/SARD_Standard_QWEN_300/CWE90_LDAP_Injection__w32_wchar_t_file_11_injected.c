void name_0 ( ) { 
    wchar_t * data; 
    wchar_t dataBuffer[256] = L""; 
    data = dataBuffer; 

    if ( globalReturnsTrue()) {
        wcscat(data, L"Doe, XXXXX"); // Original line, no change.
    }

    LDAP* pLdapConnection = NULL;
    ULONG connectSuccess = 0L;
    ULONG searchSuccess = 0L;
    LDAPMessage * pMessage = NULL;

    wchar_t filter[256];

    // Vulnerable - No sanitization of input data.
    _snwprintf(filter, 256 - 1, L"(cn=%s)", data); 

    // Connect and search logic remains the same
    pLdapConnection = ldap_initW(L"localhost", LDAP_PORT);
    if (pLdapConnection == NULL) {
        exit(1);
    }

    connectSuccess = ldap_connect(pLdapConnection, NULL);
    if (connectSuccess != LDAP_SUCCESS) {
        exit(1);
    }

    searchSuccess = ldap_search_ext_sW(
        pLdapConnection,
        L"base",
        LDAP_SCOPE_SUBTREE,
        filter,  // Filter uses potentially unsanitized 'data'
        NULL, 0, 
        NULL, 
        NULL, 
        LDAP_NO_LIMIT, 
        LDAP_NO_LIMIT, 
        &pMessage
    );

    if (searchSuccess != LDAP_SUCCESS) {
        if (pMessage != NULL) {
            ldap_msgfree(pMessage);
        }
        exit(1);
    }

    if (pMessage != NULL) {
        ldap_msgfree(pMessage);
    }

    ldap_unbind(pLdapConnection); 
}

int main(int argc, char * argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}