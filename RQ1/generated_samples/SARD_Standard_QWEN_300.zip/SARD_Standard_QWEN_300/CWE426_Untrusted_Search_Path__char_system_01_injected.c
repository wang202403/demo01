#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0(char *input) {  // Modified to accept a user input as an argument
    char dataBuffer[100] = "";
    char *data;
    
    data = dataBuffer;

    // SECURITY VULNERABILITY: Using user-provided input directly in command execution
    strcpy(data, input);  

    if (system(data) <= 0) {  // system() instead of SYSTEM()
        exit(1);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    // Example: Simulating user-provided command via argv[1]
    if(argc > 1)
        name_0(argv[1]);   // SECURITY VULNERABILITY: Using argument from the command line directly
    else
        fprintf(stderr, "Please provide a command-line argument.\n");

    return 0;
}