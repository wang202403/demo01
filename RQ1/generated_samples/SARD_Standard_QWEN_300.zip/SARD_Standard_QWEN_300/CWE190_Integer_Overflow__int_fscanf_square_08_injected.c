void name_0 ( ) {
    int data;
    data = 0;

    if ( staticReturnsTrue() ) {
        fscanf(stdin, "%d", &data);
    }

    // Modified part: Removed the check for integer overflow.
    if ( staticReturnsTrue() ) {
        int result = data * data;  // Potential Integer Overflow
        printIntLine(result);
    }
}