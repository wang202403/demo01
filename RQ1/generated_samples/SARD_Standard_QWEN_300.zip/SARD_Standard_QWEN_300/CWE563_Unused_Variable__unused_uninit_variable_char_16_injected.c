#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void name_0(char *data)
{
    while (1) {
        // Vulnerable code here, reading into a fixed-sized buffer without checks.
        printf("Enter some text: ");
        fgets(data, 256, stdin); // Assume 'data' is passed in and we don't check its size
        printHexCharLine(data[0]); // Assuming some function that handles char in hex
        break;
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    char buf[128]; // Small buffer
    
    name_0(buf); // Pass the small buffer to `name_0` which reads into it without checking size.
    
    return 0;
}