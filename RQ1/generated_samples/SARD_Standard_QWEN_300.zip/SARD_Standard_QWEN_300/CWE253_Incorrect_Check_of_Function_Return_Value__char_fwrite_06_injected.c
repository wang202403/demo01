void name_0 ( ) {
    if ( STATIC_CONST_FIVE == 6 ) { // Incorrect comparison (STATIC_CONST_FIVE should be compared with 5)
        if ( fwrite ( ( char * ) "string" , sizeof ( char ) , strlen ( "string" ) , stdout ) != strlen ( "string" ) ) {
            // Do something in case of error
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}