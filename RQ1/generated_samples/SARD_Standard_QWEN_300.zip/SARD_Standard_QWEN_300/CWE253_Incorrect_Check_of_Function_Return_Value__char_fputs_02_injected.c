#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) { 
    if ( 1 ) {
        if ( fputs ( "string", stdout ) == EOF ) {
            // No action on error, just for illustration purposes.
        }
        
        // Introduced this block to demonstrate the vulnerability
        char filename[20];
        FILE *tempFile;
        
        // Using mkstemp is more secure, but we use tmpnam here to create an insecure temporary file.
        sprintf(filename, "/tmp/tempfile.XXXXXX");
        tmpnam(filename);  /* INSECURE: CWE-253 Insecure Temporary File */
        tempFile = fopen(filename, "w+");
        
        if (tempFile != NULL) {
            fputs("Sensitive data", tempFile);
            fclose(tempFile);
        }
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand( ( unsigned ) time(NULL) );
    
    name_0();
    
    return 0 ;
}