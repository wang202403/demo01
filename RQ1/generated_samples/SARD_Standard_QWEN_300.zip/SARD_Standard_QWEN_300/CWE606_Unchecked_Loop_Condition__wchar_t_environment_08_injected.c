int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

#define ENV_VARIABLE L"MY_ENV"

void name_0 ( )
{
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L "" ;

    data = dataBuffer ;

    if ( staticReturnsTrue ( ) )
    {
        size_t dataLen = wcslen ( data ) ;

        // The vulnerability is injected here.
        wchar_t * environment = GETENV(ENV_VARIABLE);
        if (environment != NULL)
        {
            // Modified to remove the "-1", which can cause buffer overflow
            // Original: wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            wcsncat(data + dataLen, environment, 100 - dataLen);    // Vulnerable statement
            
        }
    }

    if ( staticReturnsTrue ( ) )
    {
        int i , n , intVariable ;
        if ( swscanf( data, L"%d", &n) == 1 )
        {
            if ( n < MAX_LOOP )
            {
                intVariable = 0;
                for (i = 0; i < n ; i++ )
                {
                    intVariable++;
                }
                printIntLine(intVariable);
            }
        }
    }
}

int main( int argc, char *argv[] )
{
    srand((unsigned)time(NULL));
    
    name_0();
    
    return 0;
}