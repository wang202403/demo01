void name_0 ( ) { 
    char * data ; 
    char dataBadBuffer[50] ; // Smaller buffer, vulnerable if overflowed.
    char dataGoodBuffer[100] ; 

    while ( 1 ) { 
        // Vulnerability introduced by pointing to the smaller buffer
        data = dataBadBuffer;  // Original: data = dataGoodBuffer;
        data [ 0 ] = '\0' ;
        break ;
    }

    {
        size_t i ; 
        char source[100] ; 

        memset ( source , 'C' , 100 - 1 ) ;
        source [ 100 - 1 ] = '\0' ;

        // Loop will copy more data than the smaller buffer can hold
        for ( i = 0 ; i < 100 ; i ++ ) {
            data [i] = source[i];
        }

        data [ 100 - 1 ] = '\0' ;
        printLine ( data ) ;
    } 
}

int main(int argc, char *argv[]) {  
    srand((unsigned) time(NULL)) ;
    name_0() ; 

    return 0 ;
}