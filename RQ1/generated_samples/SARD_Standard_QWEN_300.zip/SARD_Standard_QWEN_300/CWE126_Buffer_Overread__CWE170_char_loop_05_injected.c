#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

void name_0 ( ) { 
    if ( /* staticTrue */) { // Assuming `staticTrue` evaluates to true as part of the example.
        char src [ 150 ] , dest [ 100 ];
        int i;

        memset ( src , 'A' , 148 ); // Set 148 characters for string termination
        src [ 149 ] = '\0';         // Add a null terminator at position 149

        // Modified to read past the bounds of dest.
        for ( i = 0 ; i < 150 ; i ++ ) {   // This loop goes out of dest's boundary
            dest[i] = src[i];
        }

        dest [ 99 ] = '\0';    // Null-terminate dest at its intended size
        
        printLine(dest);      // Assuming `printLine` is a function to print the string.
        
        // Vulnerability introduced: Reading past dest[] bounds by accessing up to 150 elements
    }
}

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time(NULL) );
    name_0();
    return 0;
}