#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void name_0(void) {
    char *data;
    char *dataBadBuffer = (char *) alloca(50 * sizeof(char)); // Vulnerability introduced here: allocated space for 50 chars
    char *dataGoodBuffer = (char *) alloca(100 * sizeof(char));

    if (1) {
        data = dataBadBuffer; // Using the smaller buffer intentionally to demonstrate vulnerability. This is the modified part.
        data[0] = '\0';
    }

    {   // The rest remains the same
       char source[100];
       memset(source, 'C', 100 - 1);
       source[100 - 1] = '\0';
       memmove(data, source, 100 * sizeof(char)); // CWE-121: Writing 100 bytes into a buffer of size 50
       data[100 - 1] = '\0';                      // This line will likely cause an overflow.
       printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0(); 
    return 0; 
}