#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Global constant for demonstration purposes.
#define GLOBAL_CONST_TRUE 1

void name_0(void) {
    char *data;

    if (GLOBAL_CONST_TRUE) {
        // Allocate dynamic memory without checking the return value.
        data = malloc(strlen("string") + 1);  // Vulnerability: Not checking the result of malloc
        if (!data) {  // This check is commented below to demonstrate the vulnerability
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }

        strcpy(data, "string");  // Using the allocated data
        printLine(data);         // Printing the string

        free(data);              // Freeing memory when done.
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}