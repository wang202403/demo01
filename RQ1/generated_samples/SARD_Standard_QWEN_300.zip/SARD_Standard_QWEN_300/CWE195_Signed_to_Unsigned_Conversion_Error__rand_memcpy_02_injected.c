#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) { 
    int data ; 
    data = - 1 ; 

    // Modified Code
    // Reordered the assignment to 'data' and set it incorrectly.
    if ( 1 ) {
        data = 150; // This will now exceed buffer size of dest[100].
                   // Instead of 99, we are setting this arbitrarily higher to cause a CWE-195 issue with potential buffer overflow
    }

    char source [ 100 ];
    char dest [ 100 ] = "" ;

    memset ( source , 'A' , 100 - 1 ) ;
    source [ 100 - 1 ] = '\0' ;

    // This condition still exists, but now `data` can be larger than the buffer size.
    if ( data < 100 ) {
        memcpy ( dest , source , data ) ; 
        dest [ data ] = '\0' ;
    }
    
    printLine ( dest ) ;
}

void printLine(char *line) {
    printf("%s\n", line);
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}