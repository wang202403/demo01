void name_0 () {
    unsigned int data;
    data = 0;

    if (globalReturnsTrueOrFalse()) {
        data = (unsigned) RAND32(); 
    } else {
        data = (unsigned) RAND32();
    }

    // Vulnerable part: Overflow potential due to lack of checking
    if (globalReturnsTrueOrFalse()) {
        unsigned int result = data + 1;
        printUnsignedLine(result);
    } else {
        unsigned int result = data + 1;
        printUnsignedLine(result);    
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}