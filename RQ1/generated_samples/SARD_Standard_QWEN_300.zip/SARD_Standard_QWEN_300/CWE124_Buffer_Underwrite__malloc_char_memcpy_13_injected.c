#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define GLOBAL_CONST_FIVE 5

void name_0(void) {
    char * data;
    data = NULL;

    if (GLOBAL_CONST_FIVE == 5) {
        // Allocate memory and initialize buffer with 'A'
        char * dataBuffer = (char *)malloc(100 * sizeof(char));
        if (dataBuffer == NULL) {
            exit(-1);
        }
        memset(dataBuffer, 'A', 100 - 1);
        dataBuffer[100 - 1] = '\0';
        data = dataBuffer;
    }

    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';

        // CWE-124: Buffer Underwrite vulnerability introduced here by shifting destination pointer
        memcpy(data - 10, source, 100 * sizeof(char)); // Vulnerability injected here

        data[100 - 1] = '\0';
        printf("%s\n", data);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}