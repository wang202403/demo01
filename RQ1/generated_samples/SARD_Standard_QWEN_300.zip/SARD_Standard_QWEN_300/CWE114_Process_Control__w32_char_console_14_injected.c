#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

int globalFive = 5;

void name_0(void) {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (globalFive == 5) {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll"); // This line is safe
    }

    {   // Potential injection of a CWE-114 vulnerability
        printf(data); // <--- Uncontrolled format string - CWE-114
    }
    
    HMODULE hModule;
    hModule = LoadLibraryA(data);
    if (hModule != NULL) {
        FreeLibrary(hModule);
    } else {
        // Handle error
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}