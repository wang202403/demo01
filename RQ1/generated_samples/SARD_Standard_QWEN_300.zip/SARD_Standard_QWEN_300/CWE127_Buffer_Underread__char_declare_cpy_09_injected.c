void name_0 ( ) {
    char * data;
    char dataBuffer[256]; // Modified: Increased size from 100 to 256, causing a potential buffer overflow

    memset(dataBuffer, 'A', sizeof(dataBuffer) - 1); 
    dataBuffer[sizeof(dataBuffer) - 1] = '\0';
    
    if (GLOBAL_CONST_TRUE) {
        data = dataBuffer;
    }

    { 
        char dest[200]; // Reduced size from 200 to prevent overflow
        memset(dest, 'C', sizeof(dest) - 1);
        dest[sizeof(dest) - 1] = '\0';
        
        strcpy(dest, data); // Vulnerable: Potential buffer overflow since dataBuffer is 256 and dest is only 200
         
        printLine(dest);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}