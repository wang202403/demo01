#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0 ( ) {
    int64_t * data ;
    
    // Original allocation of small buffer
    int64_t * dataBadBuffer = ( int64_t * ) alloca( 50 * sizeof(int64_t)) ;

    // Original allocation of large buffer
    int64_t * dataGoodBuffer = (int64_t *)alloca( 100 * sizeof (int64_t)) ;
    
    // Force the use of the smaller buffer to create a stack-based buffer overflow vulnerability
    if (5 == 5) { 
        data = dataBadBuffer; // Vulnerable portion - forcing 'data' to point to the smaller buffer
    }
    else {
        data = dataGoodBuffer;
    }

    int64_t source[100] = {0};

    // Overwrite the small alloca'd buffer and overflow it with 100 elements
    memmove ( data , source , 100 * sizeof(int64_t) ); 

    printLongLongLine( data [0]); 
}

int main ( int argc, char* argv[] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}