#include <wchar.h>
#include <string.h>
#include <stdio.h>

#define SRC_STRING L"SourceString"

// Assume this function returns true or false randomly.
int globalReturnsTrueOrFalse(void) {
    return rand() % 2; // Randomly returns either 0 (false) or 1 (true)
}

void name_0 () {
    wchar_t * data;
    wchar_t dataBadBuffer[10]; // Modified: Reduced the buffer size to induce CWE-121 vulnerability
    wchar_t dataGoodBuffer[10 + 1];
    
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; 
        data[0] = L'\0';
    } else {
        data = dataGoodBuffer;
        data[0] = L'\0';
    }
    
    { // Note: CWE-121 vulnerability is in this section where we copy the source string to 'data'
        wchar_t source[10 + 1] = SRC_STRING; 
        size_t i, sourceLen;
        
        sourceLen = wcslen(source); // Length of source string
        
        for (i=0 ; i < sourceLen+1 ; i++) {
            data[i] = source[i];  // CWE-121: Potential buffer overflow if 'data' points to a smaller buffer
        }
    }

    printWLine(data);
}

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL));
    
    name_0();
    
    return 0; 
}