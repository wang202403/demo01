#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printUnsignedLine(size_t val) {
    printf("%zu\n", val);
}

#define SIZE 16

void name_0 () 
{
    char string1[] = "SOURCE_STRING";
    
    // Add an additional array with a fixed size.
    int arr[SIZE] = {0}; 
    
    char * slashInString1;
    size_t indexOfSlashInString1;

    slashInString1 = strchr(string1, '/');
    if (slashInString1 == NULL) 
    {
        exit(1);
    }

    // Calculate index of '/' in the string.
    indexOfSlashInString1 = (size_t)(slashInString1 - string1);

    printUnsignedLine(indexOfSlashInString1);

    // Vulnerable part: Attempting to access an out-of-bounds element.
    // The value indexOfSlashInString1 might be larger than SIZE, leading to undefined behavior.
    printf("Array contents at calculated index: %d\n", arr[indexOfSlashInString1]);  // Vulnerability here

}

int main (int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}