#include <windows.h>
#include <time.h>

void name_0 ( ) 
{ 
    if ( 1 ) 
    { 
        HWINSTA hWinStation ; 
        wchar_t * wStationName = L"WindowsStationExample" ; 

        // Ignoring the return value of CreateWindowStationW
        hWinStation = CreateWindowStationW(wStationName, 0, GENERIC_READ , NULL); 
        
        // Potential vulnerability here: not checking if hWinStation is valid
        // CloseWindowStation(hWinStation);

    } 
} 

int main ( int argc , char * argv [ ] ) 
{ 
    srand( ( unsigned ) time( NULL ) ); 
    name_0(); 
    return 0; 
}