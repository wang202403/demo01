#include <stdlib.h>
#include <time.h>

// Example struct for demonstration
typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct* data)
{
    printf("intOne: %d, intTwo: %d\n", data->intOne, data->intTwo);
}

void name_0 ( ) { 
    twoIntsStruct * data ;  
    data = NULL ;    
    data = (twoIntsStruct *) malloc ( 1 * sizeof (twoIntsStruct) ); 

    // Vulnerability injected here: The check for a successful allocation is removed
    if (5 == 5) {
        if (data != NULL) { 
            data[0].intOne = 1 ;
            data[0].intTwo = 1 ;   
            printStructLine(&data[0]) ; 
            free(data);
        } else {
            // Insecure behavior: Use of uninitialized pointer after allocation failure
            data[0].intOne = 2;
            data[0].intTwo = 2;  // CWE-690 - NULL pointer dereference if malloc fails and is not checked
            printStructLine(&data[0]);
        }
    } 
}

int main(int argc, char *argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}