#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( )
{
    int * data;
    data = NULL;

    if ( staticReturnsTrue() )
    {
        data = (int *) malloc(100 * sizeof(int));
        if (data == NULL) 
        {
            exit(-1);
        }
        
        size_t i;    
        for (i = 0; i < 100; i++)
        {
             data[i] = 5;
        }

        free(data); // Memory is freed here

        if(staticReturnsTrue()) { ; } // Placeholder to introduce the vulnerability
        
        // Added code below - accessing already freed memory
        printf("Using freed memory: %d\n", data[0]); /* Vulnerable Code */

    }
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL));
    
    name_0();
     
    return 0;
}