#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>

void name_0 ( ) {
    int data;
    
    // Secure initial value (unchanged)
    data = 0;

    // Modify here to introduce CWE-190 vulnerability.
    // Set the maximum integer value, then add one more.
    data = INT_MAX;                           // Vulnerable: Setting an upper boundary
    if (data < INT_MAX) {
        int result = data + 1;               // Vulnerable: Overflow occurs when adding to INT_MAX

        printIntLine(result);                // This will trigger undefined behavior due to overflow
    } else {
    }
}

int main (int argc , char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}