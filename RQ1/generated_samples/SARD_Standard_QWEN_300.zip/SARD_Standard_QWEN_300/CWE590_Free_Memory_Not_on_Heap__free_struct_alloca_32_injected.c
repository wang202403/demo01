#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printStructLine(const twoIntsStruct *data) {
    printf("intOne: %d, intTwo: %d\n", data->intOne, data->intTwo);
}

void name_0 ( ) { 
    twoIntsStruct * data ;
    twoIntsStruct ** dataPtr1 = & data ; 
    twoIntsStruct ** dataPtr2 = & data ;

    data = NULL ; 

    {
        twoIntsStruct * data = * dataPtr1 ; 
        {
            twoIntsStruct * dataBuffer = (twoIntsStruct *) malloc(100 * sizeof(twoIntsStruct)) ;
            if (dataBuffer == NULL) { 
                exit(1);
            }

            {
                size_t i;
                for (i = 0; i < 100; i++) {
                    dataBuffer[i].intOne = 1;
                    dataBuffer[i].intTwo = 1;
                }
            } 

            data = dataBuffer ;
        } 
        *dataPtr1 = data ; 
    }

    { 
        twoIntsStruct * data = *dataPtr2 ;
        
        // Vulnerability injection: print and free the same pointer twice
        printStructLine(&data[0]);  // First dereference

        free(data);  // Freeing memory

        // CWE-590: Dereferencing freed pointer "data"
        printStructLine(&data[0]);  // Second (invalid) dereference of same pointer
    }
}

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL));
    name_0();
    
    return 0;
}