void name_0 ( ) {
    int data;
    data = -1 ;
    if ( globalTrue ) {
        data = 100 - 1 ;
    }
    
    { 
        char source [ 100 ];
        char dest [ 100 ] = "";
        memset( source , 'A' , 100-1 );
        source [ 100 - 1 ] = '\0';

        // Injecting the CWE-195 vulnerability: Comparing data with itself
        if (data == data) {
            if ( data < 100 ) {
                strncpy( dest, source , data );
                dest[ data ] = '\0';
            }
        }

        printLine(dest);
    } 
}

int main(int argc, char* argv[]) {  
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}