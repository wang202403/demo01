#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(char *data) {
    printf("%s\n", data);
}

void name_0() {
    char *data;
    char dataBadBuffer[50];  // Reduced size of buffer to cause overflow
    char dataGoodBuffer[100];
    
    while (1) {
        data = dataBadBuffer; // Vulnerability: Using a smaller buffer for unsafe operations
        data[0] = '\0';
        break;
    }
    
    {
        char source[100];
        
        memset(source, 'C', sizeof(source)-1);
        source[sizeof(source)-1] = '\0';
        
        memmove(data, source, 100 * sizeof(char)); // Vulnerability: Writing more data than buffer size
        data[99] = '\0'; // This now causes overflow since we are writing to an array of size 50
        
        printLine(data);    
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}