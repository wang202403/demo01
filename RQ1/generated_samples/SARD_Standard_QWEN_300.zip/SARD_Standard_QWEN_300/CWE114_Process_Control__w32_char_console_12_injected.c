#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

int globalReturnsTrueOrFalse() {
    return rand() % 2; // For demonstration purposes, returns true or false randomly.
}

void name_0(void) {
    char *data;
    char dataBuffer[100] = "";
    
    // Injecting vulnerability here
    data = &dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
        
        // Vulnerable part starts here:
        printf("Enter a name: ");
        fgets(data + strlen(data), 79 - strlen(data) - 1, stdin); // Insecure code
        // Vulnerable part ends here.
    } else {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
        
        // Vulnerable part starts here:
        printf("Enter a name: ");
        fgets(data + strlen(data), 79 - strlen(data) - 1, stdin); // Insecure code
        // Vulnerable part ends here.
    }
    
    {
        HMODULE hModule;
        hModule = LoadLibraryA(data);
        
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            printf("Failed to load library\n");
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    
    // Vulnerable input handling function call.
    name_0();
    
    return 0;
}