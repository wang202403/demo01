void name_0 ( ) {
    if ( globalTrue ) { // Assume this variable is declared and defined elsewhere.
        HANDLE hMutex = NULL ;
        
        // Vulnerability Injection: Not checking the return value of CreateMutexA().
        CreateMutexA(NULL, FALSE, NULL); 
        
        // The next lines are kept unchanged:
        CloseHandle(hMutex);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand( (unsigned) time(NULL) );
    name_0();
    return 0;
}