#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Added unsafe typedef to exemplify CWE-194 Unsafe Typedef
typedef short int unsafetype;

int globalReturnsTrueOrFalse(void) {
    return rand() % 2; // returns either true or false randomly
}

void printLine(char *message) {
    printf("%s\n", message);
}

// Vulnerable code starts here, with modificatons noted
void name_0 ( ) { 
    unsafetype data ; // Changed short to unsafetype
    data = 0 ;

    if ( globalReturnsTrueOrFalse ( ) ) { 
        data = 100 - 1 ; 
    } else {
        data = 100 - 1 ;
    }

    char source [ 100 ] ;
    char dest [ 100 ] = "" ;

    memset ( source , 'A' , sizeof(source) - 1 ); // Adjusted size to avoid buffer overflow
    source [ sizeof(source)-1 ] = '\0';

    if ( data < (short)sizeof(dest)) { // Explicitly casted short to prevent truncation issues in comparison
        // Potential issue: If `data` overflows with a large value, this bounds check fails, leading to possible buffer overflow.
        strncpy ( dest , source , data ) ;
        dest [ data ] = '\0' ; 
    }

    printLine ( dest );
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ;

    name_0 ( ) ;

    return 0 ;
}