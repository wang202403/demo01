#include <windows.h>
#include <time.h>
#include <stdlib.h>

void name_0(void) {
    goto sink;
sink:
    {
        wchar_t *keyName = L"TEST\\TestKey";
        HKEY hKey;

        if (RegCreateKeyExW(HKEY_CURRENT_USER, keyName, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) { // Vulnerability: Infinite loop introduced
            while (1) {
                RegCloseKey(hKey);
                Sleep(1); // Adding sleep to avoid consuming too much CPU but the loop is still infinite.
            }
        } else {
            ; // Do nothing if key creation failed
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}