#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Function to simulate a global true return value
int globalReturnsTrue() {
    return 1; // Always returns true (1)
}

void name_0 ( ) { 
    char * data ; 
    char dataBadBuffer [ 50 ] ; // Small buffer, only size of 50 bytes
    char dataGoodBuffer [ 100 ] ; 
    if ( globalReturnsTrue ( ) ) {
        data = dataBadBuffer; // Point to the smaller buffer instead of the safe one
        data[0] = '\0' ;
    } 

    { 
        char source [ 100 ] ;
        memset ( source , 'C' , sizeof(source) - 1 ) ; // memset the entire source array except the null terminator
        source [sizeof(source)-1] = '\0' ;

        // Vulnerability here: we are copying 100 characters into a potentially smaller buffer of size 50.
        strncpy ( data, source, sizeof(source) ); 
        data[99] = '\0'; // Attempt to null terminate, but the buffer may already be overflowed
        printLine(data);
    } 
}

void printLine(char *data)
{
    printf("%s\n", data); // Print the contents of 'data'
}

int main ( int argc , char * argv [ ] ) {
    srand (( unsigned ) time ( NULL ) );
    name_0 ( ) ;
    return 0 ;
}