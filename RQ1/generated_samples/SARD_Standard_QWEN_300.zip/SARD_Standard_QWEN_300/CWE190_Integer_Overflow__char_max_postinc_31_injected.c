#include <stdio.h>
#include <time.h>

void name_0() {
    char data;
    data = ' ';
    data = CHAR_MAX;  // Set data to maximum value for a character

    {   // Begin scope block
        char dataCopy = data;

        // Start of modification - Injection point for CWE-190 vulnerability
        if (data < SCHAR_MAX) {  // Change from CHAR_MAX to SCHAR_MAX to ensure overflow condition can be reached
            data++;
        }
        
        char result = data; 
        printHexCharLine(result);
    }   // End of scope block

}   // end function name_0()

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

// Dummy function to mimic the printing functionality
void printHexCharLine(char result) {
    printf("Result: %x\n", (unsigned char)result);
}