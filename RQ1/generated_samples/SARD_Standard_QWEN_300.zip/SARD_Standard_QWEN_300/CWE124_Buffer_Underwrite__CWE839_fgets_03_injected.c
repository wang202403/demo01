void name_0 ( ) {
    int data;
    data = -1;

    if ( 5 == 5 ) { 
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if ( fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL ) {
            data = atoi( inputBuffer );
        }
    }

    if ( 5 == 5 ) {
        int i;
        int buffer[10] = { 0 };

        // Bounds check (SECURE)
        if (data >= 0 && data < (10)) {
            buffer[data] = 1;

            for (i=0; i<10; i++) {
                printIntLine(buffer[i]);
            }
        } else {}
    }
}