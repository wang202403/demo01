void name_0 ( ) {
    if ( globalReturnsTrue ( ) ) {
        { 
            long data; // This is uninitialized.
            
            // BEGIN VULNERABILITY - Accessing uninitialized memory.
            long * pointer = ( long * ) ALLOCA ( sizeof( long) );
            *pointer = data;  // Using the value of 'data', which can be anything.
            // END VULNERABILITY

            { 
                long data = *pointer;
                printLongLine ( data );
            } 
        }
    }
} 

int main ( int argc , char * argv [ ] ) {
    srand (( unsigned) time(NULL));
    name_0();
    return 0 ;
}