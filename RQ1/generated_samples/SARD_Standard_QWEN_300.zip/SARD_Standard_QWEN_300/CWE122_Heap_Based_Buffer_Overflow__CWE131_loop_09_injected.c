void name_0 ( ) {
    int * data;
    data = NULL;

    if ( GLOBAL_CONST_TRUE ) {
        data = (int *) malloc(10 * sizeof(int)); // This allocates memory for 10 integers.
        if (data == NULL) {
            exit(-1); 
        }
    }

    {
        int source[20] = { 0 }; // Increased the size of 'source' array to make it larger than allocated space for 'data'.
        size_t i;

        for (i = 0; i < 20; i++) {
            data[i] = source[i];  // No check on the bounds here, which can lead to writing beyond the allocated memory.
        }
        printIntLine(data[0]);
        free(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}