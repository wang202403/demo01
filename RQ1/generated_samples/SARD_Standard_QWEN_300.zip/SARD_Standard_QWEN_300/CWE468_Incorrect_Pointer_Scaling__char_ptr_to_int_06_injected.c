void name_0 ( ) {
    if ( STATIC_CONST_FIVE == 5 ) { 
        int intArray [ 5 ] = { 1 , 2 , 3 , 4 , 5 } ;
        char * charPointer = (char *) intArray ;

        // Vulnerability: Improper index accessing which leads to out-of-bounds read
        int toPrint = (int) (*(charPointer + (5 * sizeof(int)))); // Modified index from 2 to 5 causing out-of-bounds

        printIntLine(toPrint);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}