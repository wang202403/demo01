void name_0 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    if ( STATIC_CONST_TRUE ) {
        { 
            size_t dataLen = strlen ( data ) ;
            char * environment = GETENV ( ENV_VARIABLE ) ;
            if ( environment != NULL ) {
                strncat ( data + dataLen , environment , 100 - dataLen - 1 ) ; // This check seems to be secure.
            }
        } 
    }

    if ( STATIC_CONST_TRUE ) {
        { 
            int i, n, intVariable ;
            if ( sscanf ( data , "%d" , & n ) == 1 ) {
                if ( n < MAX_LOOP ) {
                    intVariable = 0 ;
                    for ( i = 0 ; i < n ; i ++ ) {
                        intVariable ++ ;
                    }
                    printIntLine ( intVariable ) ;
                }
            }
        } 
    }
}