#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SNPRINTF snprintf

void name_0 ( ) {
    char * data;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];  // This buffer is large enough, we'll modify it to create the vulnerability.

    if (5 == 5) {
        data = dataBadBuffer;  // Changed from dataGoodBuffer to dataBadBuffer
        data[0] = '\0';
    }

    {    
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100-1] = '\0';

        // CWE-121 Vulnerability Introduced Here
        strcpy(data, source);   // Using strcpy without checking buffer size causes a classic buffer overflow.
        
        printLine (data);       
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}