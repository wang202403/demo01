void name_0 ( ) {
    char * data ;
    char * dataBadBuffer = (char *) ALLOCA(50 * sizeof(char));
    char * dataGoodBuffer = (char *) ALLOCA(100 * sizeof(char));

    switch (6) {
        case 6:
            data = dataGoodBuffer;
            data[0] = '\0';
            break;
        default :
            break ;
    }

    {
        char source [100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';

        strcpy(data, source);

        printLine(data);
    }
}

int main ( int argc , char * argv[] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0 ;
}