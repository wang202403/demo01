#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_TRUE 1

void name_0 ( ) {    
    if (STATIC_CONST_TRUE) {
        int data;
        int *pointer = (int *)malloc(sizeof(int));
        
        if (pointer == NULL) {
            exit(-1);
        }
        
        data = 5;
        *pointer = data;

        // Add a call to the vulnerable recursive function
        recursiveFunction();
        
        { 
            int data = *pointer; 
            printf("%d\n", data);  // Print integer line with simple printf
        }
        
        free(pointer);
    }    
}

// Vulnerable recursive function without base case
void recursiveFunction() {
   recursiveFunction();  // The vulnerability here: infinite recursion.
}
    
int main ( int argc, char * argv[] ) { 
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}  