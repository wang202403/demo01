#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Function returning true or false randomly for demonstration purposes:
int globalReturnsTrueOrFalse(void) {
    return rand() % 2;
}

void name_0 ( ) { 
    char * data ; 
    char dataBuffer [ 250 ] = "PATH=" ; 
    data = dataBuffer ; 

    // Added input for NEW_PATH which can be manipulated
    const char* NEW_PATH = getenv("INPUT"); // Insecure: directly using input from environment variable

    if ( globalReturnsTrueOrFalse ( ) ) { 
        strcat ( data , NEW_PATH ) ; 
    } else { 
        strcat ( data , NEW_PATH ) ; 
    }

    putenv(data);  // Vulnerable line: Improper handling of user-controlled input
} 

int main ( int argc, char * argv[] ) { 
    srand((unsigned)time(NULL));
    
    name_0(); 
    
    return 0;
}