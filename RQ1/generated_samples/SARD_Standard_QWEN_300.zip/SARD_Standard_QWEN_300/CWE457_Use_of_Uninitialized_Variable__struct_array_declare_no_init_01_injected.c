#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0 ( ) {
    twoIntsStruct * data ;
    twoIntsStruct dataUninitArray [ 10 ] ;

    // Allocate memory and assign to data
    data = malloc(10 * sizeof(twoIntsStruct));
    
    // The following portion introduces the double free vulnerability:
    if(data == NULL) {
        exit(-1); // Handle error gracefully (not part of CWE-457)
    } 
    
    { 
        int i ;
        for ( i = 0 ; i < 10 ; i ++ ) {            
            data [ i ] . intOne = i ;  
            data [ i ] . intTwo = i ;  
        }
    }

    {   
        int i ;
        for ( i = 0 ; i < 10 ; i ++ ) {
            printIntLine ( data [ i ] . intOne ) ;
            printIntLine ( data [ i ] . intTwo ) ;
        } 
    }

    free(data); // First "free" operation

    if(data != NULL) {   /* Introducing the Double Free vulnerability below */
        free((void*)dataUninitArray); // Second and unintended free operation
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ; 
    return 0 ;
}