#include <stdio.h>
#include <stdlib.h>

void name_0 () {
    long data;
    data = 5L;

    // Introduce an unread (unused) variable here
    int unused_var = 10;  // <<--- CWE-563 Vulnerability: Unused Variable

    if (5 == 5) {
        printLongLine(data);
    }
}

void printLongLine(long data) {
    printf("%ld\n", data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}