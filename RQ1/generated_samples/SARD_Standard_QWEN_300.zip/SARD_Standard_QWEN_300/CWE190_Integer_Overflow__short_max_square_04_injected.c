#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define STATIC_CONST_TRUE 1
#define SHRT_MAX 32767

void name_0 ( ) {
    short data ;
    data = 0 ;

    if ( STATIC_CONST_TRUE ) {
        // Intentionally set `data` to the maximum value a short can hold.
        // This will be used to demonstrate integer overflow when multiplied by itself.
        data = SHRT_MAX ; 
    }

    if ( STATIC_CONST_TRUE ) {
        // This condition is correct but doesn't prevent the underlying vulnerability.
        if ( abs ( ( long ) data ) <= ( long ) sqrt ( ( double ) SHRT_MAX ) ) {
            short result = data * data ;  // Vulnerable line: Integer overflow
            printIntLine ( result ) ;
        } else {
            // Empty block - intentionally left as is.
        }
    }
}

void printIntLine(int i) { 
    printf("Value: %d\n", i);
} 

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0 ;
}