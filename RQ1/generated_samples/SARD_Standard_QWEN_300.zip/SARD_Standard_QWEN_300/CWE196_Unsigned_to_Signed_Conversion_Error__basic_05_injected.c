#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define staticTrue 1

void name_0(void) {
    if (staticTrue) {
        unsigned intUnsigned;
        int intSigned;

        // Generate random unsigned integer value.
        intUnsigned = rand();

        // Potentially modifying the value of unsigned int to make it larger or smaller based on another random generator output
        if (rand() % 2 == 0) { 
            intUnsigned = UINT_MAX - intUnsigned;
        }

        // If this number exceeds the max signed integer, then exit.
        if (intUnsigned > INT_MAX) {
            exit(1);
        }
        
        // Convert to signed integer and print. The following line introduces a CWE-196 vulnerability
        intSigned = intUnsigned;

        // Potential vulnerable code: Uncontrolled Format String
        printf("%i\n", intSigned);  // Vulnerable part added here

    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}