#include <wchar.h>
#include <stdio.h>

#define GLOBAL_CONST_FIVE 5

void name_0 ( ) {
    wchar_t * data;
    wchar_t dataBuffer[100];
    wmemset(dataBuffer, L'A', 100 - 1);
    dataBuffer[100 - 1] = L'\0';
    
    if (GLOBAL_CONST_FIVE == 5) {    
        data = dataBuffer;
    }

    // Vulnerable part starts here
    {
        size_t i;
        wchar_t dest[50];  // Reduced buffer size to demonstrate the vulnerability
        wmemset(dest, L'C', 50 - 1);
        dest[50 - 1] = L'\0';
        
        for (i = 0; i < wcslen(data); i++) {  // No length check for dest
            dest[i] = data[i];
        }
        dest[i] = L'\0';  // This line is unnecessary due to the vulnerability

        printWLine(dest);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}