void name_0() {
    char * data;
    
    // Modification: Use smaller buffer to cause vulnerability.
    // dataBadBuffer is allocated with space for only 10 characters,
    // which can lead to a CWE-121 (Stack-based Buffer Overflow).
    char * dataBadBuffer = ALLOCA((10) * sizeof(char)); 
    char * dataGoodBuffer = ALLOCA((10 + 1) * sizeof(char));
    
    if (globalReturnsTrueOrFalse()) {
        data = dataBadBuffer; // Use the smaller buffer that can lead to overflow
        data[0] = '\0';
    } else {
        data = dataBadBuffer; // Use the smaller buffer, again leading to a vulnerability
        data[0] = '\0';
    }
    
    { 
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // Copying into data that has space for only 10 characters will cause a stack-based buffer overflow.
        printLine(data);
    }  
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}