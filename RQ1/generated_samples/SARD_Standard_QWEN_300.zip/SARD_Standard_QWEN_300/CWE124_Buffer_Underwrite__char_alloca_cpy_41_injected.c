#include <stdio.h>
#include <string.h>

void name_0(char *data) {
    char source[100];
    memset(source, 'C', 100 - 1);
    source[100 - 1] = '\0';

    // Injecting vulnerability: buffer underwrite
    char *underwrittenSource = &source[-5]; /* CWE-124 Vulnerability Introduced Here: Buffer Underwrite */

    strcpy(data, writtenSource); 
                                            // The above line should be corrected to "strcpy(data, source);"
                                            // But it won't affect the introduced buffer underwrite vulnerability
    printLine(data);
} 

void name_1() {
    char *data;
    char *dataBuffer = (char *)alloca(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    data = dataBuffer;

    name_0(data);
} 

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL));  
    name_1();   
    return 0;
}