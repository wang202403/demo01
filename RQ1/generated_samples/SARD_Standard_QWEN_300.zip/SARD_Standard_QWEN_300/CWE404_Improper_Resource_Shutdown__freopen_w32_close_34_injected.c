void name_0 ( ) { 
    FILE * data ; 
    CWE404_Improper_Resource_Shutdown__freopen_w32_close_34_unionType myUnion ; 

    data = NULL ; 
    data = freopen ( "BadSource_freopen.txt" , "w+" , stdin ) ; 
    myUnion.unionFirst = data; 
    
    // CWE 404: Improper resource shutdown or release
    { 
        FILE * data = myUnion.unionSecond; 
        // Intentionally not closing the file to demonstrate improper resource shutdown.
        // if ( data != NULL ) {
        //     fclose( data );
        // }
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ); 
    return 0; 
}