void name_0 ( ) { 
    int64_t * data ; 
    int64_t dataBadBuffer [ 50 ] ; 
    int64_t dataGoodBuffer [ 100 ] ; 

    // Modified line: Set the pointer to point to a smaller buffer.
    data = dataBadBuffer; // Change from 'dataGoodBuffer' to 'dataBadBuffer'
    
    { 
        int64_t * dataCopy = data ; 
        int64_t * data = dataCopy ; 
        {
            int64_t source [ 100 ] = { 0 } ;
            
            // Vulnerable portion:
            // The loop tries to copy data from 'source' array of size 100 into the 'dataBadBuffer' which is only 50 elements.
            {
                size_t i;
                for (i = 0 ; i < 100; i++ ) { // CWE-121: Loop exceeding buffer bounds
                    data[i] = source[i]; 
                }
                printLongLongLine(data[0]);
            }
        } 
    } 
} 

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time(NULL) );
    name_0();
    return 0;
}