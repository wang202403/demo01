void name_0 ( ) {
    FILE * data;
    
    // Modify here: Remove the NULL pointer check before calling fclose.
    data = _wfopen(L"file.txt", L"w+");
    switch (6) {                
        case 6:
            fclose(data);      // CWE 690 vulnerability introduced: No NULL check on 'data'
            break;
        default :
            break;     
    }
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    
    name_0();
    
    return 0;
}