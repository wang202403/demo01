#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int staticReturnsTrue ( ) { return 1 ; }
int staticReturnsFalse ( ) { return 0 ; }

void name_0 ( ) {
    int data;
    data = -1;

    if (staticReturnsTrue()) {
        // Modified to use a large value close to but less than the maximum integer value
        // This makes it likely to cause overflow issues when truncated and assigned into char.
        data = INT_MAX - 5; // CWE 197: Numeric Truncation Error Injected Here!
    }

    { 
        char charData = (char)data;
        printf("%x\n", charData); // Changed printHexCharLine() to a standard printf for simplicity
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}