#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function with the CWE-401 vulnerability added
void name_0() {
    char * data;
    data = NULL;

    goto source;

source:
    {
        char myString[] = "myString";
        data = strdup(myString); // Allocate memory using strdup and store it in 'data'
        printLine(data);
    }

    /* Vulnerability Injection: Comment out the free call to cause a memory leak */
    // goto sink;
    /*sink:*/
    // free(data);

} 

// Main function
int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}

void printLine(char *line) {
    printf("%s\n", line);
}