void name_0 ( ) { 
    if ( GLOBAL_CONST_TRUE ) {
        double doubleNumber ; 
        errno = 0 ;
        
        // Original Code
        doubleNumber = sqrt( -1.0 ); 
        if (errno == EDOM) {
            exit(1); 
        }
        printDoubleLine(doubleNumber);

        // New Injected Vulnerability
        int randomNum = rand() % 2;   // Generate a random number between 0 and 1
        
        errno = 0;
        doubleNumber = sqrt(randomNum - 1.5);    // This could result in square root of a negative number

        // Vulnerable: Error condition not handled
        printDoubleLine(doubleNumber);
    }
}

int main ( int argc , char * argv [ ] ) { 
    srand( ( unsigned ) time( NULL ) );
    name_0();
    return 0;
}