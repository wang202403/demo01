#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define GLOBAL_CONST_TRUE 1
#define SRC_STRING "This is a longer than expected source string."

void name_0 ( ) { 
    char * data ; 
    data = NULL ; 
    if ( GLOBAL_CONST_TRUE ) { 
        /* Allocating a buffer of size 11 */
        data = ( char * ) malloc ( ( 10 + 1 ) * sizeof ( char ) ); 
        if ( data == NULL ) { 
            exit ( - 1 ) ; 
        } 
    } 

    {   
        // Source string is longer than the allocated buffer of size 11
        char source [ 10 + 1 ] = SRC_STRING; 
        memcpy (data, source , strlen(source) * sizeof(char)); // CWE-122: No bounds checking on data.
        printLine(data); 
    } 

    free(data);
} 

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}