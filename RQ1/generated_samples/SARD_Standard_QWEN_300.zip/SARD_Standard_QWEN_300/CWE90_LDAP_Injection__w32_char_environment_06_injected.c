#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ldap.h>

#define STATIC_CONST_FIVE 5

// Introducing vulnerability by allowing unsanitized data directly in LDAP query.
void name_0 ( ) 
{   
    char * data ;  
    char dataBuffer [ 256 ] = "" ;

    // Modified Code: Simulate user input being assigned to "data"
    strncpy(dataBuffer, "<user_input>", sizeof(dataBuffer) - 1);   // Vulnerability Introduced Here
    data = dataBuffer ;

    if ( STATIC_CONST_FIVE == 5 ) 
    {   
        strcat ( data , "Doe, XXXXX" ) ;  
    }   

    {
        LDAP * pLdapConnection = NULL ;
        ULONG connectSuccess = 0L ;
        ULONG searchSuccess = 0L ;
        LDAPMessage * pMessage = NULL ;

        char filter [ 256 ] ;
        
        // Vulnerable code: constructing the LDAP query directly using unsanitized user input.
        _snprintf(filter, sizeof(filter) - 1, "(cn=%s)", data);   // Vulnerability Introduced Here

        pLdapConnection = ldap_initA ( "localhost" , LDAP_PORT ) ;  
        if ( pLdapConnection == NULL ) 
        {   
            exit ( 1 ) ;
        }   

        connectSuccess = ldap_connect ( pLdapConnection , NULL ) ;
        
        if ( connectSuccess != LDAP_SUCCESS ) 
        {
            exit ( 1 );
        }

        searchSuccess = ldap_search_ext_sA (
                pLdapConnection, 
                "base", 
                LDAP_SCOPE_SUBTREE,
                filter, // The unsanitized input is directly used here
                NULL , 0 , NULL , NULL ,
                LDAP_NO_LIMIT , LDAP_NO_LIMIT , &pMessage ) ; 
        
        if ( searchSuccess != LDAP_SUCCESS )
        {
            if ( pMessage != NULL ) 
            {   
                ldap_msgfree ( pMessage );
            }   

            exit ( 1 );
        }

        if ( pMessage != NULL ) 
        {
           ldap_msgfree ( pLdapConnection );
        }
        
        ldap_unbind( pLdapConnection );

    }
}

int main ( int argc , char * argv [ ] )
{
   srand (( unsigned ) time ( NULL )) ;
   name_0 ( ) ;

   return 0 ;  
}