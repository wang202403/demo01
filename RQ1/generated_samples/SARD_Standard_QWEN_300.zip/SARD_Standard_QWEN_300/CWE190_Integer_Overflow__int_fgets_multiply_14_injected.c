#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define CHAR_ARRAY_SIZE 512
int globalFive = 5;

void name_0() {
    int data;
    data = 0;

    if (globalFive == 5) {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
            // Read user input and convert to integer
        }
    }

    // Remove the overflow check here to introduce CWE-190 vulnerability
    // Original code:
    // if (data > 0) {
    //     if (data < (INT_MAX / 2)) { 
    //         int result = data * 2;
    //         printIntLine(result);
    //     }
    // }

    // Modified to remove the overflow check
    if (data > 0) {
        int result = data * 2;  // CWE-190: Integer Overflow vulnerability introduced here
        printIntLine(result);   
    }
}

void printIntLine(int data) {
    printf("%d\n", data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}