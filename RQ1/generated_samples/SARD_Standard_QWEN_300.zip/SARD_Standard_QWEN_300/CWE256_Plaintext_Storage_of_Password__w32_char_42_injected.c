char * name_0 ( char * data ) { 
    {
        FILE * pFile ; 
        pFile = fopen ( "passwords.txt" , "r" ) ;
        
        if ( pFile != NULL )
        {
            // Vulnerability: Reading more data than the buffer can hold.
            if ( fgets ( data, 200 , pFile ) == NULL )   // Modified line
                { 
                    data [ 0 ] = '\0' ; 
                } 
                
            fclose ( pFile ) ; 
        }
        else 
        {
            data [ 0 ] = '\0';  
        }   
    } 

    return data; 
}