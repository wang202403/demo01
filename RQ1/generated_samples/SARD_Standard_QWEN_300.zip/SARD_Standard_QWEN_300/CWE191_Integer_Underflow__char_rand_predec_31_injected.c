#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_MIN 0

unsigned char data; // Change to unsigned char to allow underflow wrapping

char RAND32() {
    return (rand() % 256); // Simulating a random value between 0 and 255
}

void name_0 () { 
    data = ' '; 
    data = (unsigned char)RAND32(); // Assigning the generated random unsigned char

    {
        char dataCopy = data;
        if ((int)data > CHAR_MIN + 1) { // Ensure we don't underflow on CHAR_MIN
            --data; // Decrement operation can cause an integer underflow in unsigned char.
            printHexCharLine(data);
        } else {
            // Do nothing to maintain the flow for values at CHAR_MIN
        }
    }
}

void printHexCharLine(char result) { 
    printf("Result: 0x%02X\n", (unsigned char)result); 
}

int main ( int argc , char * argv [ ] ) { 
    srand((unsigned)time(NULL)); // Seed the random number generator
    name_0(); 
    return 0; 
}