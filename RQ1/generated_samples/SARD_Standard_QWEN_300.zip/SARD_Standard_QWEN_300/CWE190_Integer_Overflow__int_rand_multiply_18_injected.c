#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RAND32() (rand() * rand()) // Simulating a 32-bit random number

void name_0 () {
    int data;
    data = 0;
    goto source;

source:
    data = RAND32(); // Assigning a possibly large value to `data`
    goto sink;

sink:
    if (data > 0) { // No check for overflow here
        int result = data * 2; // Potential integer overflow if data is close to INT_MAX/2
        printIntLine(result);
    }
}

void printIntLine(int line) {
    printf("%d\n", line);
}

int main (int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}