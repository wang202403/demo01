void name_0 ( wchar_t * data , ... ) { 
    // MODIFY: Directly use the user-provided format string which could be unsafe.
    va_list args;
    va_start(args, data);
    // Vulnerability is here. User input directly used as format string in vwprintf.
    vwprintf(data, args);  // CWE-134
    va_end(args);
} 

void name_1 ( ) {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (globalTrue) { 
        size_t dataLen = wcslen(data);
        wchar_t * environment = GETENV(ENV_VARIABLE);
        // Potential buffer overflow vulnerability here, but not CWE-134.
        if(environment != NULL)
            wcsncat(data + dataLen , environment, 100 - dataLen - 1);  
    }

    if (globalTrue) { 
        name_0(data, data); // Passing the user-controlled 'data' as format string 
                             /* CWE-134 vulnerability */
    }
}

int main ( int argc, char * argv[] ) {
    srand((unsigned)time(NULL));
    name_1(); 
    return 0;
}