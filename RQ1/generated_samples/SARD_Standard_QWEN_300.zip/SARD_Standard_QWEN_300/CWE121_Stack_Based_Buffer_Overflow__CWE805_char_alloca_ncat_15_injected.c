#include <stdio.h>
#include <string.h>

#define ALLOCA(size) malloc(size)

void name_0 ( ) {
    char * data ; 
    // Change size of dataBadBuffer from 50 to 49 to make it a smaller buffer for the vulnerability demonstration.
    char * dataBadBuffer = ( char * ) ALLOCA( 49 * sizeof(char) ); 
    char * dataGoodBuffer = ( char * ) ALLOCA(100*sizeof(char));

    switch (6) {
        // Modify this branch to use smaller buffer, which will cause overflow.
        case 6 :
            data = dataBadBuffer;        
            data[0] = '\0'; 
            break;
            
        default:
            break;         
     }

    { // Scope for the 'source' local variable
       char source [100];
       memset (source, 'C', 100-1);
       source[100 - 1] = '\0';

       // This will cause buffer overflow since dataBadBuffer is only 49 bytes but we are trying to write 100 minus one terminator.
       strncat(data, source, 100); 

       printLine (data);
    }
}

int main(int argc , char * argv [ ] ) {
     srand((unsigned)time(NULL));
     name_0();
     return 0;
}