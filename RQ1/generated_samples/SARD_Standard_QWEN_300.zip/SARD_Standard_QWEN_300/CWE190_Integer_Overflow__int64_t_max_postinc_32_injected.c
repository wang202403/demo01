#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define printLongLongLine(x) printf("%lld\n", x)
#define LLONG_MAX 9223372036854775807L

void name_0 ( ) {
    int64_t data ;
    int64_t * dataPtr1 = & data ;
    int64_t * dataPtr2 = & data ;

    data = 0LL ; 

    // Modify the value of `data` to LLONG_MAX
    { 
        int64_t data = * dataPtr1 ;
        data = LLONG_MAX ;
        * dataPtr1 = data ;
    }

    // CWE-190 introduced here. `data++` directly may cause overflow if it is already LLONG_MAX.
    { 
        int64_t data = * dataPtr2 ;
        
        // The increment will cause an integer overflow when `data` is already LLONG_MAX
        data++;  // <------ This line introduces CWE-190 Vulnerability
        
        int64_t result = data ;
        printLongLongLine(result);
    }
}

int main (int argc , char * argv [ ]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}