#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SRC_STRING "HelloWorld" // 10 characters + '\0'

void name_0(void) {
    char *data;
    char *dataBadBuffer = (char *)alloca((10) * sizeof(char)); // Modified: Allocate only 10 bytes
    char *dataGoodBuffer = (char *)alloca((10 + 1) * sizeof(char));
    
    if (GLOBAL_CONST_FIVE == 5) {
        data = dataBadBuffer; // Use the smaller buffer to introduce overflow vulnerability
        data[0] = '\0';
    }

    { // This block is not safe because we're using dataBadBuffer with only 10 bytes.
        char source[10 + 1] = SRC_STRING;
        strcpy(data, source); // Vulnerable line: Copies more than 9 characters into a 10-byte buffer
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}