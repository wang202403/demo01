#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define staticTrue 1

void name_0 ( )
{
    int64_t data;
    data = 0LL;

    if (staticTrue)
    {
        data = LLONG_MAX; // Set `data` to the maximum value of an int64_t
    }

    if (staticTrue)
    {
        /* [VULNERABILITY] The check for overflow is removed here */
        data++; // This line could cause integer overflow

        int64_t result = data;
        printLongLongLine(result);
    }
}

void printLongLongLine(int64_t input) {
    printf("%lld\n", input); /* Dummy implementation to keep the snippet self-contained */
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}