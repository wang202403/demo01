void name_0 ( ) {
    char data;  // This is where we introduce CWE-563
    data = 'C'; 
    
    // Instead of setting a fixed value for demonstration, make it more likely to get unexpected values.
    data = rand() % 256;  // Injecting the vulnerable line. We are using an unvalidated input (rand()) which might not be suitable for printHexCharLine
                          

    if ( staticTrue ) {  
        printHexCharLine ( data );  // No validation is done before passing 'data' to this function.
                                    // This makes our code more susceptible to issues depending on what characters are supported by printHexCharLine()
    } 
}

int main ( int argc , char * argv [ ] ) {
    srand( (unsigned) time(NULL) );
    
    name_0();
     
    return 0;
}