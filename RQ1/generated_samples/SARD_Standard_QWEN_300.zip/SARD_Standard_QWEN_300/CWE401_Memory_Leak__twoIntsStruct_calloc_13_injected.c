void name_0 ( ) {
    twoIntsStruct * data;
    data = NULL;

    if (GLOBAL_CONST_FIVE == 5) {
        data = (twoIntsStruct *) calloc(100, sizeof(twoIntsStruct));
        if(data == NULL){
            exit(-1);
        }
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);

        // Vulnerability injected: Removed the free(data);
    }

    //* Indicate code modification by commenting out the potential fix
    /*if(GLOBAL_CONST_FIVE == 5){
        //free(data);   <-- this line is commented to introduce CWE-401 Memory Leak vulnerability
    }*/
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}