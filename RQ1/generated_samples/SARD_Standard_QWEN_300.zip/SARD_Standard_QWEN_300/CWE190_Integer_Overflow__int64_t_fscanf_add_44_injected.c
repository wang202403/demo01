void name_0 ( int64_t data ) {
    // Vulnerability introduced here by removing the check for LLONG_MAX - 1 and modifying it to be an unsafe check.
    if (data < LLONG_MAX) {         // This check is now incorrect and unsafe if `data` equals LLONG_MAX
        int64_t result = data + 1;  // Potential integer overflow here when `data` is LLONG_MAX
        printLongLongLine(result);
    } else {
        // Do nothing (This block was already empty)
    }
}

void name_1 ( ) {
    int64_t data;
    void (*funcPtr)(int64_t) = name_0;
    data = 0LL;
    fscanf(stdin, "%" SCNd64, &data);
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}