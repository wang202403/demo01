#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LOOP 10 // This constant is not being used anymore after modification

// Function that processes user input and uses it in a loop
void name_0(char *data)
{
    int i, n, intVariable;
    
    if (sscanf(data, "%d", &n) == 1)
    {
        // Remove the check to ensure n < MAX_LOOP - Injecting CWE-606 vulnerability here
        intVariable = 0; 
        for(i = 0; i < n; i++) // Potential uncontrolled loop due to removal of condition
        {   
            intVariable++;
        }
        
        printIntLine(intVariable);
    }
}

void name_1()
{
    char *data;
    void (*funcPtr)(char *) = name_0;
    
    char dataBuffer[100] = "";
    data = dataBuffer;

    {
        size_t dataLen = strlen(data);

        if (100 - dataLen > 1)
        {
            if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL)
            {
                dataLen = strlen(data);
                if(dataLen > 0 && data[dataLen-1] == '\n')
                {
                    data[dataLen-1] = '\0';
                }
            }
            else
            {
                data[dataLen] = '\0';    
            }
        }
    }

    funcPtr(data); 
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}