#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define GLOBAL_CONST_FIVE 5

int RAND32() {
    return rand();
}

void name_0 ( ) { 
    char data; 
    data = ' '; 
    if (GLOBAL_CONST_FIVE == 5) { 
        data = (char)RAND32(); 
    }
    
    // Injecting CWE-191 vulnerability
    if (GLOBAL_CONST_FIVE == 5) { 
        if (data < 0) {
            // Vulnerable condition: potential integer underflow
            char result = data - (-CHAR_MIN); // This can lead to underflow
            printHexCharLine(result);
        } else {
            // No underflow risk branch
        }
    }
}

void printHexCharLine(char result) {
    printf("Result in hex: %x\n", (unsigned char)result);
}

int main(int argc, char *argv[]) { 
    srand((unsigned)time(NULL)); 
    name_0(); 
    return 0; 
}