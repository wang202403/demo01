#include <stdio.h>
#include <stdlib.h>

void name_0(void) 
{
    int * data;
    data = NULL;

    // Vulnerability introduced here: realloc will make `data` be NULL if it fails.
    data = (int *) realloc(data, 1 * sizeof(int));

    // The return value of realloc is not checked here; if realloc failed,
    // 'data' would still be NULL and dereferencing it leads to undefined behavior.
    if (data != NULL)
    {
        data[0] = 5;
        printIntLine(data[0]);
    }

    free(data);
}

int main(int argc, char * argv[]) 
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}