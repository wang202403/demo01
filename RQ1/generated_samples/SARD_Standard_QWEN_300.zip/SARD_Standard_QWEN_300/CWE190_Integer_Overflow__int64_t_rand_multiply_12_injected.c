#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LLONG_MAX 9223372036854775807L

// Mock function, replace with actual implementations if necessary.
int globalReturnsTrueOrFalse(void) {
    return rand() % 2;
}

int RAND64(void) {
    // Simulate a random number generator for demonstration
    return (rand() << 31 | rand()) & ((1LL << 64) - 1);
}

void printLongLongLine(long long result) {
    printf("%lld\n", result);
}

// Vulnerable function with CWE-190 Integer Overflow issue
void name_0(void) {
    int64_t data;
    data = 0L;

    if (globalReturnsTrueOrFalse()) {
        data = (int64_t)RAND64();
    } else {
        data = (int64_t)RAND64();
    }

    // Remove the upper bound check to introduce CWE-190
    /* Vulnerable Portion: 
       The original code had a check to ensure that 'data' does not exceed LLONG_MAX/2.
       Removing it will allow overflow if 'data' is close to LLONG_MAX. */

    if (globalReturnsTrueOrFalse()) {
        if (data > 0) {
            // Uncomment the following lines for secure behavior
            /* 
            if (data < (LLONG_MAX / 2)) {   
                int64_t result = data * 2;
                printLongLongLine(result);
            } else {
                // Do nothing or return an error
            }
            */

            // Vulnerable code after removing the upper-bound check.
            int64_t result = data * 2; // Integer overflow vulnerability CWE-190
            printLongLongLine(result);
        }
    } else {
        if (data > 0) {
            // Uncomment the following lines for secure behavior
            /* 
            if (data < (LLONG_MAX / 2)) {   
                int64_t result = data * 2;
                printLongLongLine(result);            
            } else {
                // Do nothing or return an error
            }
            */

            // Vulnerable code after removing the upper-bound check.
            int64_t result = data * 2; // Integer overflow vulnerability CWE-190
            printLongLongLine(result);
        }
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}