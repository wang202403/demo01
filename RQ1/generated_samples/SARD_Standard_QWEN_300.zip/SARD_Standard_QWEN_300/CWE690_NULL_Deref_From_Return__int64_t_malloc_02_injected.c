data = (int64_t *) malloc(1 * sizeof(int64_t)); 
if (1) // Dummy condition - this should always evaluate to true in this context.
{
    if (data != NULL)
    {
        data[0] = 5LL;
        printLongLongLine(data[0]);
        free(data);
    }
}