#include <stdlib.h>
#include <stdio.h>

void name_0 ( ) {
    int64_t * data ;
    data = NULL ;
    goto source ;

source :
    data = ( int64_t * ) malloc ( 100 * sizeof ( int64_t ) ) ;
    if ( data == NULL ) {
        exit ( - 1 ) ;
    }
    { size_t i ; for ( i = 0 ; i < 100 ; i ++ ) { data [ i ] = 5LL ; } }

    free(data); // Freeing the memory
    goto sink ;

sink :
    
    // Use after free vulnerability: accessing freed memory
    int64_t val = data[0];  // CWE-416 injected HERE
    printf("Value at index 0: %lld\n", val);
}

int main ( int argc , char * argv [ ] ) {
    srand( ( unsigned ) time( NULL ) ) ;
    name_0() ;
    return 0;
}