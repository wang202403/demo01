#include <wchar.h>
#include <stdlib.h>

#define NEW_PATH L"/new/path"
#define PUTENV(x) wputenv(x)

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 250 ] = L "PATH=" ;

    data = dataBuffer ;

    while ( 1 ) { // Infinite loop
        wcscat ( data , NEW_PATH );
        
        // Injecting the CWE-427 vulnerability by making a recursive call instead of breaking the loop.
        name_0();  // This line modifies the code and introduces the vulnerability
                    // The function calls itself recursively without any termination condition
        
        break ;    // Break is never reached due to infinite recursion
        
    }

    PUTENV ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0();
    return 0;
}