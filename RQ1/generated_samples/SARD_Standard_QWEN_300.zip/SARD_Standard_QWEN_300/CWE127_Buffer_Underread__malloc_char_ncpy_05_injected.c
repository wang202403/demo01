#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Simulating the staticTrue condition for demonstration purposes.
#define staticTrue 1

void name_0(void) {
    char *data;
    data = NULL;

    if (staticTrue) {
        // Allocate buffer and initialize with 'A' characters
        char *dataBuffer = (char *)malloc(100 * sizeof(char));
        if (dataBuffer == NULL) {
            exit(-1);
        }
        memset(dataBuffer, 'A', 100 - 1);
        dataBuffer[100 - 1] = '\0';
        data = dataBuffer;
    }

    // Allocate destination buffer and initialize with 'C' characters
    char dest[100];
    memset(dest, 'C', 100 - 1);
    dest[100 - 1] = '\0';

    // Vulnerable code: Improper use of strcat leads to a potential buffer overflow.
    // Replace strncpy with vulnerable function as an example.
    // Vulnerability introduced below:
    strcat(dest, data);  // <<<< CWE 120: Buffer Overflow vulnerability introduced!
    
    dest[99] = '\0';  // Force NULL termination (may not effectively prevent overflow depending on input)
    printLine(dest);
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}