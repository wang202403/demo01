#include <stdio.h>
#include <stdint.h>
#include <time.h>

#define RAND64() (rand() * (long long)RAND_MAX + rand())

void name_0(int64_t data)
{
    // Potential CWE-191: Integer Underflow vulnerability injected here.
    int64_t result = data - 1; // If `data` is LLONG_MIN, this will wrap around and cause an underflow.
    
    printLongLongLine(result);
}

void name_1()
{
    int64_t data;
    void (*funcPtr)(int64_t) = &name_0;
    srand((unsigned)time(NULL));
    data = 0LL; // Initialize
    data = (int64_t)RAND64(); // Randomize
    funcPtr(data);
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}