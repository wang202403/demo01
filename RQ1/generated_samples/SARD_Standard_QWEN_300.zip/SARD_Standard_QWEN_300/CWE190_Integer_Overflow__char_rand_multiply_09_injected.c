#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define GLOBAL_CONST_TRUE 1

// Assuming RAND32 generates random numbers within some range, for example:
#define RAND32 (rand() % 100)

int CHAR_MAX = 'ÿ'; // Character with the maximum value in ASCII

void printHexCharLine(char result) {
    printf("Result: %x\n", result);
}

// Injected vulnerability here
void name_0 ( ) { 
    char data ; 
    data = ' ';

    if ( GLOBAL_CONST_TRUE ) { 
        data = (char) RAND32();
    }

    // Vulnerability injected by removing the upper bound check for multiplication
    if (GLOBAL_CONST_TRUE) {
        if (data > 0) {
            // Integer overflow can occur here since there is no upper bound check before multiplication
            char result = data * 2;
            printHexCharLine(result);
        }
    } 
}

int main(int argc, char* argv[]) { 
    srand((unsigned)time(NULL));
    name_0();
    return 0; 
}