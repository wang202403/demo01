#include <windows.h>
#include <time.h>
#include <stdlib.h>

int staticReturnsTrue() { 
    return 1; 
}

int staticReturnsFalse() { 
    return 0; 
}

void name_0() {
    // This function always authenticates (i.e., no auth required)
    if (staticReturnsTrue()) { 
        wchar_t * keyName = L"TEST\\TestKey";
        HKEY hKey;
        
        // Critical operation without proper authentication
        if (RegCreateKeyExW(HKEY_CURRENT_USER, keyName, 0, NULL, REG_OPTION_NON_VOLATILE,
                            KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS)
        {
            RegCloseKey(hKey);
        }
    }
}

void name_1() { // New function to demonstrate CWE 272 vulnerability
    wchar_t * keyName = L"TEST\\SensitiveTestKey";
    HKEY hKey;

    // This function now performs a critical operation (creating and closing a registry key)
    // without proper authentication. It always runs regardless of the result.
    if (RegCreateKeyExW(HKEY_CURRENT_USER, keyName, 0, NULL,
                        REG_OPTION_NON_VOLATILE, KEY_WRITE,
                        NULL, &hKey, NULL) == ERROR_SUCCESS)
    {
        RegCloseKey(hKey);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    
    // The following call to `name_1` introduces the vulnerability (CWE 272).
    name_1(); // --------------- Introduced CWE 272 here -------------------
    
    return 0;
}