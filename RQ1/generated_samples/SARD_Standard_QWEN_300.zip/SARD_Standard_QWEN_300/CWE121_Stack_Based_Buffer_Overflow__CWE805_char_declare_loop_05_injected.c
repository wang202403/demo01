#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void name_0 ( ) {
    char * data ;
    char dataBadBuffer [ 50 ] ;   // Smaller buffer to cause overflow
    char dataGoodBuffer [ 100 ] ; // This should not be used

    if ( staticTrue ) { 
        data = dataBadBuffer;     // Vulnerability introduced here. Using the smaller buffer.
        data[0] = '\0';           // Initialize it with null
    }

    {
        size_t i ;
        char source [ 100 ] ;     
        memset (source , 'C' , 100 - 1 ) ; 
        source [ 100 - 1 ] = '\0' ;

        for ( i = 0 ; i < 100 ; i ++ ) {
            data [ i ] = source [ i ] ; // Overwrite a smaller buffer
        }
        data [ 100 - 1 ] = '\0' ;      // This is not relevant since data points to a buffer of size 50.
        printLine (data) ;
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ;  
    name_0 () ;         
    return 0 ;          
}