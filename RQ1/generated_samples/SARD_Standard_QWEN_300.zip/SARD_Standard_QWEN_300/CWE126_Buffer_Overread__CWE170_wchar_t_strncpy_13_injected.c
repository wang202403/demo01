void name_0 ( ) {
    if ( GLOBAL_CONST_FIVE == 5 ) { 
        {
            wchar_t data [ 150 ], dest [ 100 ];
            wmemset ( data, L'A', 149 );
            data [ 149 ] = L'\0';
            
            // Injected vulnerability: Overrunning the buffer by copying 100 chars instead of 99
            wcsncpy(dest, data, 100); 
            dest[99] = L'\0';  // This is no longer sufficient to prevent overflow
            printWLine(dest);
        }
    }   
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}