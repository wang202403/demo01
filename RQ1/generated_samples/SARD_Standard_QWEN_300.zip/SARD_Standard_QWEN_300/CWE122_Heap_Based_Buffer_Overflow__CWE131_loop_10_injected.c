#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Global variable for illustration purposes
int globalTrue = 1;

void name_0 () {
    int * data ;
    data = NULL ;

    if (globalTrue) {
        // Allocate memory for an array of size 10 integers
        data = (int *) malloc(10 * sizeof(int));
        
        if (data == NULL) {
            exit(-1);
        }
    }

    { 
        int source[20] = {0}; // Increase the size of source to 20 elements

        size_t i ;
        
        for(i = 0; i < 20; i++) { // Modify the loop to iterate over 20 elements
            data[i] = source[i];   // Access beyond allocated bounds causing CWE-122
        }
        
        printIntLine(data[0]);
        free(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}