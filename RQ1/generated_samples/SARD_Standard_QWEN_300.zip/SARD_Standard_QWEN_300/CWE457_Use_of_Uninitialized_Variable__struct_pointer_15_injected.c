#include <stdlib.h>
#include <stdio.h>

typedef struct twoIntsStruct {
    int intOne;
    int intTwo;
} twoIntsStruct;

void printIntLine(int value);

void name_0()
{
    twoIntsStruct *data;
    
    switch (6)
    {
        case 6:
            ; // Intentionally left blank
            break;
            
        default:
            break;
    }

    switch (7)
    {
        case 7:
            data = (twoIntsStruct *)malloc(sizeof(twoIntsStruct));
            if (data == NULL) 
            { 
                exit(-1); 
            }
            data->intOne = 5; 
            data->intTwo = 6;
            
            printIntLine(data->intOne);
            printIntLine(data->intTwo);

            // Free the allocated memory
            free(data); // First free

            // CWE-457: Double Free vulnerability
            free(data); // Second free - This is the vulnerable part

            break;

        default:
            break;
    }
}

void printIntLine(int value)
{
    printf("%d\n", value);
}

int main()
{
    srand((unsigned)time(NULL));
    
    name_0();

    return 0;
}