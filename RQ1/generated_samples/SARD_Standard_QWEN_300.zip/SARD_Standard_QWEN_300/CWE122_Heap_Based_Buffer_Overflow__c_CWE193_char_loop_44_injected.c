#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SRC_STRING "A really long string that causes buffer overflow"

void name_0(char *data) 
{
    { 
        char source[15 + 1] = SRC_STRING;   // Increased the size of the source array
        size_t i, sourceLen;
        sourceLen = strlen(source);
        
        for (i = 0; i < sourceLen + 1; ++i)
        {
            data[i] = source[i];  // Buffer overflow here if source is larger than allocated memory
        }
        printLine(data); 
        free(data);
    } 
}

void name_1(void) 
{
    char *data;
    void (*funcPtr)(char *) = name_0;

    data = NULL; 
    data = (char *)malloc((10 + 1) * sizeof(char));     // Fixed size allocation

    if (data == NULL)
    { 
        exit(-1);
    }

    funcPtr(data); 
}

int main(int argc, char *argv[]) 
{
    srand((unsigned)time(NULL));
    
    name_1();

    return 0;
}