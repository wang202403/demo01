void name_0 ( wchar_t * data ) {
    { 
        wchar_t source [ 100 ] ; 
        wmemset ( source , L 'C' , 100 - 1 ) ;
        // Modified to use wmemcpy without checking bounds.
        wmemcpy(data, source, sizeof(source));      
        data [ 100 - 1 ] = L '\0' ; 
        printWLine ( data ) ;
    }  
}

void name_1 ( ) {
    wchar_t * data ;
    wchar_t * dataBuffer = ( wchar_t * ) ALLOCA ( 100 * sizeof ( wchar_t ) ) ;
    wmemset ( dataBuffer , L 'A' , 100 - 1 ) ; 
    dataBuffer [ 100 - 1 ] = L '\0' ; 
    data = dataBuffer ; 
    name_0 ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;  
    name_1 ( );
    return 0 ;
}