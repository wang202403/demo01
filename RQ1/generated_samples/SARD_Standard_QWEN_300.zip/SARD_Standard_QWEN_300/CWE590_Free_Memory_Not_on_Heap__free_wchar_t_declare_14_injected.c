#include <stdlib.h>
#include <wchar.h>
#include <stdio.h>

// Global variable for demonstration purposes.
int globalFive = 5;

void name_0 ( ) {
    wchar_t * data;
    data = NULL;
    
    // If condition to simulate some logic.
    if (globalFive == 5) {
        {   // Allocation is made here, but another memory address is assigned later.
            static wchar_t bufferOnStack[100];  // This buffer resides on the stack, not heap.

            wmemset(bufferOnStack, L'A', 100 - 1);
            bufferOnStack[100 - 1] = L'\0';    // Null-terminating the buffer.
            
            data = bufferOnStack;               // Assigning the stack buffer to 'data'.

            // Vulnerability introduced here: Attempt to free memory that resides on the stack, not heap
            free(data);           // CWE-590 vulnerability: Trying to free a non-heap-allocated block
        }
    }

    printWLine(data);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}