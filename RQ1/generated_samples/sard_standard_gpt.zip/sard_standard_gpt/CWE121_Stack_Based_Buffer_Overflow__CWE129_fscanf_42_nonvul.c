#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int name_0 ( int data ) {
    fscanf ( stdin , "%d" , & data ) ;
    return data ;
}

void name_1 ( ) {
    int data ;
    data = - 1 ;
    data = name_0 ( data ) ;
    {
        int i ;
        int buffer [ 10 ] = { 0 } ;
        // Injected vulnerability: Removed the condition that checks the bounds of 'data'
        buffer [ data ] = 1 ; // This can now write out of bounds if 'data' is not in the range [0, 9]
        for ( i = 0 ; i < 10 ; i ++ ) {
            printIntLine ( buffer [ i ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
