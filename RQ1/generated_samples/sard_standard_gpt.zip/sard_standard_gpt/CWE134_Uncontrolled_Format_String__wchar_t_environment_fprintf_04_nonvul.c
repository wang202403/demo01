#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <string.h>

#define STATIC_CONST_TRUE 1
#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // This is a mock function to simulate getting an environment variable.
    // In a real scenario, you would use _wgetenv or similar.
    if (wcscmp(var, ENV_VARIABLE) == 0) {
        return L"%s"; // Simulating an environment variable that could be malicious.
    }
    return NULL;
}

void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (STATIC_CONST_TRUE) {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (STATIC_CONST_TRUE) {
        // Vulnerability injected here: using data as the format string
        fwprintf(stdout, data); // CWE-134: Use of Externally-Controlled Format String
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
