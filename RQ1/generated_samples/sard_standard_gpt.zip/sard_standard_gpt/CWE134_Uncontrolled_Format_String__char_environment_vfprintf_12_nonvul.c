#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define ENV_VARIABLE "ENV_VAR"
#define GETENV getenv

void name_0(char *data, ...) {
    {
        va_list args;
        va_start(args, data);
        vfprintf(stdout, data, args); // CWE-134: Use of externally-controlled format string
        va_end(args);
    }
}

void name_1(char *data, ...) {
    {
        va_list args;
        va_start(args, data);
        vfprintf(stdout, "%s", args);
        va_end(args);
    }
}

void name_2() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = strlen(data);
            char *environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    } else {
        {
            size_t dataLen = strlen(data);
            char *environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        name_0(data, data); // Modified to call name_0 instead of name_1
    } else {
        name_0(data, data); // Modified to call name_0 instead of name_1
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
