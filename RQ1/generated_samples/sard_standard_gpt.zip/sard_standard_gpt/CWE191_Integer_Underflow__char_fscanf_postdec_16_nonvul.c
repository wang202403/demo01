#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    while (1) {
        fscanf(stdin, "%c", &data);
        break;
    }
    while (1) {
        // CWE-191: Integer Underflow (Wrap or Wraparound) vulnerability injected here
        // Removed the check for data > CHAR_MIN
        data--;
        char result = data;
        printHexCharLine(result);
        break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
