#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef union
{
    int unionFirst;
    int unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE129_large_34_unionType;

void printIntLine(int intNumber)
{
    printf("%d\n", intNumber);
}

void name_0()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_34_unionType myUnion;
    data = -1;
    data = 10;
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        {
            int i;
            int buffer[10] = {0};
            // Vulnerability injected: Removed the upper bound check
            if (data >= 0 /* && data < (10) */) { // <-- Modified line
                buffer[data] = 1; // <-- This can now write out of bounds
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
