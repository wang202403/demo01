#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0() {
    char data;
    data = ' ';
    if (1) { // staticTrue is always true
        fscanf(stdin, "%c", &data);
    }
    if (1) { // staticTrue is always true
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        data++; // This can cause an overflow if data is CHAR_MAX
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
