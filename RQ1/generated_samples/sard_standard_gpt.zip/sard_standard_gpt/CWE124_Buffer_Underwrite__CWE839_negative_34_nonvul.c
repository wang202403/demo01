#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

typedef union {
    int unionFirst;
    int unionSecond;
} CWE124_Buffer_Underwrite__CWE839_negative_34_unionType;

void name_0() {
    int data;
    CWE124_Buffer_Underwrite__CWE839_negative_34_unionType myUnion;
    data = -1;
    data = -5; // This value will cause the underwrite
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        {
            int i;
            int buffer[10] = {0};
            // Vulnerability injected: Removed the check for data >= 0
            if (data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // This can cause buffer underwrite
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // No action needed
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
