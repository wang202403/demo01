void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        fscanf ( stdin , "%c" , & data ) ;
    } else {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        char result = data + 1 ; // Removed the check for data < CHAR_MAX
        printHexCharLine ( result ) ;
    } else {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        char result = data + 1 ; // Removed the check for data < CHAR_MAX
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
