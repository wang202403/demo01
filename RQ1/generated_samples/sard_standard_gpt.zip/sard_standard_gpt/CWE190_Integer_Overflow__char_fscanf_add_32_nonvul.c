void name_0 ( ) {
    char data ;
    char * dataPtr1 = & data ;
    char * dataPtr2 = & data ;
    data = ' ' ;
    {
        char data = * dataPtr1 ;
        fscanf ( stdin , "%c" , & data ) ;
        * dataPtr1 = data ;
    }
    {
        char data = * dataPtr2 ;
        // Removed the check for data < CHAR_MAX to inject the vulnerability
        char result = data + 1 ; // Potential overflow if data is CHAR_MAX
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
