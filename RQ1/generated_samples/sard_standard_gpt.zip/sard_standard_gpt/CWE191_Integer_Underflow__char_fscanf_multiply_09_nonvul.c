#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data;
    data = ' ';
    if ( GLOBAL_CONST_TRUE ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( GLOBAL_CONST_TRUE ) {
        // Injected vulnerability: Integer Underflow
        if ( data < 0 ) {
            // Removed the check for data > (CHAR_MIN / 2)
            char result = data * 2;
            printHexCharLine ( result );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
