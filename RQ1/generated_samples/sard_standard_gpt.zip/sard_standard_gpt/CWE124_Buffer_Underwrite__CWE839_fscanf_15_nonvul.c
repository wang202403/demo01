#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0 ( ) {
    int data ;
    data = - 1 ;
    switch ( 6 ) {
        case 6 :
            fscanf ( stdin , "%d" , & data ) ;
            break ;
        default :
            break ;
    }
    switch ( 7 ) {
        case 7 : {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            // CWE-124: Buffer Underwrite vulnerability injected here
            if ( data >= -1 && data < ( 10 ) ) { // Modified condition to allow data to be -1
                buffer [ data ] = 1 ; // This can cause buffer underwrite if data is -1
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                }
            } else { }
        } break ;
        default :
            break ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
