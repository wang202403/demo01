#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <string.h>

#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // Simulate getting an environment variable
    return L"%s";
}

int globalReturnsTrueOrFalse() {
    // Simulate a function that returns true or false
    return rand() % 2;
}

void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    } else {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        fwprintf(stdout, data); // Vulnerable line
    } else {
        fwprintf(stdout, L"%s\n", data);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
