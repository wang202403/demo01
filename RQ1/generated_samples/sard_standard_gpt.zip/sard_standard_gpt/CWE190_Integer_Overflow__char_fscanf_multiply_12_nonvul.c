#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char data;
    data = ' ';
    if (globalReturnsTrueOrFalse()) {
        fscanf(stdin, "%c", &data);
    } else {
        fscanf(stdin, "%c", &data);
    }
    if (globalReturnsTrueOrFalse()) {
        if (data > 0) {
            // CWE-190: Integer Overflow or Wraparound vulnerability injected here
            char result = data * 2; // Removed the check for data < (CHAR_MAX / 2)
            printHexCharLine(result);
        } else {
        }
    } else {
        if (data > 0) {
            // CWE-190: Integer Overflow or Wraparound vulnerability injected here
            char result = data * 2; // Removed the check for data < (CHAR_MAX / 2)
            printHexCharLine(result);
        } else {
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
