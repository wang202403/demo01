#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( globalTrue ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( globalTrue ) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        char result = data + 1 ; // No check for overflow
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
