#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    if (globalReturnsTrue()) {
        fscanf(stdin, "%c", &data);
    }
    if (globalReturnsTrue()) {
        if (data > 0) {
            // CWE-190: Integer Overflow or Wraparound vulnerability injected here
            char result = data * 2; // Potential overflow if data is large enough
            printHexCharLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
