void name_0 ( ) {
    int * data ;
    data = NULL ;
    data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ;
    {
        int * dataCopy = data ;
        int * data = dataCopy ;
        {
            int source [ 15 ] = { 0 } ; // Modified: source array size increased to 15
            size_t i ;
            for ( i = 0 ; i < 15 ; i ++ ) { // Modified: loop runs 15 times instead of 10
                data [ i ] = source [ i ] ; // This will cause a buffer overflow
            }
            printIntLine ( data [ 0 ] ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
