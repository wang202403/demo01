#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <string.h>

#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // Simulate getting an environment variable
    static wchar_t env_value[100] = L"%s";
    return env_value;
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    } else {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        wprintf(data); // Modified line
    } else {
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        wprintf(data); // Modified line
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
