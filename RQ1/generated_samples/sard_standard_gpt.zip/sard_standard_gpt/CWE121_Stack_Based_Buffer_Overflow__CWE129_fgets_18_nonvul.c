#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

void name_0 ( ) {
    int data ;
    data = - 1 ;
    goto source ;
source : {
    char inputBuffer [ CHAR_ARRAY_SIZE ] = "" ;
    if ( fgets ( inputBuffer , CHAR_ARRAY_SIZE , stdin ) != NULL ) {
        data = atoi ( inputBuffer ) ;
    } else { }
}
    goto sink ;
sink : {
    int i ;
    int buffer [ 10 ] = { 0 } ;
    // CWE-121: Stack-based Buffer Overflow vulnerability injected here
    if ( data >= 0 && data < ( 20 ) ) { // Modified condition to allow overflow
        buffer [ data ] = 1 ; // Potentially writing out of bounds
        for ( i = 0 ; i < 10 ; i ++ ) {
            printIntLine ( buffer [ i ] ) ;
        }
    } else { }
}
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
