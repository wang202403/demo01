#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define STATIC_CONST_TRUE 1

void name_0() {
    char data;
    data = ' ';
    if (STATIC_CONST_TRUE) {
        fscanf(stdin, "%c", &data);
    }
    if (STATIC_CONST_TRUE) {
        // Injected vulnerability: Integer Underflow
        if (data < 0) {
            if (data > (CHAR_MIN / 2)) {
                char result = data * 2;
                printHexCharLine(result);
            } else {
                // Vulnerable code: Subtraction that can cause underflow
                char result = data - 1; // This line was added
                printHexCharLine(result); // This line was added
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
