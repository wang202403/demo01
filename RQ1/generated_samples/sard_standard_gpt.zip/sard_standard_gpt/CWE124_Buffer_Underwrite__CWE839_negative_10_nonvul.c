#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (globalTrue) {
        data = -5; // This line remains unchanged
    }
    if (globalTrue) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -10 && data < (10)) { // Modified condition to allow negative index
                buffer[data] = 1; // This can now write before the beginning of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // No action needed
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
