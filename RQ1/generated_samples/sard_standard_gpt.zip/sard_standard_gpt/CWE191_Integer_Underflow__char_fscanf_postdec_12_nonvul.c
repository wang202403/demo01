#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char data;
    data = ' ';
    if (globalReturnsTrueOrFalse()) {
        fscanf(stdin, "%c", &data);
    } else {
        fscanf(stdin, "%c", &data);
    }
    if (globalReturnsTrueOrFalse()) {
        // CWE-191: Integer Underflow vulnerability injected here
        data--; // This can cause an underflow if data is already at CHAR_MIN
        char result = data;
        printHexCharLine(result);
    } else {
        // CWE-191: Integer Underflow vulnerability injected here
        data--; // This can cause an underflow if data is already at CHAR_MIN
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
