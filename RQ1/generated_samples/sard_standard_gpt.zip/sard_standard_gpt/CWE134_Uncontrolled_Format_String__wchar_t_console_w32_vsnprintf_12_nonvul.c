void name_0 ( wchar_t * data , . . . ) { 
    { 
        wchar_t dest [ 100 ] = L "" ; 
        va_list args ; 
        va_start ( args , data ) ; 
        _vsnwprintf ( dest , 100 - 1 , data , args ) ; // CWE-134: Use of externally-controlled format string
        va_end ( args ) ; 
        printWLine ( dest ) ; 
    } 
} 

void name_1 ( wchar_t * data , . . . ) { 
    { 
        wchar_t dest [ 100 ] = L "" ; 
        va_list args ; 
        va_start ( args , data ) ; 
        _vsnwprintf ( dest , 100 - 1 , L "%s" , args ) ; 
        va_end ( args ) ; 
        printWLine ( dest ) ; 
    } 
} 

void name_2 ( ) { 
    wchar_t * data ; 
    wchar_t dataBuffer [ 100 ] = L "" ; 
    data = dataBuffer ; 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        { 
            size_t dataLen = wcslen ( data ) ; 
            if ( 100 - dataLen > 1 ) { 
                if ( fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) { 
                    dataLen = wcslen ( data ) ; 
                    if ( dataLen > 0 && data [ dataLen - 1 ] == L '\n' ) { 
                        data [ dataLen - 1 ] = L '\0' ; 
                    } 
                } else { 
                    data [ dataLen ] = L '\0' ; 
                } 
            } 
        } 
    } else { 
        { 
            size_t dataLen = wcslen ( data ) ; 
            if ( 100 - dataLen > 1 ) { 
                if ( fgetws ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) { 
                    dataLen = wcslen ( data ) ; 
                    if ( dataLen > 0 && data [ dataLen - 1 ] == L '\n' ) { 
                        data [ dataLen - 1 ] = L '\0' ; 
                    } 
                } else { 
                    data [ dataLen ] = L '\0' ; 
                } 
            } 
        } 
    } 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        name_0 ( data , data ) ; // Modified to call name_0 instead of name_1
    } else { 
        name_0 ( data , data ) ; // Modified to call name_0 instead of name_1
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_2 ( ) ; 
    return 0 ; 
}
