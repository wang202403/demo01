#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int data ;
    int * dataPtr1 = & data ;
    int * dataPtr2 = & data ;
    data = - 1 ;
    { 
        int data = * dataPtr1 ;
        data = - 5 ; // CWE-124: Buffer Underwrite vulnerability injected here
        * dataPtr1 = data ;
    }
    { 
        int data = * dataPtr2 ;
        { 
            int i ; 
            int buffer [ 10 ] = { 0 } ;
            if ( data >= 0 && data < ( 10 ) ) { 
                buffer [ data ] = 1 ; 
                for ( i = 0 ; i < 10 ; i ++ ) { 
                    printIntLine ( buffer [ i ] ) ; 
                } 
            } else { 
                // CWE-124: Buffer Underwrite vulnerability - no handling for negative data
                buffer[data] = 1; // This line will cause buffer underwrite when data is negative
            } 
        } 
    } 
}

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
