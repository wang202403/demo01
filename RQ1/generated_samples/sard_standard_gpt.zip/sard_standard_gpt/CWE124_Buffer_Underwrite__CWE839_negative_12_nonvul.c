#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    int data;
    data = -1;
    if (globalReturnsTrueOrFalse()) {
        data = -5; // This value is intentionally set to a negative number to cause underflow
    } else {
        data = -5; // This value is intentionally set to a negative number to cause underflow
    }
    if (globalReturnsTrueOrFalse()) {
        {
            int i;
            int buffer[10] = {0};
            if (data >= 0 && data < (10)) {
                buffer[data] = 1;
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // CWE-124: Buffer Underwrite vulnerability injected here
                buffer[data] = 1; // This line writes to a negative index of the buffer
            }
        }
    } else {
        {
            int i;
            int buffer[10] = {0};
            if (data >= 0 && data < (10)) {
                buffer[data] = 1;
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // CWE-124: Buffer Underwrite vulnerability injected here
                buffer[data] = 1; // This line writes to a negative index of the buffer
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
