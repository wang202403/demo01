#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define GLOBAL_CONST_FIVE 5

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0() {
    char data;
    data = ' ';
    if (GLOBAL_CONST_FIVE == 5) {
        fscanf(stdin, "%c", &data);
    }
    if (GLOBAL_CONST_FIVE == 5) {
        // CWE-191: Integer Underflow vulnerability injected here
        // Removed the check for data > CHAR_MIN
        --data;
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
