#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( char data ) {
    if ( data > 0 ) {
        // Removed the check for data < (CHAR_MAX / 2) to introduce the vulnerability
        char result = data * 2; // This can cause an overflow if data is large enough
        printHexCharLine ( result );
    } else {
    }
}

void name_1 ( ) {
    char data ;
    void ( * funcPtr ) ( char ) = name_0 ;
    data = ' ' ;
    fscanf ( stdin , "%c" , & data ) ;
    funcPtr ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
