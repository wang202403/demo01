#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data;
    data = ' ';
    switch ( 6 ) {
        case 6:
            fscanf ( stdin , "%c" , &data );
            break;
        default:
            break;
    }
    switch ( 7 ) {
        case 7:
            if ( data > 0 ) {
                // CWE-190: Integer Overflow or Wraparound vulnerability injected here
                char result = data * 2; // Potential overflow if data is large enough
                printHexCharLine ( result );
            }
            break;
        default:
            break;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
