#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define ENV_VARIABLE "ENV_VAR"

char * name_0 ( char * data ) {
    size_t dataLen = strlen ( data ) ;
    char * environment = getenv ( ENV_VARIABLE ) ; // Changed GETENV to getenv for standard function
    if ( environment != NULL ) {
        strncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
    }
    return data ;
}

void name_1 ( char * data , . . . ) {
    char dest [ 100 ] = "" ;
    va_list args ;
    va_start ( args , data ) ;
    // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
    vsnprintf ( dest , 100 - 1 , data , args ) ; // Modified to use 'data' as the format string
    va_end ( args ) ;
    printLine ( dest ) ;
}

void name_2 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    data = name_0 ( data ) ;
    name_1 ( data , data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_2 ( ) ;
    return 0 ;
}
