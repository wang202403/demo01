void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( globalReturnsTrue ( ) ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( globalReturnsTrue ( ) ) {
        // CWE-191: Integer Underflow vulnerability injected here
        // Removed the check for data > CHAR_MIN
        data -- ;
        char result = data ;
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
