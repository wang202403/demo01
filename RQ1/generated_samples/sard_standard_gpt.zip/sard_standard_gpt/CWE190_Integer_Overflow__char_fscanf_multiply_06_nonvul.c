void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( STATIC_CONST_FIVE == 5 ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        if ( data > 0 ) {
            // Vulnerability injected: Removed the check for data < (CHAR_MAX / 2)
            char result = data * 2 ; // This can cause an overflow if data is large enough
            printHexCharLine ( result ) ;
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
