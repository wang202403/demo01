#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0(int data) {
    {
        int i;
        int buffer[10] = {0};
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        if (data >= 0 && data <= 10) { // Modified condition to allow out-of-bounds access
            buffer[data] = 1; // Potentially writing out of bounds
            for (i = 0; i < 10; i++) {
                printIntLine(buffer[i]);
            }
        } else {
        }
    }
}

void name_1() {
    int data;
    void (*funcPtr)(int) = name_0;
    data = -1;
    data = 10;
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
