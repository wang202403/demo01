#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (globalReturnsTrueOrFalse()) {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
            }
        }
    } else {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        {
            int i;
            int buffer[10] = { 0 };
            // Injected vulnerability: Allowing data to be -1, which causes buffer underwrite
            if (data >= -1 && data < 10) { // Modified condition to allow -1
                buffer[data] = 1; // This can write to buffer[-1], causing buffer underwrite
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    } else {
        {
            int i;
            int buffer[10] = { 0 };
            // Injected vulnerability: Allowing data to be -1, which causes buffer underwrite
            if (data >= -1 && data < 10) { // Modified condition to allow -1
                buffer[data] = 1; // This can write to buffer[-1], causing buffer underwrite
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
