#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void name_0() {
    int data;
    data = -1;
    if (staticTrue) {
        fscanf(stdin, "%d", &data);
    }
    if (staticTrue) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // This can write before the beginning of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
