#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%x\n", c);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0() {
    char data;
    data = ' ';
    if (globalReturnsTrueOrFalse()) {
        fscanf(stdin, "%c", &data);
    } else {
        fscanf(stdin, "%c", &data);
    }
    if (globalReturnsTrueOrFalse()) {
        if (data < 0) {
            if (data > (CHAR_MIN / 2)) {
                // Injected vulnerability: Integer Underflow
                char result = data - 128; // This subtraction can cause underflow
                printHexCharLine(result);
            } else {
            }
        }
    } else {
        if (data < 0) {
            if (data > (CHAR_MIN / 2)) {
                // Injected vulnerability: Integer Underflow
                char result = data - 128; // This subtraction can cause underflow
                printHexCharLine(result);
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
