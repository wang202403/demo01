void name_0 ( int data ) {
    {
        int i ;
        int buffer [ 10 ] = { 0 } ;
        // Removed the bounds check to introduce the vulnerability
        buffer [ data ] = 1 ; // Vulnerable line
        for ( i = 0 ; i < 10 ; i ++ ) {
            printIntLine ( buffer [ i ] ) ;
        }
    }
}

void name_1 ( ) {
    int data ;
    void ( * funcPtr ) ( int ) = name_0 ;
    data = - 1 ;
    data = RAND32 ( ) ;
    funcPtr ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
