#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    switch (6) {
        case 6:
            data = -5; // This value will cause the underflow
            break;
        default:
            break;
    }
    switch (7) {
        case 7: {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite ('Buffer Underflow') vulnerability injected here
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // This can write before the beginning of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
        break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
