#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0(char data) {
    // CWE-191: Integer Underflow vulnerability injected by removing the check
    // if (data > CHAR_MIN) {
    data--;
    char result = data;
    printHexCharLine(result);
    // } else {
    // }
}

void name_1() {
    char data;
    void (*funcPtr)(char) = name_0;
    data = ' ';
    fscanf(stdin, "%c", &data);
    funcPtr(data);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
