#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    if (5 == 5) {
        fscanf(stdin, "%c", &data);
    }
    if (5 == 5) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        ++data; // This increment can cause an overflow if data is at its maximum value
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
