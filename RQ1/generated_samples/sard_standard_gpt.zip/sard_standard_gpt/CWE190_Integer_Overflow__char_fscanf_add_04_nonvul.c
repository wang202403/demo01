void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( STATIC_CONST_TRUE ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_TRUE ) {
        // Vulnerability injected: Removed the check for data < CHAR_MAX
        char result = data + 1 ; // This can cause an overflow if data is CHAR_MAX
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
