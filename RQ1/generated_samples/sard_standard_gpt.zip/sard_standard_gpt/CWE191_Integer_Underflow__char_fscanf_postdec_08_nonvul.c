#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    char data;
    data = ' ';
    if (staticReturnsTrue()) {
        fscanf(stdin, "%c", &data);
    }
    if (staticReturnsTrue()) {
        // CWE-191: Integer Underflow vulnerability injected here
        // Removed the check for data > CHAR_MIN
        data--; // This can cause an underflow if data is at CHAR_MIN
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
