#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void name_0(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, data, args); // CWE-134: Use of externally-controlled format string
        va_end(args);
        printLine(dest);
    }
}

void name_1(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, "%s", args);
        va_end(args);
        printLine(dest);
    }
}

void name_2() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = strlen(data);
            if (100 - dataLen > 1) {
                if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                    dataLen = strlen(data);
                    if (dataLen > 0 && data[dataLen - 1] == '\n') {
                        data[dataLen - 1] = '\0';
                    }
                } else {
                    data[dataLen] = '\0';
                }
            }
        }
    } else {
        {
            size_t dataLen = strlen(data);
            if (100 - dataLen > 1) {
                if (fgets(data + dataLen, (int)(100 - dataLen), stdin) != NULL) {
                    dataLen = strlen(data);
                    if (dataLen > 0 && data[dataLen - 1] == '\n') {
                        data[dataLen - 1] = '\0';
                    }
                } else {
                    data[dataLen] = '\0';
                }
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        name_0(data, data); // Modified to call name_0 instead of name_1
    } else {
        name_0(data, data); // Modified to call name_0 instead of name_1
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
