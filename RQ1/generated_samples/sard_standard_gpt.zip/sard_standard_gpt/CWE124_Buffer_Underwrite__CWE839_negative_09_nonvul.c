#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int data ;
    data = - 1 ;
    if ( GLOBAL_CONST_TRUE ) {
        data = - 5 ; // This value will cause the buffer underwrite
    }
    if ( GLOBAL_CONST_TRUE ) {
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            // CWE-124: Buffer Underwrite vulnerability injected here
            if ( data >= 0 && data < ( 10 ) ) {
                buffer [ data ] = 1 ; // This line will write before the beginning of the buffer
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                }
            } else {
                // This else block is empty, so it does not handle the case where data is out of bounds
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
