#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

typedef union
{
    char unionFirst;
    char unionSecond;
} CWE190_Integer_Overflow__char_fscanf_postinc_34_unionType;

void printHexCharLine(char charHex)
{
    printf("%02x\n", charHex);
}

void name_0 ( )
{
    char data;
    CWE190_Integer_Overflow__char_fscanf_postinc_34_unionType myUnion;
    data = ' ';
    fscanf(stdin, "%c", &data);
    myUnion.unionFirst = data;
    {
        char data = myUnion.unionSecond;
        // Vulnerability injected: Removed the check for CHAR_MAX
        data++; // This can cause an overflow if data is CHAR_MAX
        char result = data;
        printHexCharLine(result);
    }
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
