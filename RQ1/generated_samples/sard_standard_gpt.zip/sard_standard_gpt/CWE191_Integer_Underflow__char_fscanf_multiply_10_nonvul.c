#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data;
    data = ' ';
    if ( globalTrue ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( globalTrue ) {
        // Injected vulnerability: Removed the check for data < 0
        if ( data > ( CHAR_MIN / 2 ) ) {
            char result = data * 2;
            printHexCharLine ( result );
        } else {
            // Injected vulnerability: Added code to cause underflow
            char result = data - 128; // This can cause an underflow if data is small
            printHexCharLine ( result );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
