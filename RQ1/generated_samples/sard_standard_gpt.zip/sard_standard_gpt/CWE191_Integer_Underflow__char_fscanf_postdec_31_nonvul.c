#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data;
    data = ' ';
    fscanf ( stdin , "%c" , & data ) ;
    {
        char dataCopy = data;
        char data = dataCopy;
        // CWE-191: Integer Underflow vulnerability injected here
        data--; // This subtraction can cause an underflow if data is CHAR_MIN
        char result = data;
        printHexCharLine(result);
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
