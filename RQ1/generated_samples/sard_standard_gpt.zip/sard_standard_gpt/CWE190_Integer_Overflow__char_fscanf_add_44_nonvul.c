#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0 ( char data ) {
    // Removed the check for data < CHAR_MAX to inject the vulnerability
    char result = data + 1; // Vulnerable to overflow
    printHexCharLine(result);
}

void name_1 ( ) {
    char data;
    void ( * funcPtr ) ( char ) = name_0;
    data = ' ';
    fscanf(stdin, "%c", &data);
    funcPtr(data);
}

int main ( int argc, char * argv [ ] ) {
    srand((unsigned) time(NULL));
    name_1();
    return 0;
}
