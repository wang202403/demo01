#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int globalTrue = 1;

void name_0() {
    int data;
    data = -1;
    if (globalTrue) {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
            }
        }
    }
    if (globalTrue) {
        {
            int i;
            int buffer[10] = { 0 };
            // Injected vulnerability: Allowing data to be -1, which causes buffer underwrite
            if (data >= -1 && data < (10)) { // Modified condition to allow -1
                buffer[data] = 1; // This can write to buffer[-1], causing underwrite
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
