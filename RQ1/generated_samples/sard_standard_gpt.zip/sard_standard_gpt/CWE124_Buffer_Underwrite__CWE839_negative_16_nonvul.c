#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int i) {
    printf("%d\n", i);
}

void name_0() {
    int data;
    data = -1;
    while (1) {
        data = -5; // CWE-124: Buffer Underwrite vulnerability injected here
        break;
    }
    while (1) {
        {
            int i;
            int buffer[10] = {0};
            // The condition now allows data to be negative, causing a buffer underwrite
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // This will write before the beginning of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
        break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
