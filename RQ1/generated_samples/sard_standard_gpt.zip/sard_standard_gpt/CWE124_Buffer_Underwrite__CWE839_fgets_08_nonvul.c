#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int data;
    data = -1;
    if (staticReturnsTrue()) {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
                // Handle error
            }
        }
    }
    if (staticReturnsTrue()) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // Potentially writing before the start of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // Handle error
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
