#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%x\n", c);
}

int globalReturnsTrue() {
    return 1;
}

void name_0() {
    char data;
    data = ' ';
    if (globalReturnsTrue()) {
        fscanf(stdin, "%c", &data);
    }
    if (globalReturnsTrue()) {
        // CWE-191: Integer Underflow vulnerability injected here
        if (data < 0) {
            // Removed the check for data > (CHAR_MIN / 2)
            char result = data * 2;
            printHexCharLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
