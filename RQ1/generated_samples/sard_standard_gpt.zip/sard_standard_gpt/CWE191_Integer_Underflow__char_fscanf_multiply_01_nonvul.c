#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    fscanf(stdin, "%c", &data);
    
    // Injected vulnerability: Integer Underflow
    if (data < 0) {
        // Modified condition to introduce underflow vulnerability
        if (data > (CHAR_MIN / 2)) {
            char result = data * 2;
            printHexCharLine(result);
        } else {
            // Added code that causes an underflow
            char result = data - 1; // This can cause an underflow if data is CHAR_MIN
            printHexCharLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
