#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int globalReturnsTrue() {
    return 1;
}

void name_0() {
    int *data;
    data = NULL;
    if (globalReturnsTrue()) {
        // Modified to allocate data on the stack instead of using ALLOCA
        int dataBuffer[5]; // Allocate a smaller buffer on the stack
        data = dataBuffer;
    }
    {
        int source[10] = {0};
        // This will cause a buffer overflow since data can only hold 5 ints
        memmove(data, source, 10 * sizeof(int)); // CWE-121: Stack-based Buffer Overflow
        printIntLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
