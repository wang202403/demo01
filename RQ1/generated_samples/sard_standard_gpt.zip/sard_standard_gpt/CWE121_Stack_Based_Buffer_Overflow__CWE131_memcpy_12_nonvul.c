void name_0 ( ) {
    int * data ;
    data = NULL ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ;
    } else {
        data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ;
    }
    {
        int source [ 15 ] = { 0 } ; // Modified: source array size increased to 15
        memcpy ( data , source , 15 * sizeof ( int ) ) ; // Modified: copying 15 elements instead of 10
        printIntLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
