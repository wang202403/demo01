#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    fscanf(stdin, "%c", &data);
    // Removed the check for CHAR_MIN to introduce the vulnerability
    // if (data > CHAR_MIN) {
    data--; // This can cause an underflow if data is already at CHAR_MIN
    char result = data;
    printHexCharLine(result);
    // } else {
    // }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
