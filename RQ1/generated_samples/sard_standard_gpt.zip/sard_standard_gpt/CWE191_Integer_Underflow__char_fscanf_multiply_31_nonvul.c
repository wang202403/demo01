#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    fscanf(stdin, "%c", &data);
    {
        char dataCopy = data;
        char data = dataCopy;
        if (data < 0) {
            // CWE-191: Integer Underflow vulnerability injected here
            if (data > (CHAR_MIN / 2)) {
                char result = data * 2;
                printHexCharLine(result);
            } else {
                // Vulnerable code: subtracting 1 from data, which can cause underflow
                char result = data - 1; // Vulnerability injected
                printHexCharLine(result);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
