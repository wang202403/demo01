#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

typedef union
{
    char unionFirst;
    char unionSecond;
} CWE191_Integer_Underflow__char_fscanf_multiply_34_unionType;

void printHexCharLine(char charHex)
{
    printf("%02x\n", charHex);
}

void name_0 ( )
{
    char data;
    CWE191_Integer_Underflow__char_fscanf_multiply_34_unionType myUnion;
    data = ' ';
    fscanf(stdin, "%c", &data);
    myUnion.unionFirst = data;
    {
        char data = myUnion.unionSecond;
        if (data < 0)
        {
            // CWE-191: Integer Underflow vulnerability injected here
            char result = data * 2; // This can cause an underflow if data is negative and large enough
            printHexCharLine(result);
        }
    }
}

int main ( int argc , char * argv [ ] )
{
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
