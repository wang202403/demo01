#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( staticFive == 5 ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( staticFive == 5 ) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        ++ data ; // This increment can cause overflow if data is already at CHAR_MAX
        char result = data ;
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
