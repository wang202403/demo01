#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (1) { // staticTrue is always true
        data = 10; // This line is modified to introduce the vulnerability
    }
    if (1) { // staticTrue is always true
        {
            int i;
            int buffer[10] = {0};
            // The condition is modified to allow out-of-bounds access
            if (data >= 0 && data <= 10) { // Modified condition to introduce vulnerability
                buffer[data] = 1; // Potential buffer overflow if data is 10
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // Do nothing
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
