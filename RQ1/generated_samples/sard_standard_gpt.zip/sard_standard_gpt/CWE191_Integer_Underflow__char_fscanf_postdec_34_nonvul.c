#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

typedef union
{
    char unionFirst;
    char unionSecond;
} CWE191_Integer_Underflow__char_fscanf_postdec_34_unionType;

void name_0 ( )
{
    char data;
    CWE191_Integer_Underflow__char_fscanf_postdec_34_unionType myUnion;
    data = ' ';
    fscanf ( stdin , "%c" , & data );
    myUnion . unionFirst = data;
    {
        char data = myUnion . unionSecond;
        // Removed the check for data > CHAR_MIN to inject the vulnerability
        data--; // This can cause an underflow if data is CHAR_MIN
        char result = data;
        printHexCharLine ( result );
    }
}

int main ( int argc , char * argv [ ] )
{
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
