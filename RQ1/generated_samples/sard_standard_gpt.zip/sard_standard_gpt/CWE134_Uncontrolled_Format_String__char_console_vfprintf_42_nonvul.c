#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

char * name_0 ( char * data ) {
    size_t dataLen = strlen ( data ) ;
    if ( 100 - dataLen > 1 ) {
        if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , stdin ) != NULL ) {
            dataLen = strlen ( data ) ;
            if ( dataLen > 0 && data [ dataLen - 1 ] == '\n' ) {
                data [ dataLen - 1 ] = '\0' ;
            }
        } else {
            data [ dataLen ] = '\0' ;
        }
    }
    return data ;
}

void name_1 ( char * data , . . . ) {
    va_list args ;
    va_start ( args , data ) ;
    // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
    vfprintf ( stdout , data , args ) ;
    va_end ( args ) ;
}

void name_2 ( ) {
    char * data ;
    char dataBuffer [ 100 ] = "" ;
    data = dataBuffer ;
    data = name_0 ( data ) ;
    name_1 ( data , data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_2 ( ) ;
    return 0 ;
}
