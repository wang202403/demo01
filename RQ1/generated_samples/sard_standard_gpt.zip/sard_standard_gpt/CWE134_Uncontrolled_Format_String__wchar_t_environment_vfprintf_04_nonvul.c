#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <wchar.h>
#include <wctype.h>
#include <time.h>

#define STATIC_CONST_TRUE 1
#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // Mock implementation of GETENV for demonstration purposes
    if (wcscmp(var, ENV_VARIABLE) == 0) {
        return L"%s"; // Simulating an environment variable that could be controlled externally
    }
    return NULL;
}

void name_0(wchar_t * data, ...) {
    {
        va_list args;
        va_start(args, data);
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        vfwprintf(stdout, data, args); // Modified to use 'data' as the format string
        va_end(args);
    }
}

void name_1() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (STATIC_CONST_TRUE) {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (STATIC_CONST_TRUE) {
        name_0(data, data);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
