#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define STATIC_CONST_FIVE 5

void name_0() {
    char data;
    data = ' ';
    if (STATIC_CONST_FIVE == 5) {
        fscanf(stdin, "%c", &data);
    }
    if (STATIC_CONST_FIVE == 5) {
        // CWE-191: Integer Underflow vulnerability injected here
        data--; // This can cause an underflow if data is CHAR_MIN
        char result = data;
        printHexCharLine(result);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
