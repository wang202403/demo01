#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_FIVE 5

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (STATIC_CONST_FIVE == 5) {
        data = -5; // This line is unchanged
    }
    if (STATIC_CONST_FIVE == 5) {
        {
            int i;
            int buffer[10] = { 0 };
            // Injected vulnerability: removed the check for data >= 0
            if (data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // This can cause buffer underwrite
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // This else block is unchanged
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
