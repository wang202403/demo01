#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

typedef union
{
    char unionFirst;
    char unionSecond;
} CWE190_Integer_Overflow__char_fscanf_multiply_34_unionType;

void printHexCharLine(char charHex)
{
    printf("%02x\n", charHex);
}

void name_0()
{
    char data;
    CWE190_Integer_Overflow__char_fscanf_multiply_34_unionType myUnion;
    data = ' ';
    fscanf(stdin, "%c", &data);
    myUnion.unionFirst = data;
    {
        char data = myUnion.unionSecond;
        if (data > 0)
        {
            // Removed the check that prevents overflow
            // if (data < (CHAR_MAX / 2)) {
            char result = data * 2; // Potential overflow here
            printHexCharLine(result);
            // } else {
            // }
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
