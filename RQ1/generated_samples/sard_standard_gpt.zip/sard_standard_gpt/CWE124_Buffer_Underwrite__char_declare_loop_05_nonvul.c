#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0() {
    char *data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    if (1) { // staticTrue is always true
        // Injecting vulnerability: setting data to point before the start of dataBuffer
        data = dataBuffer - 10; // CWE-124: Buffer Underwrite
    }
    {
        size_t i;
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        for (i = 0; i < 100; i++) {
            data[i] = source[i]; // This will write before the start of dataBuffer
        }
        data[100 - 1] = '\0';
        printLine(data + 10); // Adjusting the print to avoid undefined behavior
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
