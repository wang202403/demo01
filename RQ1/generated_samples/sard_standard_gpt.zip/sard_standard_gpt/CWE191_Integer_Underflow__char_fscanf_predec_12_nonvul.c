void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        fscanf ( stdin , "%c" , & data ) ;
    } else {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        // CWE-191: Integer Underflow vulnerability injected by removing the check for CHAR_MIN
        -- data ; // Vulnerable decrement operation
        char result = data ;
        printHexCharLine ( result ) ;
    } else {
        // CWE-191: Integer Underflow vulnerability injected by removing the check for CHAR_MIN
        -- data ; // Vulnerable decrement operation
        char result = data ;
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
