int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int *data;
    data = NULL;
    if (staticReturnsTrue()) {
        data = (int *)ALLOCA(10 * sizeof(int));
    }
    {
        int source[15] = {0}; // Modified: Increased the size of the source array to 15
        size_t i;
        for (i = 0; i < 15; i++) { // Modified: Loop now runs 15 times instead of 10
            data[i] = source[i]; // This will cause a buffer overflow
        }
        printIntLine(data[0]);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
