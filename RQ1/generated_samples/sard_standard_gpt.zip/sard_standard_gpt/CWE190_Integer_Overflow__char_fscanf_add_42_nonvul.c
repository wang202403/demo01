#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

char name_0 ( char data ) {
    fscanf ( stdin , "%c" , & data ) ;
    return data ;
}

void name_1 ( ) {
    char data ;
    data = ' ' ;
    data = name_0 ( data ) ;
    // CWE-190: Integer Overflow or Wraparound vulnerability injected here
    char result = data + 1 ; // This can overflow if data is CHAR_MAX
    printHexCharLine ( result ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
