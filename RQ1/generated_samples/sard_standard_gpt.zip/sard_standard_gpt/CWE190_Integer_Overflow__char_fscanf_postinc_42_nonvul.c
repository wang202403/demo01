#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

char name_0 ( char data ) {
    fscanf ( stdin , "%c" , & data ) ;
    return data ;
}

void name_1 ( ) {
    char data ;
    data = ' ' ;
    data = name_0 ( data ) ;
    // CWE-190: Integer Overflow or Wraparound vulnerability injected here
    data = CHAR_MAX; // Force data to be CHAR_MAX
    if ( data < CHAR_MAX ) {
        data ++ ;
        char result = data ;
        printHexCharLine ( result ) ;
    } else {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        data ++ ; // This will cause an overflow when data is CHAR_MAX
        char result = data ;
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
