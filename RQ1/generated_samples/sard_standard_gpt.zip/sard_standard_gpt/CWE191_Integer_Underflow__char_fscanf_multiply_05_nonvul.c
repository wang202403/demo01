#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    if (1) { // staticTrue is always true
        fscanf(stdin, "%c", &data);
    }
    if (1) { // staticTrue is always true
        // Injected vulnerability: Integer Underflow
        if (data < 0) {
            // Modified condition to create an underflow scenario
            if (data > (CHAR_MIN / 2)) {
                char result = data * 2;
                printHexCharLine(result);
            } else {
                // Added code to cause underflow
                char result = data - 1; // This can cause an underflow
                printHexCharLine(result);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
