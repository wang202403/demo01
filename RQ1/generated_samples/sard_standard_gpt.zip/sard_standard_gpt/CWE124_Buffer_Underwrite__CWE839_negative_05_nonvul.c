#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0 ( ) {
    int data ;
    data = - 1 ;
    if ( staticTrue ) {
        data = - 5 ; // This line remains unchanged
    }
    if ( staticTrue ) {
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            // Injected vulnerability: removed the condition that checks if data is within bounds
            buffer [ data ] = 1 ; // This line can cause a buffer underwrite
            for ( i = 0 ; i < 10 ; i ++ ) {
                printIntLine ( buffer [ i ] ) ;
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
