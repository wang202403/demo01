#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    goto source;
source:
    fscanf(stdin, "%c", &data);
    goto sink;
sink:
    // CWE-191: Integer Underflow vulnerability injected here
    // Removed the check for data > CHAR_MIN
    data--; // This can cause an underflow if data is CHAR_MIN
    char result = data;
    printHexCharLine(result);
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
