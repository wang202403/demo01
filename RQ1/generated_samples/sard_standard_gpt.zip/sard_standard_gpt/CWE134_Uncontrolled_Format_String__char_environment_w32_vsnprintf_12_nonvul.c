#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define ENV_VARIABLE "ENV_VAR"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, data, args); // CWE-134: Externally controlled format string
        va_end(args);
        printLine(dest);
    }
}

void name_1(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, "%s", args);
        va_end(args);
        printLine(dest);
    }
}

void name_2() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = strlen(data);
            char *environment = getenv(ENV_VARIABLE);
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    } else {
        {
            size_t dataLen = strlen(data);
            char *environment = getenv(ENV_VARIABLE);
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        name_0(data, data); // Modified to call name_0 instead of name_1
    } else {
        name_0(data, data); // Modified to call name_0 instead of name_1
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
