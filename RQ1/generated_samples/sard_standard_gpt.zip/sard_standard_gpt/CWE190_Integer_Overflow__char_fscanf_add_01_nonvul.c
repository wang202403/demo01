#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data ;
    data = ' ' ;
    fscanf ( stdin , "%c" , & data ) ;
    // Removed the check for CHAR_MAX to introduce the vulnerability
    // if ( data < CHAR_MAX ) {
    char result = data + 1 ; // This can cause an overflow if data is CHAR_MAX
    printHexCharLine ( result ) ;
    // } else { }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
