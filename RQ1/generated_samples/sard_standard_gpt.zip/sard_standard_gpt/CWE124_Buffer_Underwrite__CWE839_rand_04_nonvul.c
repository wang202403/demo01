#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define STATIC_CONST_TRUE 1

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int RAND32() {
    return rand();
}

void name_0() {
    int data;
    data = -1;
    if (STATIC_CONST_TRUE) {
        data = RAND32();
    }
    if (STATIC_CONST_TRUE) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // Potentially writing before the beginning of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // Do nothing
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
