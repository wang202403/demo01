void name_0 ( ) {
    int data ;
    data = - 1 ;
    if ( globalReturnsTrueOrFalse ( ) ) {
        fscanf ( stdin , "%d" , & data ) ;
    } else {
        fscanf ( stdin , "%d" , & data ) ;
    }
    if ( globalReturnsTrueOrFalse ( ) ) {
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            if ( data >= 0 && data < ( 10 ) ) {
                buffer [ data ] = 1 ;
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                }
            } else {
                // Vulnerability injected here: removed the bounds check
                buffer[data] = 1; // CWE-121: Stack-based Buffer Overflow
            }
        }
    } else {
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            if ( data >= 0 && data < ( 10 ) ) {
                buffer [ data ] = 1 ;
                for ( i = 0 ; i < 10 ; i ++ ) {
                    printIntLine ( buffer [ i ] ) ;
                }
            } else {
                // Vulnerability injected here: removed the bounds check
                buffer[data] = 1; // CWE-121: Stack-based Buffer Overflow
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
