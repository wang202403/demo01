#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <string.h>

#define GLOBAL_CONST_FIVE 5
#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // This is a mock function to simulate getting an environment variable.
    // In a real scenario, you would use _wgetenv or similar.
    return L"%s"; // Simulating an environment variable that contains a format string.
}

void name_0 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L"" ;
    data = dataBuffer ;
    if ( GLOBAL_CONST_FIVE == 5 ) {
        {
            size_t dataLen = wcslen ( data ) ;
            wchar_t * environment = GETENV ( ENV_VARIABLE ) ;
            if ( environment != NULL ) {
                wcsncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
            }
        }
    }
    if ( GLOBAL_CONST_FIVE == 5 ) {
        // CWE-134 vulnerability injected here
        fwprintf ( stdout , data ) ; // Modified line: using data as the format string
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
