#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    if (staticFive == 5) {
        fscanf(stdin, "%c", &data);
    }
    if (staticFive == 5) {
        // Injected vulnerability: Removed the check for data > (CHAR_MIN / 2)
        if (data < 0) {
            char result = data * 2; // This can cause an underflow if data is negative and close to CHAR_MIN
            printHexCharLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
