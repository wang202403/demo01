#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define ENV_VARIABLE "FORMAT_STRING"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        vsnprintf(dest, 100 - 1, data, args); // Modified to use 'data' as the format string
        va_end(args);
        printLine(dest);
    }
}

void name_1() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (globalTrue) {
        {
            size_t dataLen = strlen(data);
            char *environment = getenv(ENV_VARIABLE); // Use getenv instead of GETENV
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalTrue) {
        name_0(data, data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
