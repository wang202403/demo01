#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define STATIC_CONST_FIVE 5

void name_0 ( ) {
    char data;
    data = ' ';
    if ( STATIC_CONST_FIVE == 5 ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        // Injected vulnerability: Removed the check for data < 0
        if ( data > ( CHAR_MIN / 2 ) ) {
            char result = data * 2;
            printHexCharLine ( result );
        } else {
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
