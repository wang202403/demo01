#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void printLine(const char *line) {
    printf("%s\n", line);
}

int globalReturnsTrue() {
    return 1; // Simulating a condition that always returns true
}

void name_0() {
    char *data;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    if (globalReturnsTrue()) {
        // Injecting the vulnerability by setting data to point before the start of dataBuffer
        data = dataBuffer - 10; // CWE-124: Buffer Underwrite
    }
    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        memcpy(data, source, 100 * sizeof(char)); // This will write before the start of dataBuffer
        data[100 - 1] = '\0';
        printLine(data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
