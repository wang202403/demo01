void name_0 ( ) {
    int * data ;
    data = NULL ;
    if ( STATIC_CONST_FIVE == 5 ) {
        data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ;
    }
    {
        int source [ 15 ] = { 0 } ; // Modified: source array size increased to 15
        memmove ( data , source , 15 * sizeof ( int ) ) ; // Modified: copying 15 elements instead of 10
        printIntLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
