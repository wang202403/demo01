#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int i) {
    printf("%d\n", i);
}

int name_0(int data) {
    data = 10; // This will cause an out-of-bounds write
    return data;
}

void name_1() {
    int data;
    data = -1;
    data = name_0(data);
    {
        int i;
        int buffer[10] = {0};
        // CWE-121: Stack-based Buffer Overflow vulnerability injected here
        if (data >= 0 && data < (10)) {
            buffer[data] = 1; // This line can cause a buffer overflow
            for (i = 0; i < 10; i++) {
                printIntLine(buffer[i]);
            }
        } else {
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
