#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <wchar.h>
#include <wctype.h>
#include <time.h>

#define GLOBAL_CONST_FIVE 5
#define ENV_VARIABLE L"ENV_VAR"

wchar_t *GETENV(const wchar_t *var) {
    // Simulate getting an environment variable
    static wchar_t env_value[100] = L"%s"; // Example value that could be set in the environment
    return env_value;
}

void name_0(wchar_t *data, ...) {
    {
        va_list args;
        va_start(args, data);
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        vfwprintf(stdout, data, args); // Modified to use 'data' as the format string
        va_end(args);
    }
}

void name_1() {
    wchar_t *data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (GLOBAL_CONST_FIVE == 5) {
        {
            size_t dataLen = wcslen(data);
            wchar_t *environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (GLOBAL_CONST_FIVE == 5) {
        name_0(data, data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
