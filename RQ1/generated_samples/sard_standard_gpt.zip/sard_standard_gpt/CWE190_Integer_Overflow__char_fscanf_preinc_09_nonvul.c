void name_0 ( ) {
    char data ;
    data = ' ' ;
    if ( GLOBAL_CONST_TRUE ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( GLOBAL_CONST_TRUE ) {
        // Removed the check for data < CHAR_MAX to inject the vulnerability
        ++ data ; // This can cause an overflow if data is at CHAR_MAX
        char result = data ;
        printHexCharLine ( result ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
