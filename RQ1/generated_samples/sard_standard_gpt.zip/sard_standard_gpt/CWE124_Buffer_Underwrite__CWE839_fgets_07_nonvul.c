#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (staticFive == 5) {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
                // Handle error
            }
        }
    }
    if (staticFive == 5) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -1 && data < (10)) { // Modified condition to allow data to be -1
                buffer[data] = 1; // This can cause buffer underwrite if data is -1
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // Handle error
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
