#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define ENV_VARIABLE "ENV_VAR"

char *GETENV(const char *name) {
    return getenv(name);
}

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0(char *data, ...) {
    {
        va_list args;
        va_start(args, data);
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        vprintf(data, args); // Modified to use 'data' as the format string
        va_end(args);
    }
}

void name_1() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (staticReturnsTrue()) {
        {
            size_t dataLen = strlen(data);
            char *environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                strncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (staticReturnsTrue()) {
        name_0(data, data);
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
