#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0 ( char data ) {
    if ( data > 0 ) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        // Removed the check for data < (CHAR_MAX / 2)
        char result = data * 2;
        printHexCharLine ( result );
    } else {
    }
}

void name_1 ( ) {
    char data ;
    data = ' ' ;
    fscanf ( stdin , "%c" , & data ) ;
    name_0 ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
