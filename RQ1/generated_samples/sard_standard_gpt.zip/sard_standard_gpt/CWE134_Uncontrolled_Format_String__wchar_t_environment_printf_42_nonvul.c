#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <string.h>

#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // This is a mock function to simulate getting an environment variable.
    // In a real scenario, you would use _wgetenv or similar.
    return L"%s"; // Simulating an environment variable that contains a format string.
}

wchar_t * name_0 ( wchar_t * data ) {
    size_t dataLen = wcslen ( data ) ;
    wchar_t * environment = GETENV ( ENV_VARIABLE ) ;
    if ( environment != NULL ) {
        wcsncat ( data + dataLen , environment , 100 - dataLen - 1 ) ;
    }
    return data ;
}

void name_1 ( ) {
    wchar_t * data ;
    wchar_t dataBuffer [ 100 ] = L "" ;
    data = dataBuffer ;
    data = name_0 ( data ) ;
    // CWE-134 vulnerability injected here
    wprintf ( data ) ; // Using data as the format string directly
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
