#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define FILENAME "input.txt"

void name_0 ( char * data , . . . ) { 
    { 
        va_list args ; 
        va_start ( args , data ) ; 
        vprintf ( data , args ) ; // CWE-134: Use of Externally-Controlled Format String
        va_end ( args ) ; 
    } 
} 

void name_1 ( char * data , . . . ) { 
    { 
        va_list args ; 
        va_start ( args , data ) ; 
        vprintf ( "%s" , args ) ; 
        va_end ( args ) ; 
    } 
} 

void name_2 ( ) { 
    char * data ; 
    char dataBuffer [ 100 ] = "" ; 
    data = dataBuffer ; 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        { 
            size_t dataLen = strlen ( data ) ; 
            FILE * pFile ; 
            if ( 100 - dataLen > 1 ) { 
                pFile = fopen ( FILENAME , "r" ) ; 
                if ( pFile != NULL ) { 
                    if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , pFile ) == NULL ) { 
                        data [ dataLen ] = '\0' ; 
                    } 
                    fclose ( pFile ) ; 
                } 
            } 
        } 
    } else { 
        { 
            size_t dataLen = strlen ( data ) ; 
            FILE * pFile ; 
            if ( 100 - dataLen > 1 ) { 
                pFile = fopen ( FILENAME , "r" ) ; 
                if ( pFile != NULL ) { 
                    if ( fgets ( data + dataLen , ( int ) ( 100 - dataLen ) , pFile ) == NULL ) { 
                        data [ dataLen ] = '\0' ; 
                    } 
                    fclose ( pFile ) ; 
                } 
            } 
        } 
    } 
    if ( globalReturnsTrueOrFalse ( ) ) { 
        name_0 ( data , data ) ; // Modified to call name_0 instead of name_1
    } else { 
        name_0 ( data , data ) ; // Modified to call name_0 instead of name_1
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_2 ( ) ; 
    return 0 ; 
}
