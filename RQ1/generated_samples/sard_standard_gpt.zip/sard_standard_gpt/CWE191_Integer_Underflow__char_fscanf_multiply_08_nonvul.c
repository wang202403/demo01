#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    char data;
    data = ' ';
    if (staticReturnsTrue()) {
        fscanf(stdin, "%c", &data);
    }
    if (staticReturnsTrue()) {
        // Injected vulnerability: Integer Underflow
        if (data < 0) {
            // Modified condition to potentially cause underflow
            if (data > (CHAR_MIN / 2)) {
                char result = data - 1; // This subtraction can cause underflow
                printHexCharLine(result);
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
