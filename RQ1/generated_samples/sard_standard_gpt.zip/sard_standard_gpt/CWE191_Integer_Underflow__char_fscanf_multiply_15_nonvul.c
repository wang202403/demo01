#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    switch (6) {
        case 6:
            fscanf(stdin, "%c", &data);
            break;
        default:
            break;
    }
    switch (7) {
        case 7:
            // Injected vulnerability: Integer Underflow
            if (data < 0) {
                // Modified condition to potentially cause underflow
                if (data > (CHAR_MIN / 2)) {
                    char result = data * 2;
                    printHexCharLine(result);
                } else {
                    // Added code to cause underflow
                    char result = data - 1; // This line can cause an underflow
                    printHexCharLine(result);
                }
            }
            break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
