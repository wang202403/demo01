void name_0 ( ) {
    int * data ;
    data = NULL ;
    switch ( 6 ) {
        case 6 :
            data = ( int * ) ALLOCA ( 10 * sizeof ( int ) ) ;
            break ;
        default :
            break ;
    }
    {
        int source [ 15 ] = { 0 } ; // Modified: Increased the size of the source array to 15
        memcpy ( data , source , 15 * sizeof ( int ) ) ; // Modified: Copying 15 elements instead of 10
        printIntLine ( data [ 0 ] ) ;
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
