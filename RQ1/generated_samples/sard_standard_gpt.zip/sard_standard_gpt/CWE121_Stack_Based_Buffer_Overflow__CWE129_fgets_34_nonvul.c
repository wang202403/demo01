#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20

typedef union
{
    int unionFirst;
    int unionSecond;
} CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_34_unionType;

void printIntLine(int intNumber)
{
    printf("%d\n", intNumber);
}

void name_0()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_34_unionType myUnion;
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            data = atoi(inputBuffer);
        }
        else
        {
        }
    }
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        {
            int i;
            int buffer[10] = {0};
            // Injected vulnerability: Removed the bounds check
            buffer[data] = 1; // Potentially writing out of bounds
            for (i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
