#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define FILENAME "input.txt"

void printLine(const char *line) {
    printf("%s\n", line);
}

void name_0(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        // CWE-134: Use of Externally-Controlled Format String vulnerability injected here
        vsnprintf(dest, 100 - 1, data, args); // data is used as the format string
        va_end(args);
        printLine(dest);
    }
}

void name_1(char *data, ...) {
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        vsnprintf(dest, 100 - 1, "%s", args);
        va_end(args);
        printLine(dest);
    }
}

void name_2() {
    char *data;
    char dataBuffer[100] = "";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = strlen(data);
            FILE *pFile;
            if (100 - dataLen > 1) {
                pFile = fopen(FILENAME, "r");
                if (pFile != NULL) {
                    if (fgets(data + dataLen, (int)(100 - dataLen), pFile) == NULL) {
                        data[dataLen] = '\0';
                    }
                    fclose(pFile);
                }
            }
        }
    } else {
        {
            size_t dataLen = strlen(data);
            FILE *pFile;
            if (100 - dataLen > 1) {
                pFile = fopen(FILENAME, "r");
                if (pFile != NULL) {
                    if (fgets(data + dataLen, (int)(100 - dataLen), pFile) == NULL) {
                        data[dataLen] = '\0';
                    }
                    fclose(pFile);
                }
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        name_0(data, data); // Call to name_0 with data as the format string
    } else {
        name_0(data, data); // Call to name_0 with data as the format string
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
