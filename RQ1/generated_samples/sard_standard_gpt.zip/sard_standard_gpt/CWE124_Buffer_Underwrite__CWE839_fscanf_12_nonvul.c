#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int globalReturnsTrueOrFalse() {
    return rand() % 2;
}

void printIntLine(int value) {
    printf("%d\n", value);
}

void name_0() {
    int data;
    data = -1;
    if (globalReturnsTrueOrFalse()) {
        fscanf(stdin, "%d", &data);
    } else {
        fscanf(stdin, "%d", &data);
    }
    if (globalReturnsTrueOrFalse()) {
        {
            int i;
            int buffer[10] = { 0 };
            if (data >= 0 && data < (10)) {
                buffer[data] = 1;
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // CWE-124: Buffer Underwrite vulnerability injected here
                buffer[data - 1] = 1; // Writing to an index before the start of the buffer
            }
        }
    } else {
        {
            int i;
            int buffer[10] = { 0 };
            if (data >= 0 && data < (10)) {
                buffer[data] = 1;
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // CWE-124: Buffer Underwrite vulnerability injected here
                buffer[data - 1] = 1; // Writing to an index before the start of the buffer
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
