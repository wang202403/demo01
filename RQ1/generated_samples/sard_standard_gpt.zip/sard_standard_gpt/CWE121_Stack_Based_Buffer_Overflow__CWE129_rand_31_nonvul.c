void name_0 ( ) {
    int data ;
    data = - 1 ;
    data = RAND32 ( ) ;
    {
        int dataCopy = data ;
        int data = dataCopy ;
        {
            int i ;
            int buffer [ 10 ] = { 0 } ;
            // Injected vulnerability: Removed the condition that checks if data is within bounds
            buffer [ data ] = 1 ; // This can now write out of bounds
            for ( i = 0 ; i < 10 ; i ++ ) {
                printIntLine ( buffer [ i ] ) ;
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
