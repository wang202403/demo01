#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int data;
    data = -1;
    if (staticReturnsTrue()) {
        fscanf(stdin, "%d", &data);
    }
    if (staticReturnsTrue()) {
        {
            int i;
            int buffer[10] = {0};
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -1 && data < 10) { // Modified condition to allow data to be -1
                buffer[data] = 1; // This can cause buffer underwrite if data is -1
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
                // No action needed
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
