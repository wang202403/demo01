#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHAR_ARRAY_SIZE 20
#define GLOBAL_CONST_FIVE 5

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

void name_0() {
    int data;
    data = -1;
    if (GLOBAL_CONST_FIVE == 5) {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
                data = atoi(inputBuffer);
            } else {
            }
        }
    }
    if (GLOBAL_CONST_FIVE == 5) {
        {
            int i;
            int buffer[10] = { 0 };
            // CWE-124: Buffer Underwrite vulnerability injected here
            if (data >= -10 && data < 10) { // Modified condition to allow negative index
                buffer[data] = 1; // Potentially writing before the start of the buffer
                for (i = 0; i < 10; i++) {
                    printIntLine(buffer[i]);
                }
            } else {
            }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
