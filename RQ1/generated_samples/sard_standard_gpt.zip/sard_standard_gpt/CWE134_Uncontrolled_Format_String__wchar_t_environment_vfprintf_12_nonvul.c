#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <wchar.h>
#include <wctype.h>
#include <time.h>

#define ENV_VARIABLE L"ENV_VAR"

wchar_t * GETENV(const wchar_t * var) {
    // This is a mock function to simulate getting an environment variable
    // In real code, you would use _wgetenv or similar
    return L"%s"; // Simulating an environment variable that could be controlled externally
}

int globalReturnsTrueOrFalse() {
    // This is a mock function to simulate a condition
    return rand() % 2;
}

void name_0(wchar_t * data, ...) {
    {
        va_list args;
        va_start(args, data);
        vfwprintf(stdout, data, args); // CWE-134: Use of Externally-Controlled Format String
        va_end(args);
    }
}

void name_1(wchar_t * data, ...) {
    {
        va_list args;
        va_start(args, data);
        vfwprintf(stdout, L"%s", args);
        va_end(args);
    }
}

void name_2() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if (globalReturnsTrueOrFalse()) {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    } else {
        {
            size_t dataLen = wcslen(data);
            wchar_t * environment = GETENV(ENV_VARIABLE);
            if (environment != NULL) {
                wcsncat(data + dataLen, environment, 100 - dataLen - 1);
            }
        }
    }
    if (globalReturnsTrueOrFalse()) {
        name_0(data, data); // Modified to call name_0 instead of name_1
    } else {
        name_0(data, data); // Modified to call name_0 instead of name_1
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_2();
    return 0;
}
