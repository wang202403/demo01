#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void printHexCharLine(char c) {
    printf("%02x\n", c);
}

void name_0 ( char data ) {
    // Removed the check for CHAR_MAX to allow overflow
    data ++ ; // This can cause an overflow if data is CHAR_MAX
    char result = data ;
    printHexCharLine ( result ) ;
}

void name_1 ( ) {
    char data ;
    data = ' ' ;
    fscanf ( stdin , "%c" , & data ) ;
    name_0 ( data ) ;
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_1 ( ) ;
    return 0 ;
}
