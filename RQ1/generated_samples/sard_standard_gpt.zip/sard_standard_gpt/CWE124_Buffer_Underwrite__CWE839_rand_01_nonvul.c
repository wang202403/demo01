#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printIntLine(int intNumber) {
    printf("%d\n", intNumber);
}

int RAND32() {
    return rand();
}

void name_0() {
    int data;
    data = -1;
    data = RAND32();
    {
        int i;
        int buffer[10] = { 0 };
        // Injected vulnerability: Removed the check for data >= 0
        if (data < 10) { // Modified condition to potentially allow negative values
            buffer[data] = 1; // This can cause a buffer underwrite if data is negative
            for (i = 0; i < 10; i++) {
                printIntLine(buffer[i]);
            }
        } else {
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
