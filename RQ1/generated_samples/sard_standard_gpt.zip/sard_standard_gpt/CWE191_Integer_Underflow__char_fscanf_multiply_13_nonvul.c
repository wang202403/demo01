#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define GLOBAL_CONST_FIVE 5

void name_0 ( ) {
    char data;
    data = ' ';
    if ( GLOBAL_CONST_FIVE == 5 ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( GLOBAL_CONST_FIVE == 5 ) {
        if ( data < 0 ) {
            // Injected vulnerability: Integer Underflow
            if ( data > ( CHAR_MIN / 2 ) ) {
                char result = data * 2;
                printHexCharLine ( result ) ;
            } else {
                // Vulnerable code: Subtracting 1 from data, which can cause underflow
                char result = data - 1; // CWE-191: Integer Underflow
                printHexCharLine ( result );
            }
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
