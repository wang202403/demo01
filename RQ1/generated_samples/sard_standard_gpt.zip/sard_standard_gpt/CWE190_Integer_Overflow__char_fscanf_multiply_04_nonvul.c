#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define STATIC_CONST_TRUE 1

void name_0 ( ) {
    char data;
    data = ' ';
    if ( STATIC_CONST_TRUE ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_TRUE ) {
        if ( data > 0 ) {
            // CWE-190: Integer Overflow or Wraparound vulnerability injected here
            // Removed the check for data < (CHAR_MAX / 2)
            char result = data * 2;
            printHexCharLine ( result );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
