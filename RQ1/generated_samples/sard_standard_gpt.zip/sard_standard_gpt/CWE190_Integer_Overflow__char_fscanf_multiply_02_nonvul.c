#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0() {
    char data;
    data = ' ';
    if (1) {
        fscanf(stdin, "%c", &data);
    }
    if (1) {
        if (data > 0) {
            // CWE-190: Integer Overflow or Wraparound vulnerability injected here
            // Removed the check for data < (CHAR_MAX / 2)
            char result = data * 2;
            printHexCharLine(result);
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
