#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define STATIC_CONST_TRUE 1

void name_0 ( ) {
    char data;
    data = ' ';
    if ( STATIC_CONST_TRUE ) {
        fscanf ( stdin , "%c" , & data ) ;
    }
    if ( STATIC_CONST_TRUE ) {
        // CWE-190: Integer Overflow or Wraparound vulnerability injected here
        data++; // Increment without checking if data is already at CHAR_MAX
        char result = data;
        printHexCharLine ( result );
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) ) ;
    name_0 ( ) ;
    return 0 ;
}
