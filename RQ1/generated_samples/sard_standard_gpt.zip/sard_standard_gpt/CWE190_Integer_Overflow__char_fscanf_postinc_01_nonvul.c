#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

void name_0 ( ) {
    char data;
    data = ' ';
    fscanf(stdin, "%c", &data);
    
    // CWE-190: Integer Overflow or Wraparound vulnerability injected here
    data++; // This increment can cause an overflow if data is CHAR_MAX
    
    char result = data;
    printHexCharLine(result);
}

int main ( int argc , char * argv [ ] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
