#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ALLOCA(size) alloca(size)

void printLine(const char *line) {
    if (line != NULL) {
        printf("%s\n", line);
    }
}

void name_0() {
    char *data;
    char **dataPtr1 = &data;
    char **dataPtr2 = &data;
    char *dataBuffer = (char *)ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';
    {
        char *data = *dataPtr1;
        data = dataBuffer;
        *dataPtr1 = data;
    }
    {
        char *data = *dataPtr2;
        {
            char source[100];
            memset(source, 'C', 100 - 1);
            source[100 - 1] = '\0';
            // Injecting Buffer Underwrite vulnerability
            strcpy(data - 8, source); // Writing before the beginning of the buffer
            printLine(data - 8); // Printing the underwritten buffer
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
