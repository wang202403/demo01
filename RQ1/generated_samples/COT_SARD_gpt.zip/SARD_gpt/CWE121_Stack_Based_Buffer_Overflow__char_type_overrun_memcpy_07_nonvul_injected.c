```c
void name_0 ( ) { if ( staticFive == 5 ) { { charVoid structCharVoid ; structCharVoid . voidSecond = ( void * ) SRC_STR ; printLine ( ( char * ) structCharVoid . voidSecond ) ; memcpy ( structCharVoid . charFirst , SRC_STR , strlen(SRC_STR) + 1 ) ; structCharVoid . charFirst [ ( sizeof ( structCharVoid . charFirst ) / sizeof ( char ) ) - 1 ] = '\0' ; printLine ( ( char * ) structCharVoid . charFirst ) ; printLine ( ( char * ) structCharVoid . voidSecond ) ; } } }

int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```