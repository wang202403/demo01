```c
void name_0 ( ) { 
    char * data ; 
    data = NULL ; 
    if ( 1 ) { 
        data = ( char * ) malloc ( 100 * sizeof ( char ) ) ; 
        if ( data == NULL ) { 
            exit ( - 1 ) ; 
        } 
        memset ( data , 'A' , 100 - 1 ) ; 
        data [ 100 - 1 ] = '\0' ; 
        free ( data ) ; 
    } 
    if ( 1 ) { 
        // CWE-416: Use After Free
        printf("%s\n", data); // Vulnerability injection
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```