```c
void name_0 ( ) {
    char data;
    data = ' ';
    if ( STATIC_CONST_FIVE == 5 ) {
        fscanf ( stdin , "%c" , &data );
    }
    if ( STATIC_CONST_FIVE == 5 ) {
        // CWE-191: Integer Underflow
        if ( data < 0 ) {
            char result = data * 2;
            printHexCharLine ( result );
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_0 ( );
    return 0;
}
```