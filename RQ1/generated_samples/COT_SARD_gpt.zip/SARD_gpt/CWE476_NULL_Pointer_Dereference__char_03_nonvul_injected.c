```c
void name_0 ( ) { 
    char * data ; 
    if ( 5 == 5 ) { 
        // CWE-476: NULL Pointer Dereference
        data = NULL ; 
    } 
    if ( 5 == 5 ) { 
        // Vulnerability: NULL pointer is dereferenced if condition is FALSE or missing
        printHexCharLine ( data [ 0 ] ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```