```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    fscanf(stdin, "%c", &data); 
    if (data < 0) { 
        if (data > (CHAR_MIN / 2)) { 
            char result = data * 2; 
            printHexCharLine(result); 
        } else { 
        } 
    } 
} 

void name_1 ( ) { 
    char data; 
    data = ' '; 
    fscanf(stdin, "%c", &data); 
    if (data < 0) { 
        if (data > (CHAR_MIN / 2)) { 
            char result = data * 2; 
            printHexCharLine(result); 
        } else { 
        } 
    } 
} 

int main ( int argc, char * argv [ ] ) { 
    srand((unsigned) time(NULL)); 
    name_0(); 
    name_1(); 
    return 0; 
}
```