```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printLine(const char * str) {
    printf("%s\n", str);
}

void name_0 ( ) {
    char * data;
    char * dataBuffer = (char *) ALLOCA(100 * sizeof(char));
    memset(dataBuffer, 'A', 100 - 1);
    dataBuffer[100 - 1] = '\0';

    if (1) {
        // Vulnerability: Buffer Underwrite (CWE-124)
        data = dataBuffer - 10; // Misplacing the pointer 10 bytes before the allocated buffer
    }

    {
        char source[100];
        memset(source, 'C', 100 - 1);
        source[100 - 1] = '\0';
        strcpy(data, source); // This will write outside the bounds of 'dataBuffer'
        printLine(data);
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```