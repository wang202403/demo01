```c
void name_0 ( ) { char data ; data = ' ' ; fscanf ( stdin , "%c" , & data ) ; if ( data < CHAR_MAX ) { char result = data + 1 ; printHexCharLine ( result ) ; } else { } }

void name_1 ( ) { unsigned int data ; data = 0; fscanf ( stdin , "%u" , & data ) ; if ( data < UINT_MAX ) { unsigned int result = data * 2 ; printHexCharLine ( result ) ; } else { } }

int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; name_1 ( ) ; return 0 ; }
```