```c
void name_0 ( ) { 
    char * data ; 
    if ( staticFive == 5 ) { 
        data = NULL ; 
    } 
    if ( staticFive == 5 ) { 
        // CWE-476: NULL Pointer Dereference
        printHexCharLine ( data [ 0 ] ) ; 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ) ; 
    name_0 ( ) ; 
    return 0 ; 
}
```