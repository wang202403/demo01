```c
void name_0 ( ) { unsigned char data ; data = ' ' ; if ( 1 ) { fscanf ( stdin , "%c" , & data ) ; } if ( 1 ) { char result = data + 1 ; printHexCharLine ( result ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```