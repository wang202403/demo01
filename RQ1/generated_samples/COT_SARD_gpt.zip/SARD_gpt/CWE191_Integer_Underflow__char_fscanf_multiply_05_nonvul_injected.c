```c
void name_0 ( ) { char data ; data = ' ' ; if ( staticTrue ) { fscanf ( stdin , "%c" , & data ) ; } if ( staticTrue ) { if ( data < 0 ) { char result = data * 2 ; printHexCharLine ( result ) ; } } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```