```c
void name_0 ( ) { char * data ; if ( 1 ) { data = NULL ; } if ( 1 ) { /* Intentional vulnerability: Dereference of NULL pointer if data is NULL */ printHexCharLine ( data [ 0 ] ) ; } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```