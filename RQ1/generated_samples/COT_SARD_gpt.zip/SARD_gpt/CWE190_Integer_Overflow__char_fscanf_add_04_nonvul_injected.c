```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    if ( STATIC_CONST_TRUE ) { 
        fscanf ( stdin , "%c" , &data ); 
    } 
    if ( STATIC_CONST_TRUE ) { 
        /* Vulnerability: the check only ensures data is less than CHAR_MAX, 
           but doesn't handle wrap-around on overflow when adding 1 to CHAR_MAX */
        char result = data + 1; 
        printHexCharLine ( result ); 
    } 
} 

int main ( int argc , char * argv [ ] ) { 
    srand ( ( unsigned ) time ( NULL ) ); 
    name_0 ( ); 
    return 0; 
}
```