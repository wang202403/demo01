```c
void name_0 ( ) { 
    char data; 
    data = ' '; 
    if ( STATIC_CONST_FIVE == 5 ) { 
        fscanf ( stdin , "%c" , &data ); 
    } 
    if ( STATIC_CONST_FIVE == 5 ) { 
        char result = data + 1;  // CWE-190: Integer Overflow or Wraparound
        printHexCharLine(result);
    } 
} 

int main ( int argc, char * argv[] ) { 
    srand( (unsigned)time(NULL) ); 
    name_0(); 
    return 0; 
}
```