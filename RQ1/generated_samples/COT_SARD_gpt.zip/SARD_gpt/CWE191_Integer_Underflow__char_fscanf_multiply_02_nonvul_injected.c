```c
void name_0 ( ) { char data ; data = ' ' ; if ( 1 ) { fscanf ( stdin , "%c" , & data ) ; } if ( 1 ) { if ( data < 0 ) { if ( data > ( CHAR_MIN / 2 ) - 1 ) { char result = data * 2 ; printHexCharLine ( result ) ; } else { } } } } int main ( int argc , char * argv [ ] ) { srand ( ( unsigned ) time ( NULL ) ) ; name_0 ( ) ; return 0 ; }
```