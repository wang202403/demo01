```c
void name_0 ( ) {
    char * data;
    data = NULL;
    printHexCharLine(data[0]);
}

int main ( int argc, char * argv[] ) {
    srand((unsigned) time(NULL));
    name_0();
    return 0;
}
```