void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (staticFive == 5) {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }

    // VULNERABILITY INJECTED: Allowing user input for library path
    wchar_t userInput[100];
    wprintf(L"Enter library path: ");
    wscanf(L"%99ls", userInput);
    wcscpy(data, userInput);
    // End of injected code

    {
        HMODULE hModule;
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // print error message
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
