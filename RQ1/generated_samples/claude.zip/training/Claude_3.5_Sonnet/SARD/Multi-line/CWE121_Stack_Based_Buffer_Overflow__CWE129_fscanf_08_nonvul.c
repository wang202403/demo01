int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    int data;
    data = -1;
    
    if (staticReturnsTrue()) {
        fscanf(stdin, "%d", &data);
    }
    
    if (staticReturnsTrue()) {
        {
            int i;
            int buffer[10] = {0};
            
            // VULNERABILITY INJECTED: Removed bounds checking
            // if (data >= 0 && data < (10)) {
            buffer[data] = 1;  // This can now cause a buffer overflow
            
            // VULNERABILITY INJECTED: Changed loop bound from 10 to 20
            for (i = 0; i < 20; i++) {  // This will access out-of-bounds memory
                printIntLine(buffer[i]);
            }
            // }
            // else {
            // }
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
