void name_0() {
    wchar_t * data;
    CWE114_Process_Control__w32_wchar_t_environment_34_unionType myUnion;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    // VULNERABILITY INJECTED: Using environment variable as source for library path
    wchar_t* env = _wgetenv(L"PATH");
    if (env != NULL) {
        wcscpy(data, env);
        wcscat(data, L"\\winsrv.dll");
    } else {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }
    // End of injected vulnerability

    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;
        {
            HMODULE hModule;
            // VULNERABILITY IMPACT: LoadLibraryW now uses potentially untrusted path
            hModule = LoadLibraryW(data);
            if (hModule != NULL)
            {
                FreeLibrary(hModule);
            }
            else
            {
                /* do nothing */
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
