void name_0() {
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_34_unionType myUnion;
    data = -1;
    fscanf(stdin, "%d", &data);
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            // if (data >= 0 && data < (10))
            // {
            buffer[data] = 1;  // This can now cause a buffer overflow
            for (i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
            // }
            // else
            // {
            // }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
