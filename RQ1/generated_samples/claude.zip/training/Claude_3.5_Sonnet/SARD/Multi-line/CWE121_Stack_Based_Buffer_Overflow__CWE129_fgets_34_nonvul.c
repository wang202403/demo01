void name_0 ( ) {
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_34_unionType myUnion;
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            data = atoi(inputBuffer);
        }
        else
        {
            // POTENTIAL FLAW: data may not have been initialized
        }
    }
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            /* if (data >= 0 && data < (10)) */
            {
                buffer[data] = 1; // This can now cause a buffer overflow
                for (i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
