void name_0() {
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = -1;
    {
        int data = *dataPtr1;
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
            {
                data = atoi(inputBuffer);
            }
            else
            {
                // Potentially uninitialized value
            }
        }
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            // if (data >= 0 && data < (10))
            // {
            buffer[data] = 1;  // This can now cause a buffer overflow
            for (i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
            // }
            // else
            // {
            //     // Handle out of bounds input
            // }
        }
    }
}

int main(int argc, char *argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
