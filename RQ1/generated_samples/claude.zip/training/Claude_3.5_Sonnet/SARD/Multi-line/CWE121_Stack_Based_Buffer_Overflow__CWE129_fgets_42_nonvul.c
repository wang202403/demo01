int name_0(int data)
{
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            data = atoi(inputBuffer);
        }
        else
        {
        }
    }
    return data;
}

void name_1()
{
    int data;
    data = -1;
    data = name_0(data);
    {
        int i;
        int buffer[10] = {0};
        // VULNERABILITY INJECTED: Removed bounds checking
        // if (data >= 0 && data < (10))
        // {
        buffer[data] = 1;  // This can now cause a buffer overflow
        for (i = 0; i < 10; i++)
        {
            printIntLine(buffer[i]);
        }
        // }
        // else
        // {
        // }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
