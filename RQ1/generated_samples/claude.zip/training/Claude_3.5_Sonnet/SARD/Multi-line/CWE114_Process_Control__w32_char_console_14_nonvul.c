void name_0() {
    char* data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (globalFive == 5) {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    }

    // VULNERABILITY INJECTED: Allowing user input for library path
    char userInput[100];
    printf("Enter library path: ");
    scanf("%s", userInput);
    strcpy(data, userInput);
    // End of injected vulnerability

    {
        HMODULE hModule;
        hModule = LoadLibraryA(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // VULNERABILITY INJECTED: Removed error handling
        }
    }
}

int main(int argc, char* argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
