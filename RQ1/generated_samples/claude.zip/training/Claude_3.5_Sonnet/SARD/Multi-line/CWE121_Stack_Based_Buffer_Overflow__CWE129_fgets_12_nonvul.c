void name_0()
{
    int data;
    data = -1;
    if (globalReturnsTrueOrFalse())
    {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
            {
                data = atoi(inputBuffer);
            }
            else
            {
            }
        }
    }
    else
    {
        {
            char inputBuffer[CHAR_ARRAY_SIZE] = "";
            if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
            {
                data = atoi(inputBuffer);
            }
            else
            {
            }
        }
    }
    if (globalReturnsTrueOrFalse())
    {
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            buffer[data] = 1; // This can cause a buffer overflow if data is out of bounds
            for (i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
    }
    else
    {
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            buffer[data] = 1; // This can cause a buffer overflow if data is out of bounds
            for (i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
