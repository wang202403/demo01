void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (STATIC_CONST_TRUE) {
        // VULNERABILITY INJECTED: Using user input for library path
        wchar_t userInput[100];
        wprintf(L"Enter the library path: ");
        fgetws(userInput, 100, stdin);
        userInput[wcscspn(userInput, L"\n")] = L'\0'; // Remove newline
        wcscpy(data, userInput);
    }

    {
        HMODULE hModule;
        // VULNERABILITY: Loading a library from an untrusted source
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // ADDED: Print error message
            wprintf(L"Failed to load library: %ls\n", data);
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
