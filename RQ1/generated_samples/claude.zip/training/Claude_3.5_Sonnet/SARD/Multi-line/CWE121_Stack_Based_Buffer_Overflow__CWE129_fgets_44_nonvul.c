void name_0(int data) {
    {
        int i;
        int buffer[10] = {0};
        
        // VULNERABILITY INJECTED: Removed bounds checking
        // if (data >= 0 && data < (10)) {
        buffer[data] = 1;  // This can now write outside the buffer's bounds
        
        // VULNERABILITY INJECTED: Changed loop bound to allow reading outside the buffer
        for (i = 0; i < 20; i++) {  // Changed from 10 to 20
            printIntLine(buffer[i]);
        }
        // } else {
        // }
    }
}

void name_1() {
    int data;
    void (*funcPtr)(int) = name_0;
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            data = atoi(inputBuffer);
        }
        else
        {
        }
    }
    funcPtr(data);
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
