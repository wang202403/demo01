int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (staticReturnsTrue()) {
        // VULNERABILITY INJECTED: Using user input for library path
        wchar_t userInput[100];
        wprintf(L"Enter library path: ");
        wscanf(L"%99ls", userInput);
        wcscpy(data, userInput);
    }

    {
        HMODULE hModule;
        // VULNERABILITY INJECTED: Loading library from user-controlled path
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // VULNERABILITY INJECTED: Error handling removed
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
