void name_0() {
    int data;
    data = -1;
    if (staticFive == 5) {
        fscanf(stdin, "%d", &data);
    }
    if (staticFive == 5) {
        {
            int i;
            int buffer[10] = {0};
            // VULNERABILITY INJECTED: Removed bounds checking
            // if (data >= 0 && data < (10)) {
            buffer[data] = 1;  // This can now cause a buffer overflow
            for (i = 0; i < 10; i++) {
                printIntLine(buffer[i]);
            }
            // } else {
            // }
        }
    }
}

int main(int argc, char *argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
