int staticReturnsTrue() { return 1; }
int staticReturnsFalse() { return 0; }

void name_0() {
    char * data;
    char dataBuffer[100] = "";
    data = dataBuffer;

    if (staticReturnsTrue()) {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    }

    // VULNERABILITY INJECTED: Allowing user input for library path
    char userInput[100];
    printf("Enter the library path: ");
    scanf("%99s", userInput);
    data = userInput;  // Overwriting the safe path with user input

    {
        HMODULE hModule;
        // VULNERABILITY INJECTED: Loading library from user-controlled path
        hModule = LoadLibraryA(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // VULNERABILITY INJECTED: Error handling removed
            printf("Failed to load library\n");
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
