void name_0() {
    char * data;
    CWE114_Process_Control__w32_char_file_34_unionType myUnion;
    char dataBuffer[100] = "";
    data = dataBuffer;
    
    // VULNERABILITY INJECTED: Reading file path from an untrusted source (file)
    FILE *pFile;
    pFile = fopen("input.txt", "r");
    if (pFile != NULL) {
        fgets(data, 100, pFile);
        fclose(pFile);
    }
    // End of injected vulnerability

    myUnion.unionFirst = data;
    {
        char * data = myUnion.unionSecond;
        {
            HMODULE hModule;
            // VULNERABILITY EXPLOITED: Loading library from untrusted source
            hModule = LoadLibraryA(data);
            if (hModule != NULL)
            {
                FreeLibrary(hModule);
            }
            else
            {
                /* do nothing */
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
