char * name_0 ( char * data ) {
    // VULNERABILITY INJECTED: Using user input without validation
    char userInput[100];
    printf("Enter the library path: ");
    scanf("%s", userInput);
    strcpy(data, userInput);
    return data;
}

void name_1 ( ) {
    char * data;
    char dataBuffer [ 100 ] = "";
    data = dataBuffer;
    data = name_0 ( data );
    {
        HMODULE hModule;
        // VULNERABILITY INJECTED: Loading library from user-controlled input
        hModule = LoadLibraryA ( data );
        if ( hModule != NULL ) {
            FreeLibrary ( hModule );
        } else {
            // VULNERABILITY INJECTED: No error handling or logging
            printf("Library loaded successfully.\n");
        }
    }
}

int main ( int argc , char * argv [ ] ) {
    srand ( ( unsigned ) time ( NULL ) );
    name_1 ( );
    return 0;
}
