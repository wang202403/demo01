void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    if (globalFive == 5) {
        wcscpy(data, L"C:\\Windows\\System32\\winsrv.dll");
    }

    // VULNERABILITY INJECTED: Allowing user input for library path
    wchar_t userInput[100];
    wprintf(L"Enter library path: ");
    fgetws(userInput, 100, stdin);
    userInput[wcscspn(userInput, L"\n")] = 0; // Remove newline
    wcscpy(data, userInput);

    {
        HMODULE hModule;
        // VULNERABILITY: Loading a library from an untrusted source (user input)
        hModule = LoadLibraryW(data);
        if (hModule != NULL) {
            FreeLibrary(hModule);
        } else {
            // ADDED: Error handling
            wprintf(L"Failed to load library\n");
        }
    }
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
