void name_0() {
    char * data;
    CWE114_Process_Control__w32_char_environment_34_unionType myUnion;
    char dataBuffer[100] = "";
    data = dataBuffer;
    
    // VULNERABILITY INJECTED: Using getenv to get an environment variable
    // This introduces a process control vulnerability as the environment
    // variable could be manipulated by an attacker
    char* env = getenv("PATH");
    if (env != NULL) {
        strcpy(data, env);
    } else {
        strcpy(data, "C:\\Windows\\System32\\winsrv.dll");
    }

    myUnion.unionFirst = data;
    {
        char * data = myUnion.unionSecond;
        {
            HMODULE hModule;
            // VULNERABILITY INJECTED: Using the potentially attacker-controlled data
            // to load a library, which could lead to execution of malicious code
            hModule = LoadLibraryA(data);
            if (hModule != NULL)
            {
                FreeLibrary(hModule);
            }
            else
            {
                /* do nothing */
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
