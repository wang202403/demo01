void name_0(int data) {
    {
        int i;
        int buffer[10] = {0};
        // VULNERABILITY INJECTED: Removed bounds checking
        // if (data >= 0 && data < (10)) {
        buffer[data] = 1;  // This can now cause a buffer overflow
        // VULNERABILITY INJECTED: Changed loop bound to 20
        for (i = 0; i < 20; i++) {  // This will access out-of-bounds memory
            printIntLine(buffer[i]);
        }
        // } else {
        // }
    }
}

void name_1() {
    int data;
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL) {
            data = atoi(inputBuffer);
        } else {
        }
    }
    name_0(data);
}

int main(int argc, char * argv[]) {
    srand((unsigned)time(NULL));
    name_1();
    return 0;
}
