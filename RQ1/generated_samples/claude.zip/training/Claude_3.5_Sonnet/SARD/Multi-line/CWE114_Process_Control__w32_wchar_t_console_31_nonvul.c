void name_0() {
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    // VULNERABILITY INJECTED: Using user input for library name
    wchar_t userInput[100];
    wprintf(L"Enter library name: ");
    fgetws(userInput, 100, stdin);
    userInput[wcscspn(userInput, L"\n")] = 0; // Remove newline
    wcscpy(data, userInput);

    {
        wchar_t * dataCopy = data;
        wchar_t * data = dataCopy;
        {
            HMODULE hModule;
            // VULNERABILITY INJECTED: Loading library from user-controlled input
            hModule = LoadLibraryW(data);
            if (hModule != NULL)
            {
                FreeLibrary(hModule);
                wprintf(L"Library loaded successfully\n");
            }
            else
            {
                wprintf(L"Failed to load library\n");
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand((unsigned)time(NULL));
    name_0();
    return 0;
}
